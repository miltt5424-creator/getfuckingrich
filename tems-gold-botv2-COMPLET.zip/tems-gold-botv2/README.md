# 🤖 Tems-gold-botv2

Bot de trading algorithmique — **Martingale/Grid hybride** avec **51 outils d'analyse** et système de survie 3 phases.

## Stack technique
- **Runtime** : Node.js ≥ 20 (ESM)
- **Dashboard** : Vite + React + Recharts
- **Connexion broker** : MT5 via ZeroMQ (DWX_ZeroMQ_Connector)
- **Alertes** : Telegram Bot API
- **CI/CD** : GitHub Actions

## Actifs supportés
| Symbole | Type   | Activé |
|---------|--------|--------|
| XAUUSD  | Métal  | ✅     |
| EURUSD  | Forex  | ✅     |
| GBPUSD  | Forex  | ✅     |
| BTCUSD  | Crypto | ⬜     |
| ETHUSD  | Crypto | ⬜     |

## Installation rapide

```bash
git clone https://github.com/ton-user/tems-gold-botv2.git
cd tems-gold-botv2
npm install
cp .env.example .env
# → Remplis .env avec tes valeurs (MT5, Telegram)
```

## Lancement

```bash
# Mode paper (test, aucun ordre réel) — TOUJOURS commencer ici
npm run dev

# Mode live (ordres réels)
BOT_MODE=live npm start

# Dashboard live (dans un autre terminal)
cd dashboard && npm install && npm run dev

# Guide installation bridge MT5
npm run setup-bridge

# Télécharger données historiques
npm run download-data

# Backtest
npm run backtest

# Optimisation des paramètres
npm run optimize
```

## Les 51 outils d'analyse

### Structure de prix (12 outils)
- SMC : Break of Structure, Change of Character, Order Blocks, FVG, Liquidity Sweep, Premium/Discount
- Fibonacci retracements (0.236→0.786) et extensions (1.272, 1.618, 2.0)
- Pivot Points quotidiens et hebdomadaires (CPR)
- Patterns harmoniques : Gartley, Bat, Crab, Butterfly, Shark
- Analyse Wyckoff : Spring, SOS, UTAD, SOW
- Elliott Waves simplifié (vagues 1-5 et A-B-C)
- 8 patterns de bougies japonaises

### Volume & liquidité (6 outils)
- Volume Profile avec POC, VAH, VAL
- VWAP journalier et hebdomadaire
- OBV avec détection de divergences
- Volume Delta (acheteurs vs vendeurs)
- Zones d'imbalance
- Analyse du volume tick

### Indicateurs techniques (10 outils)
- EMA 20/50/200 avec alignement et golden/death cross
- RSI 14 avec divergences haussières/baissières
- MACD signal + histogramme + croisements
- Stochastic RSI
- ADX (force de tendance — clé pour la Martingale)
- CCI, Williams %R, Momentum oscillator
- Supertrend basé ATR
- Ichimoku Cloud complet
- Parabolic SAR

### Volatilité (5 outils)
- ATR dynamique (calcul du grid step adaptatif)
- Bollinger Bands + Keltner Channels (squeeze detector)
- Volatilité historique vs actuelle
- Heatmap horaire de la volatilité XAUUSD
- Gap detector (gaps weekend et news)

### Macro & sentiment (7 outils)
- Corrélation DXY, US10Y, SPX500
- Calendrier économique automatique (NFP, Fed, CPI)
- COT Report (positions institutionnelles Gold futures)
- Fear & Greed proxy
- Open Interest Gold futures

### Multi-timeframe (4 outils)
- Biais H4 et H1
- Confluence M15 et M5

## Système de survie — 3 Phases

| Phase | Déclencheur | Action automatique |
|-------|-------------|-------------------|
| 1 | Normal (DD < 15%) | Trading normal, TP à ATR×1.5 |
| 2 | Niveau ≥ 7 ou DD ≥ 15% | Hedge 40% + TP élargi à ATR×3 |
| 3 | DD ≥ 40% | Fermeture totale + arrêt bot + alerte Telegram |

## Paramètres clés (config/params.json)

| Paramètre | Défaut | Description |
|-----------|--------|-------------|
| `lot_multiplier` | 1.5 | Multiplicateur Martingale |
| `max_levels` | 15 | Niveaux max par grille |
| `max_drawdown_pct` | 40% | Equity stop |
| `grid_step_atr_mult` | 1.2 | Écart entre niveaux (×ATR) |
| `min_score_to_trade` | 70% | Score minimum pour entrer |
| `hedge_ratio` | 0.4 | Lot hedge = 40% du cumul |

## Arborescence

```
tems-gold-botv2/
├── index.js                    ← Point d'entrée principal
├── config/params.json          ← Tous les paramètres
├── src/
│   ├── analysis/
│   │   ├── price/              ← SMC, HLZ, Fibonacci, Wyckoff, Elliott, Harmonics, Candles
│   │   ├── volume/             ← VolumeProfile, VWAP, OBV, Delta, Imbalance, TickVol
│   │   ├── indicators/         ← EMA, RSI, MACD, ADX, Ichimoku, Stoch
│   │   ├── volatility/         ← ATR, Bollinger, HistVol, Heatmap, Gap
│   │   ├── macro/              ← Corrélations, News, COT, FearGreed, OI
│   │   ├── mtf/                ← MTFAnalysis, BiasCalculator
│   │   ├── scoreEngine.js      ← Score global pondéré
│   │   └── signalEngine.js     ← Orchestrateur principal
│   ├── grid/                   ← GridManager, GridState, LotCalculator, TPManager
│   ├── survival/               ← SurvivalSystem, DrawdownMonitor, Hedge, EquityStop, Recovery
│   ├── broker/                 ← MT5Bridge (ZeroMQ), OrderManager, AccountMonitor, CandleFeeder
│   ├── notify/                 ← Telegram, DashboardServer, Reporter, Logger
│   └── utils/                  ← Config, Math, Time, EventBus
├── dashboard/                  ← Interface Vite React live
└── scripts/                    ← Backtest, Optimize, DataDownloader, Setup
```

## ⚠️ Avertissement

Le trading comporte des risques de perte en capital. Ce bot est fourni à des fins éducatives.
**Toujours tester en mode paper avant d'activer le mode live.**
