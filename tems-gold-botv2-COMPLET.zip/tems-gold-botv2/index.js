// ============================================================
//  TEMS-GOLD-BOTV2 — Point d'entrée principal
//  Martingale/Grid hybride | 51 outils d'analyse | SMC + HLZ
// ============================================================

import 'dotenv/config';
import { config }          from './src/utils/config.js';
import logger              from './src/utils/logger.js';
import { bus, EVENTS }     from './src/utils/eventBus.js';
import { isAnyTradingSessionActive, isDailyReportTime, isWeekend } from './src/utils/time.js';

import { MT5Bridge }        from './src/broker/mt5Bridge.js';
import { AccountMonitor }   from './src/broker/accountMonitor.js';
import { CandleFeeder }     from './src/broker/candleFeeder.js';
import { Reconnector }      from './src/broker/reconnector.js';
import { OrderManager }     from './src/broker/orderManager.js';

import { SignalEngine }      from './src/analysis/signalEngine.js';

import { GridManager }       from './src/grid/gridManager.js';
import { SurvivalSystem }    from './src/survival/survivalSystem.js';
import { RecoveryEngine }    from './src/survival/recoveryEngine.js';

import { TelegramNotifier }  from './src/notify/telegram.js';
import { DashboardServer }   from './src/notify/dashboardServer.js';
import { Reporter }          from './src/notify/reporter.js';

// ─── Initialisation ────────────────────────────────────────

logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
logger.info('  🤖 TEMS-GOLD-BOTV2  v2.0.0  |  Démarrage...');
logger.info(`  Mode     : ${config.env.mode.toUpperCase()}`);
logger.info(`  Symboles : ${config.getEnabledSymbols().map(s => s.name).join(', ')}`);
logger.info(`  Capital  : Lot initial ${config.grid.lot_initial} × ${config.grid.lot_multiplier} — max ${config.grid.max_levels} niveaux`);
logger.info(`  Score    : Minimum ${config.score.min_score_to_trade}% pour entrer`);
logger.info('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');

if (config.isLive) logger.warn('⚠️  MODE LIVE — Ordres réels seront envoyés à MT5 !');
else               logger.info('🧪 MODE PAPER — Aucun ordre réel');

// ─── Instanciation des modules ─────────────────────────────

const telegram   = new TelegramNotifier(config);
const bridge     = new MT5Bridge(config);
const survival   = new SurvivalSystem(config, bridge, telegram);
const signal     = new SignalEngine(config);
const gridMgr    = new GridManager(config, bridge, survival, telegram);
const acctMon    = new AccountMonitor(bridge, survival);
const candleFeed = new CandleFeeder(bridge, signal, config);
const reconnector= new Reconnector(bridge, config, telegram);
const orderMgr   = new OrderManager(bridge, config);
const dashServer = new DashboardServer(config);
const reporter   = new Reporter(config, gridMgr, survival, telegram);
const recovery   = new RecoveryEngine(config, survival, telegram);

// ─── État global ───────────────────────────────────────────
let running      = true;
let loopCount    = 0;
let lastReport   = -1;

// ─── Bootstrap ─────────────────────────────────────────────

async function bootstrap() {
  telegram.init();
  dashServer.start();
  reconnector.watch();

  // Connexion MT5
  if (config.isPaper) {
    logger.info('[Bootstrap] Mode PAPER — bridge MT5 simulé');
  } else {
    logger.info('[Bootstrap] Connexion au bridge MT5...');
    await bridge.connect();
    logger.info('[Bootstrap] Bridge MT5 connecté ✓');
  }

  // Chargement de l'historique des bougies
  logger.info('[Bootstrap] Chargement de l\'historique des bougies...');
  await candleFeed.start();
  logger.info('[Bootstrap] Bougies chargées ✓');

  // Rafraîchissement initial des données macro
  logger.info('[Bootstrap] Rafraîchissement données macro (news, corrélations)...');
  await signal.refreshMacro();
  logger.info('[Bootstrap] Macro chargée ✓');

  // Initialisation du compte
  const account = await acctMon.refresh();
  survival.init(account.equity);
  reporter.setStartEquity(account.equity);
  logger.info(`[Bootstrap] Equity initiale: ${account.equity}$`);

  // Notification de démarrage
  await telegram.notifyStartup(config.env.mode, config.getEnabledSymbols().map(s => s.name));

  logger.info('[Bootstrap] ✅ Bot prêt — boucle principale démarrée\n');

  // Démarrer la boucle principale
  mainLoop();

  // Rafraîchissement macro toutes les heures
  setInterval(() => signal.refreshMacro(), 60 * 60 * 1000);

  // Rapport quotidien
  setInterval(async () => {
    if (isDailyReportTime()) {
      const acc = acctMon.getAccount();
      await reporter.generateDailyReport(acc.equity);
    }
  }, 60 * 1000);
}

// ─── Boucle principale ─────────────────────────────────────

async function mainLoop() {
  while (running) {
    const loopStart = Date.now();
    loopCount++;

    try {
      // Vérifier equity stop
      if (survival.equityStop.isTriggered()) {
        if (running) {
          logger.risk('[MainLoop] Equity stop actif — boucle suspendue');
          recovery.startRecovery();
          running = false;
          break;
        }
      }

      // Weekend : ne pas trader
      if (isWeekend()) {
        await sleep(60000);
        continue;
      }

      // Récupérer l'état du compte
      const account = acctMon.getAccount();

      // Récupérer les prix actuels
      const prices = await getCurrentPrices();

      // Gérer les grilles existantes
      await gridMgr.manageAll(prices, account);

      // Broadcast état dashboard
      dashServer.updateState('account', account);
      dashServer.updateState('gridStats', gridMgr.getStats());
      dashServer.updateState('survival', survival.getStatus());

      // Analyser les signaux et ouvrir de nouvelles grilles
      if (isAnyTradingSessionActive()) {
        await analyzeAndTrade(account, prices);
      }

      // Attendre jusqu'à la prochaine itération
      const elapsed = Date.now() - loopStart;
      const waitMs  = Math.max(0, (config.general?.loop_interval_ms || 1000) - elapsed);
      await sleep(waitMs);

    } catch (err) {
      logger.error(`[MainLoop] Erreur: ${err.message}`, { stack: err.stack });
      await sleep(5000);
    }
  }
}

// ─── Analyse et ouverture de grilles ──────────────────────

async function analyzeAndTrade(account, prices) {
  const enabledSymbols = config.getEnabledSymbols();

  for (const sym of enabledSymbols) {
    const symbol = sym.name;
    const price  = prices[symbol];
    if (!price) continue;

    // Vérifier si on peut encore trader (risk guard)
    const riskCheck = survival.check(account.equity);
    if (!riskCheck.allowed) {
      if (loopCount % 60 === 0) logger.risk(`[Trade] Bloqué: ${riskCheck.reason}`);
      continue;
    }

    // Analyser le signal
    const sig = await signal.analyze(symbol);

    // Broadcaster le signal au dashboard
    dashServer.broadcast('signal:generated', {
      symbol, score: sig.score, go: sig.go, direction: sig.direction, breakdown: sig.breakdown,
    });

    if (!sig.go || !sig.direction) {
      if (loopCount % 30 === 0) {
        logger.debug(`[Trade] ${symbol} NO-GO: ${sig.reason} (score=${sig.score}%)`);
      }
      continue;
    }

    // Ouvrir la grille
    const grid = await gridMgr.openGrid(symbol, sig);
    if (grid) {
      reporter.recordTrade({ symbol, direction: sig.direction, openTime: new Date(), profit: 0 });
    }
  }
}

// ─── Récupère les prix actuels ────────────────────────────

async function getCurrentPrices() {
  const prices = {};
  const symbols = config.getEnabledSymbols().map(s => s.name);

  for (const symbol of symbols) {
    const candles = candleFeed.getCandles(symbol, 'M1');
    if (candles.length > 0) {
      prices[symbol] = candles[candles.length - 1].close;
    }
  }
  return prices;
}

// ─── Gestion propre de l'arrêt ────────────────────────────

async function shutdown(signal) {
  logger.warn(`\n[Shutdown] Signal reçu: ${signal} — arrêt propre...`);
  running = false;

  try {
    candleFeed.stop();
    acctMon.stop();
    dashServer.stop();
    if (!config.isPaper) await bridge.disconnect();
    logger.info('[Shutdown] Toutes les connexions fermées. Au revoir !');
  } catch (e) {
    logger.error(`[Shutdown] Erreur: ${e.message}`);
  }
  process.exit(0);
}

process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('uncaughtException', async (err) => {
  logger.error('💀 Exception non capturée', { error: err.message, stack: err.stack });
  await telegram.notifyFatalError(err.message).catch(() => {});
  await shutdown('uncaughtException');
});
process.on('unhandledRejection', (reason) => {
  logger.error('Promise rejetée non gérée', { reason: String(reason) });
});

// ─── Utilitaires ──────────────────────────────────────────

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ─── Lancement ────────────────────────────────────────────

bootstrap().catch(async (err) => {
  logger.error(`💀 Erreur fatale au démarrage: ${err.message}`, { stack: err.stack });
  process.exit(1);
});
