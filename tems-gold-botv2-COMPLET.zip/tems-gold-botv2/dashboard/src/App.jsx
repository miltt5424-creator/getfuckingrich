import React, { useState, useEffect, useRef } from 'react';
import EquityCurve    from './components/EquityCurve.jsx';
import GridCard       from './components/GridCard.jsx';
import SignalPanel    from './components/SignalPanel.jsx';
import PhaseIndicator from './components/PhaseIndicator.jsx';
import TradeHistory   from './components/TradeHistory.jsx';
import StatsPanel     from './components/StatsPanel.jsx';

const C = {
  bg:      '#0a0a0f', card:    '#12121a', border:  '#1e1e2e',
  text:    '#e2e8f0', muted:   '#64748b', accent:  '#f59e0b',
  green:   '#22c55e', red:     '#ef4444', blue:    '#3b82f6', purple: '#a855f7',
};

const s = {
  app:     { minHeight:'100vh', background:C.bg, color:C.text, fontFamily:'Segoe UI,system-ui,sans-serif', padding:'16px' },
  header:  { display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:'20px', paddingBottom:'12px', borderBottom:`1px solid ${C.border}` },
  title:   { fontSize:'20px', fontWeight:700, color:C.accent, letterSpacing:'0.05em' },
  status:  { display:'flex', gap:'8px', alignItems:'center' },
  dot:     (connected) => ({ width:'8px', height:'8px', borderRadius:'50%', background: connected ? C.green : C.red, boxShadow: connected ? `0 0 8px ${C.green}` : 'none' }),
  grid3:   { display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:'12px', marginBottom:'16px' },
  grid2:   { display:'grid', gridTemplateColumns:'1fr 1fr', gap:'12px', marginBottom:'16px' },
  card:    { background:C.card, border:`1px solid ${C.border}`, borderRadius:'10px', padding:'16px' },
  label:   { fontSize:'11px', color:C.muted, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:'4px' },
  value:   { fontSize:'24px', fontWeight:700 },
  profit:  (v) => ({ fontSize:'24px', fontWeight:700, color: v >= 0 ? C.green : C.red }),
  tag:     (c) => ({ background: c+'22', color:c, border:`1px solid ${c}44`, borderRadius:'4px', padding:'2px 6px', fontSize:'10px', fontWeight:600 }),
  log:     { background:C.card, border:`1px solid ${C.border}`, borderRadius:'10px', padding:'12px', maxHeight:'180px', overflowY:'auto', fontFamily:'monospace', fontSize:'11px' },
  logLine: (type) => ({ color: type==='error'?C.red: type==='trade'?C.green: type==='risk'?C.accent: C.muted, marginBottom:'2px', lineHeight:1.4 }),
};

export default function App() {
  const [ws, setWs]             = useState(null);
  const [connected, setConnected] = useState(false);
  const [account, setAccount]   = useState({ equity:0, balance:0, freeMargin:0 });
  const [gridStats, setGridStats] = useState({ activeGrids:0, winRate:0, totalProfit:0 });
  const [survival, setSurvival] = useState({ phase:1, blocked:false, ddStats:{} });
  const [grids, setGrids]       = useState([]);
  const [signals, setSignals]   = useState([]);
  const [trades, setTrades]     = useState([]);
  const [equityHistory, setEquityHistory] = useState([]);
  const [logs, setLogs]         = useState([]);
  const [mode, setMode]         = useState('PAPER');
  const logsEndRef              = useRef(null);

  // Connexion WebSocket au dashboardServer
  useEffect(() => {
    function connect() {
      const socket = new WebSocket('ws://localhost:3002');

      socket.onopen = () => {
        setConnected(true);
        setWs(socket);
        addLog('Connecté au bot', 'info');
      };

      socket.onclose = () => {
        setConnected(false);
        addLog('Déconnecté — reconnexion dans 3s...', 'error');
        setTimeout(connect, 3000);
      };

      socket.onmessage = (evt) => {
        try {
          const { type, data } = JSON.parse(evt.data);
          handleEvent(type, data);
        } catch {}
      };
    }
    connect();
  }, []);

  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [logs]);

  function addLog(msg, type = 'info') {
    const ts = new Date().toTimeString().slice(0, 8);
    setLogs(prev => [...prev.slice(-100), { msg, type, ts }]);
  }

  function handleEvent(type, data) {
    switch (type) {
      case 'STATE_UPDATE':
        if (data.key === 'account')   setAccount(data.value || {});
        if (data.key === 'gridStats') setGridStats(data.value || {});
        if (data.key === 'survival')  setSurvival(data.value || {});
        break;
      case 'account:equity_updated':
        setAccount(data || {});
        setEquityHistory(prev => [...prev.slice(-500), { equity: data?.equity || 0, ts: Date.now() }]);
        break;
      case 'grid:opened':
        setGrids(prev => [...prev.filter(g => g.id !== data.id), data]);
        addLog(`Grille ouverte: ${data.symbol} ${data.direction} (score ${data.signalScore}%)`, 'trade');
        break;
      case 'grid:level_added':
        setGrids(prev => prev.map(g => g.id === data.id ? data : g));
        addLog(`Niveau ${data.level} — ${data.symbol} ${data.direction}`, 'trade');
        break;
      case 'grid:tp_hit':
        setGrids(prev => prev.filter(g => g.id !== data.id));
        setTrades(prev => [{ ...data, closeReason: 'TP_HIT' }, ...prev.slice(0, 199)]);
        addLog(`✅ TP HIT — ${data.symbol} | Profit: ${data.floatingPnL?.toFixed(2)}$`, 'trade');
        break;
      case 'grid:closed':
        setGrids(prev => prev.filter(g => g.id !== data.id));
        setTrades(prev => [data, ...prev.slice(0, 199)]);
        addLog(`Grille fermée — ${data.symbol} (${data.closeReason})`, 'info');
        break;
      case 'signal:generated':
        setSignals(prev => [data, ...prev.slice(0, 19)]);
        break;
      case 'survival:phase_changed':
        addLog(`⚠️ Phase ${data.phase} — ${data.gridId}`, 'risk');
        break;
      case 'survival:equity_stop':
        addLog(`🚨 EQUITY STOP — ${data.reason}`, 'error');
        break;
      case 'bridge:connected':
        addLog('Bridge MT5 connecté', 'info');
        break;
      case 'bridge:disconnected':
        addLog('Bridge MT5 déconnecté !', 'error');
        break;
    }
  }

  const ddPct = survival.ddStats?.maxDDSeen || 0;
  const activeGridsList = grids.filter(g => g.status === 'open');

  return (
    <div style={s.app}>
      {/* Header */}
      <div style={s.header}>
        <div>
          <div style={s.title}>🤖 TEMS-GOLD-BOTV2</div>
          <div style={{ fontSize:'11px', color:C.muted, marginTop:'2px' }}>Martingale/Grid Hybride · 51 outils d'analyse</div>
        </div>
        <div style={s.status}>
          <div style={s.dot(connected)}></div>
          <span style={{ fontSize:'12px', color: connected ? C.green : C.red }}>{connected ? 'CONNECTÉ' : 'DÉCONNECTÉ'}</span>
          <span style={s.tag(mode === 'LIVE' ? C.green : C.blue)}>{mode}</span>
          <span style={s.tag(survival.phase === 1 ? C.green : survival.phase === 2 ? C.accent : C.red)}>Phase {survival.phase}</span>
          {survival.blocked && <span style={s.tag(C.red)}>BLOQUÉ</span>}
        </div>
      </div>

      {/* Stats compte */}
      <div style={s.grid3}>
        <div style={s.card}>
          <div style={s.label}>Equity</div>
          <div style={s.value}>{account.equity?.toFixed(2) || '0.00'}$</div>
        </div>
        <div style={s.card}>
          <div style={s.label}>Balance</div>
          <div style={s.value}>{account.balance?.toFixed(2) || '0.00'}$</div>
        </div>
        <div style={s.card}>
          <div style={s.label}>Profit total</div>
          <div style={s.profit(gridStats.totalProfit || 0)}>{(gridStats.totalProfit || 0) >= 0 ? '+' : ''}{(gridStats.totalProfit || 0).toFixed(2)}$</div>
        </div>
        <div style={s.card}>
          <div style={s.label}>Grilles actives</div>
          <div style={s.value}>{gridStats.activeGrids || 0}</div>
        </div>
        <div style={s.card}>
          <div style={s.label}>Win Rate</div>
          <div style={{ ...s.value, color: parseFloat(gridStats.winRate) > 60 ? C.green : C.accent }}>{gridStats.winRate || 0}%</div>
        </div>
        <div style={s.card}>
          <div style={s.label}>DD max</div>
          <div style={{ ...s.value, color: ddPct > 20 ? C.red : ddPct > 10 ? C.accent : C.green }}>{ddPct?.toFixed(1) || 0}%</div>
        </div>
      </div>

      {/* Equity curve */}
      <div style={{ ...s.card, marginBottom:'16px' }}>
        <div style={{ ...s.label, marginBottom:'8px' }}>Equity Curve</div>
        <EquityCurve data={equityHistory} />
      </div>

      {/* Grilles actives */}
      <div style={{ marginBottom:'16px' }}>
        <div style={{ fontSize:'13px', fontWeight:600, marginBottom:'10px', color:C.muted }}>
          GRILLES ACTIVES ({activeGridsList.length})
        </div>
        {activeGridsList.length === 0
          ? <div style={{ ...s.card, color:C.muted, fontSize:'13px', textAlign:'center', padding:'24px' }}>Aucune grille active</div>
          : <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(280px, 1fr))', gap:'10px' }}>
              {activeGridsList.map(g => <GridCard key={g.id} grid={g} />)}
            </div>
        }
      </div>

      {/* Signaux + Phase indicator */}
      <div style={s.grid2}>
        <SignalPanel signals={signals} />
        <PhaseIndicator survival={survival} account={account} />
      </div>

      {/* Stats globales */}
      <div style={{ marginBottom: '16px' }}>
        <StatsPanel gridStats={gridStats} trades={trades} survivalStatus={survival} />
      </div>

      {/* Historique des trades */}
      <div style={{ marginBottom: '16px' }}>
        <TradeHistory trades={trades} />
      </div>

      {/* Logs */}
      <div style={s.card}>
        <div style={{ ...s.label, marginBottom:'8px' }}>Logs temps réel</div>
        <div style={s.log}>
          {logs.map((l, i) => (
            <div key={i} style={s.logLine(l.type)}>
              <span style={{ color:C.muted }}>[{l.ts}]</span> {l.msg}
            </div>
          ))}
          <div ref={logsEndRef} />
        </div>
      </div>
    </div>
  );
}
