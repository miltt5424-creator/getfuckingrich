import React from 'react';

const C = { green:'#22c55e', red:'#ef4444', amber:'#f59e0b', muted:'#64748b', border:'#1e1e2e', card:'#12121a', text:'#e2e8f0', purple:'#a855f7' };

function ScoreBar({ label, value, color }) {
  return (
    <div style={{ marginBottom:'5px' }}>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:'10px', color:C.muted, marginBottom:'2px' }}>
        <span>{label}</span><span style={{ color }}>{value || 0}%</span>
      </div>
      <div style={{ background:'#1e1e2e', borderRadius:'3px', height:'4px' }}>
        <div style={{ height:'4px', width:`${value || 0}%`, background:color, borderRadius:'3px', transition:'width 0.4s' }} />
      </div>
    </div>
  );
}

export default function SignalPanel({ signals }) {
  const latest = signals[0];

  return (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:'10px', padding:'16px' }}>
      <div style={{ fontSize:'11px', color:C.muted, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:'12px' }}>Derniers signaux</div>

      {!latest
        ? <div style={{ color:C.muted, fontSize:'12px', textAlign:'center', padding:'16px' }}>En attente de signaux...</div>
        : <>
          {/* Signal le plus récent */}
          <div style={{ padding:'10px', background:'#0a0a0f', borderRadius:'8px', marginBottom:'12px', border:`1px solid ${latest.go ? '#22c55e33' : '#ef444433'}` }}>
            <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:'8px' }}>
              <div>
                <span style={{ fontWeight:700, fontSize:'14px' }}>{latest.symbol}</span>
                {latest.direction && <span style={{ marginLeft:'8px', fontSize:'11px', color: latest.direction === 'BUY' ? C.green : C.red, fontWeight:600 }}>{latest.direction === 'BUY' ? '▲' : '▼'} {latest.direction}</span>}
              </div>
              <div style={{ display:'flex', alignItems:'center', gap:'6px' }}>
                <span style={{ fontSize:'18px', fontWeight:700, color: latest.score >= 70 ? C.green : C.amber }}>{latest.score}%</span>
                <span style={{ fontSize:'10px', padding:'2px 6px', borderRadius:'4px', background: latest.go ? '#22c55e22' : '#ef444422', color: latest.go ? C.green : C.red, fontWeight:700 }}>
                  {latest.go ? 'GO' : 'NO-GO'}
                </span>
              </div>
            </div>
            {latest.breakdown && (
              <>
                <ScoreBar label="Structure SMC/HLZ" value={latest.breakdown.structure} color={C.purple} />
                <ScoreBar label="Indicateurs"       value={latest.breakdown.indicators} color={C.blue} />
                <ScoreBar label="Multi-Timeframe"   value={latest.breakdown.mtf}        color={C.amber} />
                <ScoreBar label="Macro"             value={latest.breakdown.macro}      color={C.green} />
                <ScoreBar label="Volatilité"        value={latest.breakdown.volatility} color={C.red} />
              </>
            )}
          </div>

          {/* Historique des signaux */}
          <div style={{ display:'flex', flexDirection:'column', gap:'4px', maxHeight:'120px', overflowY:'auto' }}>
            {signals.slice(1, 8).map((sig, i) => (
              <div key={i} style={{ display:'flex', justifyContent:'space-between', fontSize:'11px', padding:'4px 6px', borderRadius:'4px', background:'#0a0a0f' }}>
                <span style={{ color:C.text }}>{sig.symbol}</span>
                <span style={{ color: sig.direction === 'BUY' ? C.green : sig.direction === 'SELL' ? C.red : C.muted }}>{sig.direction || '—'}</span>
                <span style={{ color: sig.score >= 70 ? C.green : C.amber }}>{sig.score}%</span>
                <span style={{ color: sig.go ? C.green : C.muted }}>{sig.go ? '✓' : '✗'}</span>
              </div>
            ))}
          </div>
        </>
      }
    </div>
  );
}
