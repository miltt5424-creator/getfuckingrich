import React, { useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const C = {
  green: '#22c55e', red: '#ef4444', amber: '#f59e0b',
  blue: '#3b82f6', purple: '#a855f7', muted: '#64748b',
  border: '#1e1e2e', card: '#12121a', text: '#e2e8f0', bg: '#0a0a0f',
};

function StatCard({ label, value, sub, color, icon }) {
  return (
    <div style={{ background: C.bg, border: `1px solid ${C.border}`, borderRadius: '8px', padding: '12px 14px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontSize: '10px', color: C.muted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '4px' }}>{label}</div>
          <div style={{ fontSize: '20px', fontWeight: 700, color: color || C.text }}>{value}</div>
          {sub && <div style={{ fontSize: '10px', color: C.muted, marginTop: '2px' }}>{sub}</div>}
        </div>
        {icon && <span style={{ fontSize: '20px', opacity: 0.7 }}>{icon}</span>}
      </div>
    </div>
  );
}

function SymbolRow({ symbol, data }) {
  const isPositive = (data.profit || 0) >= 0;
  const wr = data.count > 0 ? (data.wins / data.count * 100).toFixed(0) : 0;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: '10px', padding: '6px 8px', borderRadius: '6px', background: C.bg, marginBottom: '4px' }}>
      <span style={{ fontSize: '12px', fontWeight: 600, color: C.text, width: '70px' }}>{symbol}</span>
      <div style={{ flex: 1, height: '4px', background: C.border, borderRadius: '2px', overflow: 'hidden' }}>
        <div style={{ height: '4px', width: `${Math.min(100, Math.abs(wr))}%`, background: isPositive ? C.green : C.red, borderRadius: '2px' }} />
      </div>
      <span style={{ fontSize: '11px', color: C.muted, width: '32px', textAlign: 'right' }}>{wr}%</span>
      <span style={{ fontSize: '12px', fontWeight: 600, color: isPositive ? C.green : C.red, width: '70px', textAlign: 'right' }}>
        {isPositive ? '+' : ''}{(data.profit || 0).toFixed(2)}$
      </span>
      <span style={{ fontSize: '10px', color: C.muted, width: '40px', textAlign: 'right' }}>{data.count} trades</span>
    </div>
  );
}

export default function StatsPanel({ gridStats = {}, trades = [], survivalStatus = {} }) {
  // Calculs des statistiques
  const stats = useMemo(() => {
    const closedTrades = trades.filter(t => t.status === 'closed' || t.closeReason);
    const wins   = closedTrades.filter(t => (t.profit || 0) > 0);
    const losses = closedTrades.filter(t => (t.profit || 0) <= 0);
    const totalProfit = closedTrades.reduce((s, t) => s + (t.profit || 0), 0);
    const grossWins  = wins.reduce((s, t) => s + (t.profit || 0), 0);
    const grossLoss  = losses.reduce((s, t) => s + Math.abs(t.profit || 0), 0);
    const profitFactor = grossLoss > 0 ? (grossWins / grossLoss).toFixed(2) : '∞';
    const avgWin    = wins.length   > 0 ? grossWins / wins.length : 0;
    const avgLoss   = losses.length > 0 ? grossLoss / losses.length : 0;
    const avgLevels = closedTrades.length > 0
      ? closedTrades.reduce((s, t) => s + (t.level || 1), 0) / closedTrades.length
      : 0;
    const avgDuration = closedTrades.length > 0
      ? closedTrades.reduce((s, t) => s + (t.duration || 0), 0) / closedTrades.length
      : 0;

    // Streak en cours
    let currentStreak = 0, streakType = null;
    for (let i = closedTrades.length - 1; i >= 0; i--) {
      const isWin = (closedTrades[i].profit || 0) > 0;
      if (streakType === null) { streakType = isWin ? 'win' : 'loss'; currentStreak = 1; }
      else if ((isWin && streakType === 'win') || (!isWin && streakType === 'loss')) currentStreak++;
      else break;
    }

    // Profit par symbole
    const bySymbol = {};
    closedTrades.forEach(t => {
      const s = t.symbol || 'Unknown';
      if (!bySymbol[s]) bySymbol[s] = { profit: 0, count: 0, wins: 0 };
      bySymbol[s].profit += (t.profit || 0);
      bySymbol[s].count++;
      if ((t.profit || 0) > 0) bySymbol[s].wins++;
    });

    // Profit par heure (pour le heatmap)
    const byHour = Array(24).fill(0).map((_, h) => ({ hour: h, profit: 0, count: 0 }));
    closedTrades.forEach(t => {
      if (t.openTime) {
        const h = new Date(t.openTime).getHours();
        byHour[h].profit += (t.profit || 0);
        byHour[h].count++;
      }
    });

    return {
      total: closedTrades.length, wins: wins.length, losses: losses.length,
      winRate: closedTrades.length > 0 ? (wins.length / closedTrades.length * 100).toFixed(1) : 0,
      totalProfit, profitFactor, avgWin, avgLoss,
      avgLevels: avgLevels.toFixed(1), avgDuration: avgDuration.toFixed(0),
      currentStreak, streakType, bySymbol, byHour,
    };
  }, [trades]);

  const maxHourProfit = Math.max(...stats.byHour.map(h => Math.abs(h.profit)), 1);

  const CustomBarTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) return null;
    const d = payload[0].payload;
    return (
      <div style={{ background: C.card, border: `1px solid ${C.border}`, padding: '6px 10px', borderRadius: '6px', fontSize: '11px' }}>
        <div style={{ color: C.text }}>{d.hour}:00 UTC</div>
        <div style={{ color: d.profit >= 0 ? C.green : C.red }}>{d.profit >= 0 ? '+' : ''}{d.profit.toFixed(2)}$</div>
        <div style={{ color: C.muted }}>{d.count} trades</div>
      </div>
    );
  };

  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: '10px', padding: '16px' }}>
      <div style={{ fontSize: '11px', color: C.muted, textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: '14px' }}>
        Statistiques globales
      </div>

      {/* KPIs principaux */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', marginBottom: '14px' }}>
        <StatCard
          label="Win Rate"
          value={`${stats.winRate}%`}
          sub={`${stats.wins}W / ${stats.losses}L`}
          color={parseFloat(stats.winRate) >= 60 ? C.green : parseFloat(stats.winRate) >= 45 ? C.amber : C.red}
          icon="🎯"
        />
        <StatCard
          label="Profit Total"
          value={`${stats.totalProfit >= 0 ? '+' : ''}${stats.totalProfit.toFixed(2)}$`}
          sub={`${stats.total} trades`}
          color={stats.totalProfit >= 0 ? C.green : C.red}
          icon="💰"
        />
        <StatCard
          label="Profit Factor"
          value={stats.profitFactor}
          sub={`Moy win: +${stats.avgWin.toFixed(2)}$`}
          color={parseFloat(stats.profitFactor) >= 1.5 ? C.green : parseFloat(stats.profitFactor) >= 1 ? C.amber : C.red}
          icon="📊"
        />
        <StatCard
          label="DD Max"
          value={`${survivalStatus?.ddStats?.maxDDSeen?.toFixed(1) || 0}%`}
          sub={`Phase: ${survivalStatus?.phase || 1}`}
          color={
            (survivalStatus?.ddStats?.maxDDSeen || 0) > 20 ? C.red :
            (survivalStatus?.ddStats?.maxDDSeen || 0) > 10 ? C.amber : C.green
          }
          icon="📉"
        />
      </div>

      {/* Stats secondaires */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px', marginBottom: '14px' }}>
        <StatCard label="Niv. moyen"  value={stats.avgLevels}       sub="niveaux/grille"   color={C.blue}   icon="📶" />
        <StatCard label="Durée moy."  value={`${stats.avgDuration}m`} sub="par grille"     color={C.blue}   icon="⏱️" />
        <StatCard label="Moy. gain"   value={`+${stats.avgWin.toFixed(2)}$`}  sub="par TP"  color={C.green}  icon="✅" />
        <StatCard label="Moy. perte"  value={`-${stats.avgLoss.toFixed(2)}$`} sub="par SL"  color={C.red}    icon="❌" />
      </div>

      {/* Streak */}
      {stats.currentStreak > 1 && (
        <div style={{
          padding: '8px 12px', borderRadius: '8px', marginBottom: '14px',
          background: stats.streakType === 'win' ? `${C.green}22` : `${C.red}22`,
          border: `1px solid ${stats.streakType === 'win' ? C.green : C.red}44`,
          fontSize: '12px', color: stats.streakType === 'win' ? C.green : C.red,
          display: 'flex', alignItems: 'center', gap: '8px',
        }}>
          <span style={{ fontSize: '16px' }}>{stats.streakType === 'win' ? '🔥' : '❄️'}</span>
          <span><strong>{stats.currentStreak} {stats.streakType === 'win' ? 'victoires' : 'pertes'} consécutives</strong> en cours</span>
        </div>
      )}

      {/* Profit par symbole */}
      {Object.keys(stats.bySymbol).length > 0 && (
        <div style={{ marginBottom: '14px' }}>
          <div style={{ fontSize: '10px', color: C.muted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '8px' }}>Performance par symbole</div>
          {Object.entries(stats.bySymbol)
            .sort((a, b) => b[1].profit - a[1].profit)
            .map(([symbol, data]) => (
              <SymbolRow key={symbol} symbol={symbol} data={data} />
            ))
          }
        </div>
      )}

      {/* Heatmap profit par heure */}
      {stats.total > 0 && (
        <div>
          <div style={{ fontSize: '10px', color: C.muted, textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: '8px' }}>Profit par heure UTC</div>
          <ResponsiveContainer width="100%" height={80}>
            <BarChart data={stats.byHour} margin={{ top: 0, right: 0, bottom: 0, left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={C.border} vertical={false} />
              <XAxis dataKey="hour" tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false}
                tickFormatter={h => h % 4 === 0 ? `${h}h` : ''} />
              <YAxis tick={{ fontSize: 9, fill: C.muted }} tickLine={false} axisLine={false} />
              <Tooltip content={<CustomBarTooltip />} />
              <Bar dataKey="profit" radius={[2, 2, 0, 0]}>
                {stats.byHour.map((entry, i) => (
                  <Cell key={i} fill={entry.profit >= 0 ? C.green : C.red} opacity={0.4 + Math.abs(entry.profit) / maxHourProfit * 0.6} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
          <div style={{ fontSize: '10px', color: C.muted, textAlign: 'center', marginTop: '4px' }}>
            Heures optimales: 08h-11h (London open) et 13h-17h (NY overlap)
          </div>
        </div>
      )}

      {stats.total === 0 && (
        <div style={{ textAlign: 'center', padding: '20px', color: C.muted, fontSize: '12px' }}>
          Les statistiques s'afficheront après les premiers trades
        </div>
      )}
    </div>
  );
}
