import React, { useEffect, useState } from 'react';

const PHASES = {
  1: { color:'#22c55e', label:'Phase 1 — Normal',       desc:'Trading actif. Grille s\'ouvre normalement.', icon:'✅' },
  2: { color:'#f59e0b', label:'Phase 2 — Hedge actif',  desc:'Hedge 40% ouvert. TP élargi à ATR×3.', icon:'⚠️' },
  3: { color:'#ef4444', label:'Phase 3 — EQUITY STOP',  desc:'Toutes positions fermées. Bot arrêté.', icon:'🚨' },
};

export default function PhaseIndicator({ survival, account }) {
  const [blink, setBlink] = useState(false);
  const phase = survival?.phase || 1;
  const info  = PHASES[phase] || PHASES[1];
  const dd    = survival?.ddStats?.maxDDSeen || 0;
  const blocked = survival?.blocked || false;

  // Clignotement si phase 3
  useEffect(() => {
    if (phase === 3) {
      const t = setInterval(() => setBlink(b => !b), 600);
      return () => clearInterval(t);
    }
    setBlink(false);
  }, [phase]);

  const C = { card:'#12121a', border:'#1e1e2e', muted:'#64748b', text:'#e2e8f0' };

  return (
    <div style={{ background:C.card, border:`2px solid ${blink ? 'transparent' : info.color+'66'}`, borderRadius:'10px', padding:'16px', transition:'border-color 0.3s' }}>
      <div style={{ fontSize:'11px', color:C.muted, textTransform:'uppercase', letterSpacing:'0.08em', marginBottom:'12px' }}>Système de survie</div>

      {/* Indicateur principal */}
      <div style={{ display:'flex', alignItems:'center', gap:'12px', marginBottom:'14px', padding:'12px', borderRadius:'8px', background:`${info.color}11`, border:`1px solid ${info.color}33` }}>
        <span style={{ fontSize:'28px' }}>{info.icon}</span>
        <div>
          <div style={{ fontSize:'13px', fontWeight:700, color:info.color }}>{info.label}</div>
          <div style={{ fontSize:'11px', color:C.muted, marginTop:'2px' }}>{info.desc}</div>
        </div>
      </div>

      {/* Métriques */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:'8px', marginBottom:'10px' }}>
        {[
          { label:'Equity', value:`${account?.equity?.toFixed(2) || '0.00'}$`, color:C.text },
          { label:'Marge libre', value:`${account?.freeMargin?.toFixed(2) || '0.00'}$`, color:C.text },
          { label:'DD max vu', value:`${dd?.toFixed(1) || 0}%`, color: dd > 20 ? '#ef4444' : dd > 10 ? '#f59e0b' : '#22c55e' },
          { label:'Statut', value: blocked ? 'BLOQUÉ' : 'Actif', color: blocked ? '#ef4444' : '#22c55e' },
        ].map((m, i) => (
          <div key={i} style={{ padding:'8px 10px', background:'#0a0a0f', borderRadius:'6px' }}>
            <div style={{ fontSize:'10px', color:C.muted }}>{m.label}</div>
            <div style={{ fontSize:'13px', fontWeight:600, color:m.color }}>{m.value}</div>
          </div>
        ))}
      </div>

      {/* Seuils */}
      <div style={{ fontSize:'10px', color:C.muted, lineHeight:'1.6' }}>
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          <span>Phase 2 si DD ≥</span><span style={{ color:'#f59e0b' }}>15%</span>
        </div>
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          <span>Equity stop si DD ≥</span><span style={{ color:'#ef4444' }}>40%</span>
        </div>
        <div style={{ display:'flex', justifyContent:'space-between' }}>
          <span>Hedge ratio Phase 2</span><span>40% du lot cumulé</span>
        </div>
      </div>
    </div>
  );
}
