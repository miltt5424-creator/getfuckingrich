import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';

export default function EquityCurve({ data }) {
  if (!data || data.length < 2) {
    return <div style={{ height: '120px', display:'flex', alignItems:'center', justifyContent:'center', color:'#64748b', fontSize:'12px' }}>En attente de données...</div>;
  }

  const startEquity = data[0]?.equity || 1000;
  const minVal = Math.min(...data.map(d => d.equity)) * 0.999;
  const maxVal = Math.max(...data.map(d => d.equity)) * 1.001;

  const formatTime = (ts) => {
    const d = new Date(ts);
    return `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`;
  };

  const CustomTooltip = ({ active, payload }) => {
    if (!active || !payload?.length) return null;
    const val    = payload[0].value;
    const change = val - startEquity;
    return (
      <div style={{ background:'#12121a', border:'1px solid #1e1e2e', padding:'8px 12px', borderRadius:'6px', fontSize:'12px' }}>
        <div style={{ color:'#e2e8f0', fontWeight:600 }}>{val?.toFixed(2)}$</div>
        <div style={{ color: change >= 0 ? '#22c55e' : '#ef4444' }}>{change >= 0 ? '+' : ''}{change?.toFixed(2)}$</div>
      </div>
    );
  };

  return (
    <ResponsiveContainer width="100%" height={120}>
      <LineChart data={data} margin={{ top:4, right:4, bottom:0, left:0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1e1e2e" />
        <XAxis dataKey="ts" tickFormatter={formatTime} tick={{ fontSize:10, fill:'#64748b' }} tickLine={false} axisLine={false} interval="preserveStartEnd" />
        <YAxis domain={[minVal, maxVal]} tick={{ fontSize:10, fill:'#64748b' }} tickLine={false} axisLine={false} tickFormatter={v => v.toFixed(0)} width={50} />
        <Tooltip content={<CustomTooltip />} />
        <ReferenceLine y={startEquity} stroke="#64748b" strokeDasharray="4 4" />
        <Line type="monotone" dataKey="equity" stroke="#f59e0b" strokeWidth={2} dot={false} activeDot={{ r:4, fill:'#f59e0b' }} />
      </LineChart>
    </ResponsiveContainer>
  );
}
