import React from 'react';

const C = { green:'#22c55e', red:'#ef4444', amber:'#f59e0b', blue:'#3b82f6', muted:'#64748b', border:'#1e1e2e', card:'#12121a', text:'#e2e8f0' };

const phaseColor = { 1: C.green, 2: C.amber, 3: C.red };

export default function GridCard({ grid }) {
  const pnl      = grid.floatingPnL || 0;
  const phase    = grid.survivalPhase || 1;
  const pColor   = phaseColor[phase] || C.green;
  const dirColor = grid.direction === 'BUY' ? C.green : C.red;
  const pct      = grid.maxLevels > 0 ? (grid.level / grid.maxLevels) * 100 : 0;

  return (
    <div style={{ background:C.card, border:`1px solid ${pColor}44`, borderRadius:'10px', padding:'14px', position:'relative' }}>
      {/* Phase indicator */}
      <div style={{ position:'absolute', top:'10px', right:'10px', background:`${pColor}22`, color:pColor, border:`1px solid ${pColor}44`, borderRadius:'4px', padding:'2px 6px', fontSize:'10px', fontWeight:700 }}>
        Phase {phase}
      </div>

      {/* Header */}
      <div style={{ marginBottom:'10px' }}>
        <div style={{ fontSize:'14px', fontWeight:700, color:C.text }}>{grid.symbol}</div>
        <div style={{ fontSize:'11px', color:dirColor, fontWeight:600 }}>{grid.direction === 'BUY' ? '▲ BUY' : '▼ SELL'}</div>
      </div>

      {/* Niveaux */}
      <div style={{ marginBottom:'8px' }}>
        <div style={{ display:'flex', justifyContent:'space-between', fontSize:'11px', color:C.muted, marginBottom:'4px' }}>
          <span>Niveau {grid.level}/{grid.maxLevels}</span>
          <span>Lot: {grid.totalLot}</span>
        </div>
        <div style={{ background:'#1e1e2e', borderRadius:'4px', height:'6px', overflow:'hidden' }}>
          <div style={{ height:'6px', width:`${pct}%`, background: pct < 50 ? C.green : pct < 75 ? C.amber : C.red, borderRadius:'4px', transition:'width 0.3s' }} />
        </div>
      </div>

      {/* PnL */}
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center' }}>
        <div>
          <div style={{ fontSize:'10px', color:C.muted }}>PnL flottant</div>
          <div style={{ fontSize:'16px', fontWeight:700, color: pnl >= 0 ? C.green : C.red }}>{pnl >= 0 ? '+' : ''}{pnl.toFixed(2)}$</div>
        </div>
        <div style={{ textAlign:'right' }}>
          <div style={{ fontSize:'10px', color:C.muted }}>Score signal</div>
          <div style={{ fontSize:'14px', fontWeight:600, color:C.amber }}>{grid.signalScore}%</div>
        </div>
      </div>

      {/* Breakeven + TP */}
      <div style={{ marginTop:'8px', paddingTop:'8px', borderTop:`1px solid ${C.border}`, display:'flex', justifyContent:'space-between', fontSize:'10px', color:C.muted }}>
        <span>BE: {grid.breakeven?.toFixed(2) || '—'}</span>
        <span>TP: {grid.tpPrice?.toFixed(2) || '—'}</span>
        {grid.hedgeActive && <span style={{ color:C.blue }}>🔀 Hedgé</span>}
      </div>
    </div>
  );
}
