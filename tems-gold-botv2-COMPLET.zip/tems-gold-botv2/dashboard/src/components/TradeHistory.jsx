import React, { useState } from 'react';

const C = {
  green: '#22c55e', red: '#ef4444', amber: '#f59e0b',
  blue: '#3b82f6', muted: '#64748b', border: '#1e1e2e',
  card: '#12121a', text: '#e2e8f0', bg: '#0a0a0f',
};

function formatDuration(minutes) {
  if (!minutes) return '—';
  if (minutes < 60) return `${Math.round(minutes)}m`;
  const h = Math.floor(minutes / 60);
  const m = Math.round(minutes % 60);
  return `${h}h${m > 0 ? `${m}m` : ''}`;
}

function formatTime(date) {
  if (!date) return '—';
  const d = new Date(date);
  return `${d.getHours().toString().padStart(2,'0')}:${d.getMinutes().toString().padStart(2,'0')}`;
}

const FILTERS = ['Tous', 'BUY', 'SELL', 'TP Hit', 'Perte'];

export default function TradeHistory({ trades = [] }) {
  const [filter, setFilter]   = useState('Tous');
  const [sortBy, setSortBy]   = useState('time');
  const [page, setPage]       = useState(0);
  const PER_PAGE = 10;

  // Filtrage
  const filtered = trades.filter(t => {
    if (filter === 'BUY')    return t.direction === 'BUY';
    if (filter === 'SELL')   return t.direction === 'SELL';
    if (filter === 'TP Hit') return t.closeReason === 'TP_HIT';
    if (filter === 'Perte')  return (t.profit || 0) < 0;
    return true;
  });

  // Tri
  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'profit') return (b.profit || 0) - (a.profit || 0);
    if (sortBy === 'levels') return (b.level || 0) - (a.level || 0);
    return new Date(b.openTime || 0) - new Date(a.openTime || 0);
  });

  // Pagination
  const totalPages = Math.ceil(sorted.length / PER_PAGE);
  const paginated  = sorted.slice(page * PER_PAGE, (page + 1) * PER_PAGE);

  // Stats résumé
  const totalProfit = filtered.reduce((s, t) => s + (t.profit || 0), 0);
  const wins        = filtered.filter(t => (t.profit || 0) > 0).length;
  const winRate     = filtered.length > 0 ? (wins / filtered.length * 100).toFixed(1) : 0;
  const avgLevels   = filtered.length > 0
    ? (filtered.reduce((s, t) => s + (t.level || 1), 0) / filtered.length).toFixed(1)
    : 0;

  const btnStyle = (active) => ({
    padding: '4px 10px', borderRadius: '6px', fontSize: '11px', fontWeight: 500,
    cursor: 'pointer', border: `1px solid ${active ? C.amber : C.border}`,
    background: active ? `${C.amber}22` : 'transparent',
    color: active ? C.amber : C.muted,
  });

  const thStyle = {
    padding: '6px 10px', fontSize: '10px', color: C.muted,
    textTransform: 'uppercase', letterSpacing: '0.06em',
    textAlign: 'left', borderBottom: `1px solid ${C.border}`,
    cursor: 'pointer', userSelect: 'none',
  };

  const tdStyle = {
    padding: '8px 10px', fontSize: '12px',
    borderBottom: `1px solid ${C.border}22`,
  };

  return (
    <div style={{ background: C.card, border: `1px solid ${C.border}`, borderRadius: '10px', padding: '16px' }}>
      {/* Titre + résumé */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '12px' }}>
        <div style={{ fontSize: '11px', color: C.muted, textTransform: 'uppercase', letterSpacing: '0.08em' }}>
          Historique des trades ({filtered.length})
        </div>
        <div style={{ display: 'flex', gap: '16px', fontSize: '11px' }}>
          <span>
            Profit: <span style={{ color: totalProfit >= 0 ? C.green : C.red, fontWeight: 600 }}>
              {totalProfit >= 0 ? '+' : ''}{totalProfit.toFixed(2)}$
            </span>
          </span>
          <span>WR: <span style={{ color: parseFloat(winRate) >= 60 ? C.green : C.amber, fontWeight: 600 }}>{winRate}%</span></span>
          <span style={{ color: C.muted }}>Niv. moy: {avgLevels}</span>
        </div>
      </div>

      {/* Filtres */}
      <div style={{ display: 'flex', gap: '6px', marginBottom: '12px', flexWrap: 'wrap' }}>
        {FILTERS.map(f => (
          <button key={f} style={btnStyle(filter === f)} onClick={() => { setFilter(f); setPage(0); }}>
            {f}
          </button>
        ))}
        <div style={{ marginLeft: 'auto', display: 'flex', gap: '6px' }}>
          <span style={{ fontSize: '10px', color: C.muted, alignSelf: 'center' }}>Trier:</span>
          {[['time','Heure'],['profit','Profit'],['levels','Niveaux']].map(([key, label]) => (
            <button key={key} style={btnStyle(sortBy === key)} onClick={() => setSortBy(key)}>{label}</button>
          ))}
        </div>
      </div>

      {/* Tableau */}
      {paginated.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '24px', color: C.muted, fontSize: '13px' }}>
          Aucun trade{filter !== 'Tous' ? ` pour le filtre "${filter}"` : ''} pour le moment
        </div>
      ) : (
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {[
                  ['Heure','time'], ['Symbole',null], ['Dir.',null],
                  ['Niveaux','levels'], ['Durée',null], ['Profit','profit'],
                  ['Raison',null], ['Score',null],
                ].map(([label, key]) => (
                  <th key={label} style={thStyle} onClick={() => key && setSortBy(key)}>
                    {label}{sortBy === key ? ' ↓' : ''}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {paginated.map((trade, i) => {
                const profit  = trade.profit || 0;
                const isWin   = profit > 0;
                const dirColor = trade.direction === 'BUY' ? C.green : C.red;
                return (
                  <tr key={i} style={{ background: i % 2 === 0 ? 'transparent' : `${C.bg}88` }}>
                    <td style={tdStyle}>
                      <div style={{ color: C.text }}>{formatTime(trade.openTime)}</div>
                      <div style={{ fontSize: '10px', color: C.muted }}>{formatTime(trade.closeTime)}</div>
                    </td>
                    <td style={{ ...tdStyle, fontWeight: 600, color: C.text }}>{trade.symbol || '—'}</td>
                    <td style={tdStyle}>
                      <span style={{
                        color: dirColor, fontWeight: 700, fontSize: '11px',
                        background: `${dirColor}22`, padding: '2px 6px', borderRadius: '4px',
                      }}>
                        {trade.direction === 'BUY' ? '▲ BUY' : '▼ SELL'}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, textAlign: 'center' }}>
                      <span style={{
                        color: (trade.level || 0) >= 10 ? C.red : (trade.level || 0) >= 7 ? C.amber : C.green,
                        fontWeight: 600,
                      }}>
                        {trade.level || 1}/{trade.maxLevels || 15}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, color: C.muted }}>{formatDuration(trade.duration)}</td>
                    <td style={tdStyle}>
                      <span style={{ color: isWin ? C.green : C.red, fontWeight: 700 }}>
                        {profit >= 0 ? '+' : ''}{profit.toFixed(2)}$
                      </span>
                    </td>
                    <td style={tdStyle}>
                      <span style={{
                        fontSize: '10px', padding: '2px 6px', borderRadius: '4px',
                        background: trade.closeReason === 'TP_HIT' ? `${C.green}22` : `${C.red}22`,
                        color: trade.closeReason === 'TP_HIT' ? C.green : C.red,
                      }}>
                        {trade.closeReason === 'TP_HIT' ? '✅ TP' :
                         trade.closeReason === 'equity_stop' ? '🚨 Stop' :
                         trade.closeReason === 'Phase 3 — Equity stop' ? '🚨 DD' :
                         trade.closeReason || '—'}
                      </span>
                    </td>
                    <td style={{ ...tdStyle, color: C.amber }}>{trade.signalScore || '—'}%</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {/* Pagination */}
      {totalPages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '8px', marginTop: '12px' }}>
          <button
            style={{ ...btnStyle(false), opacity: page === 0 ? 0.4 : 1 }}
            onClick={() => setPage(p => Math.max(0, p - 1))}
            disabled={page === 0}
          >← Préc.</button>
          <span style={{ fontSize: '11px', color: C.muted }}>Page {page + 1} / {totalPages}</span>
          <button
            style={{ ...btnStyle(false), opacity: page >= totalPages - 1 ? 0.4 : 1 }}
            onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
            disabled={page >= totalPages - 1}
          >Suiv. →</button>
        </div>
      )}
    </div>
  );
}
