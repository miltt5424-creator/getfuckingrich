// setup-mt5-bridge.js — Guide interactif d'installation du bridge ZeroMQ dans MT5

console.log(`
╔══════════════════════════════════════════════════════════════╗
║        TEMS-GOLD-BOTV2 — Installation Bridge MT5             ║
║        DWX_ZeroMQ_Connector — Guide complet Windows          ║
╚══════════════════════════════════════════════════════════════╝

═══════════════════════════════════════════════════════════════
  ÉTAPE 1 : Télécharger le bridge ZeroMQ
═══════════════════════════════════════════════════════════════

  1. Ouvre ce lien dans ton navigateur :
     https://github.com/darwinex/dwx-zeromq-connector

  2. Clique sur le bouton vert "Code" → "Download ZIP"

  3. Décompresse le ZIP sur ton bureau


═══════════════════════════════════════════════════════════════
  ÉTAPE 2 : Préparer MetaTrader 5
═══════════════════════════════════════════════════════════════

  1. Ouvre MetaTrader 5

  2. Menu : Outils → Options → Expert Advisors
     ☑ Autoriser les DLL externes
     ☑ Autoriser les requêtes WebRequest pour les URL listées
     → Ajoute dans la liste : http://localhost

  3. Clique OK et redémarre MT5


═══════════════════════════════════════════════════════════════
  ÉTAPE 3 : Installer les fichiers dans MT5
═══════════════════════════════════════════════════════════════

  Dans MT5, menu : Fichier → Ouvrir le dossier des données
  (s'ouvre dans l'explorateur Windows)

  A. Copie ces fichiers du ZIP téléchargé :
     
     ZIP/MQL5/Experts/DWX_ZeroMQ_Connector_v2_0_1_RC8.ex5
     → Coller dans : [DossierMT5]/MQL5/Experts/

     ZIP/MQL5/Libraries/libzmq.dll
     ZIP/MQL5/Libraries/mql4zmq.dll
     → Coller dans : [DossierMT5]/MQL5/Libraries/

  B. Redémarre MT5 après la copie


═══════════════════════════════════════════════════════════════
  ÉTAPE 4 : Lancer le bridge sur un graphique
═══════════════════════════════════════════════════════════════

  1. Dans MT5, ouvre un graphique XAUUSD M1

  2. Dans le navigateur (F7) :
     Expert Advisors → DWX_ZeroMQ_Connector

  3. Fais glisser l'EA sur le graphique

  4. Dans les paramètres de l'EA :
     ✅ Laisser les valeurs par défaut (ports 32768/32769/32770)
     ✅ Clique OK

  5. En haut du graphique tu dois voir :
     "DWX_ZeroMQ_Connector: Connected"

  6. Dans l'onglet "Experts" de MT5, tu vois :
     "[INFO] ZeroMQ Connector started"
     "[INFO] PUSH port: 32768 | PULL port: 32769 | SUB port: 32770"


═══════════════════════════════════════════════════════════════
  ÉTAPE 5 : Vérifier la connexion
═══════════════════════════════════════════════════════════════

  Lance le bot en mode PAPER pour tester :

    BOT_MODE=paper node index.js

  Tu dois voir dans les logs :
    [Bridge] MT5Bridge connecté | localhost:32768/32769/32770

  Si tu vois une erreur de connexion :
    → Vérifie que MT5 est ouvert
    → Vérifie que l'EA est actif sur le graphique
    → Vérifie que les DLL sont autorisées (Étape 2)


═══════════════════════════════════════════════════════════════
  CONFIGURATION .env
═══════════════════════════════════════════════════════════════

  Dans ton fichier .env, configure :

    MT5_BRIDGE_HOST=localhost
    MT5_BRIDGE_PUSH_PORT=32768
    MT5_BRIDGE_PULL_PORT=32769
    MT5_BRIDGE_SUB_PORT=32770
    BOT_MODE=paper  ← TOUJOURS commencer en paper !

  Pour le Telegram (optionnel mais recommandé) :
    1. Ouvre Telegram, cherche @BotFather
    2. /newbot → suis les instructions → copie le TOKEN
    3. Cherche @userinfobot → envoie /start → copie ton Chat ID

    TELEGRAM_BOT_TOKEN=1234567890:ABCDEFghijklmNOPQRSTUVwxyz
    TELEGRAM_CHAT_ID=987654321


═══════════════════════════════════════════════════════════════
  PORTS UTILISÉS (Windows Firewall)
═══════════════════════════════════════════════════════════════

  Si le pare-feu Windows bloque la connexion :
  Panneau de configuration → Pare-feu Windows Defender
  → Règles de trafic entrant → Nouvelle règle
  → Type : Port → TCP → 32768,32769,32770 → Autoriser

═══════════════════════════════════════════════════════════════
`);

// Test de connexion optionnel
const args = process.argv.slice(2);
if (args.includes('--test')) {
  console.log('🔄 Test de connexion au bridge MT5...');
  import('../src/broker/mt5Bridge.js').then(async ({ MT5Bridge }) => {
    const { config } = await import('../src/utils/config.js');
    const bridge = new MT5Bridge(config);
    try {
      await bridge.connect();
      console.log('✅ Connexion réussie ! Le bridge MT5 est opérationnel.');
      const account = await bridge.getAccountInfo();
      console.log(`   Compte: Balance=${account.balance}$ | Equity=${account.equity}$ | Marge libre=${account.freeMargin}$`);
      await bridge.disconnect();
    } catch (err) {
      console.error(`❌ Connexion échouée: ${err.message}`);
      console.error('   Vérifie que MT5 est ouvert et le bridge démarré sur un graphique.');
    }
  }).catch(console.error);
}
