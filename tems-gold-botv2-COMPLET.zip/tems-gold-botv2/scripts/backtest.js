// backtest.js — Rejoue un historique CSV sur toute la logique du bot
// Usage: node scripts/backtest.js --symbol XAUUSD --file data/XAUUSD_M1.csv

import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { parse } from 'csv-parse/sync';
import 'dotenv/config';

const __dirname = dirname(fileURLToPath(import.meta.url));

// Arguments CLI
const args      = process.argv.slice(2);
const symbol    = args[args.indexOf('--symbol') + 1] || 'XAUUSD';
const filePath  = args[args.indexOf('--file')   + 1] || join(__dirname, `../data/${symbol}_M1.csv`);
const startLot  = parseFloat(args[args.indexOf('--lot')  + 1] || '0.01');
const mult      = parseFloat(args[args.indexOf('--mult')  + 1] || '1.5');
const maxLevels = parseInt(args[args.indexOf('--levels') + 1] || '15');
const minScore  = parseInt(args[args.indexOf('--score')  + 1] || '70');
const gridStepPips = parseFloat(args[args.indexOf('--step') + 1] || '15');

console.log('\n═══════════════════════════════════════════════════════');
console.log('  TEMS-GOLD-BOTV2 — Backtest Engine');
console.log(`  Symbole   : ${symbol}`);
console.log(`  Fichier   : ${filePath}`);
console.log(`  Lot init  : ${startLot} × ${mult} — max ${maxLevels} niveaux`);
console.log(`  Grid step : ${gridStepPips} pips`);
console.log('═══════════════════════════════════════════════════════\n');

// Chargement des données
let candles = [];
try {
  const raw = readFileSync(filePath, 'utf-8');
  const rows = parse(raw, { columns: true, skip_empty_lines: true });
  candles = rows.map(r => ({
    time:   new Date(r.time || r.date || r.Date),
    open:   parseFloat(r.open  || r.Open),
    high:   parseFloat(r.high  || r.High),
    low:    parseFloat(r.low   || r.Low),
    close:  parseFloat(r.close || r.Close),
    volume: parseFloat(r.volume || r.Volume || 1),
  })).filter(c => !isNaN(c.open));
  console.log(`✅ ${candles.length} bougies chargées`);
} catch (err) {
  console.error(`❌ Impossible de charger le fichier: ${err.message}`);
  console.error('Génère d\'abord les données avec: npm run download-data');
  process.exit(1);
}

if (candles.length < 100) {
  console.error('❌ Pas assez de données (minimum 100 bougies)');
  process.exit(1);
}

// ─── Simulation ──────────────────────────────────────────────

const PIP = 0.01; // XAUUSD
const PIP_VALUE = 1.0; // par lot par pip

let equity    = 1000;
let startEquity = 1000;
let peakEquity = 1000;
let totalProfit = 0;
let maxDD     = 0;

const grids   = [];
let openGrid  = null;

const stats = {
  gridsOpened: 0, gridsClosed: 0, tpHits: 0, losses: 0,
  totalProfit: 0, maxDD: 0, maxLevel: 0, avgDuration: 0,
  byMonth: {},
};

function calcLot(level) {
  return Math.round(startLot * Math.pow(mult, level - 1) * 100) / 100;
}

function calcFloatingPnL(grid, price) {
  return grid.positions.reduce((sum, pos) => {
    const pips = grid.direction === 'BUY' ? (price - pos.entry) / PIP : (pos.entry - price) / PIP;
    return sum + pips * PIP_VALUE * pos.lot;
  }, 0);
}

function simpleSignal(candles, idx) {
  if (idx < 50) return null;
  const slice = candles.slice(idx - 50, idx + 1);
  const closes = slice.map(c => c.close);

  // EMA simple
  const ema20 = closes.slice(-20).reduce((a,b) => a+b) / 20;
  const ema50 = closes.reduce((a,b) => a+b) / 50;

  // RSI simplifié
  let gains = 0, losses = 0;
  for (let i = 1; i < closes.length; i++) {
    const d = closes[i] - closes[i-1];
    if (d > 0) gains += d; else losses -= d;
  }
  const rs  = losses > 0 ? gains / losses : 100;
  const rsi = 100 - 100 / (1 + rs);

  // ATR
  const atrSlice = slice.slice(-14);
  const atr = atrSlice.reduce((s, c, i) => {
    if (i === 0) return s;
    return s + Math.max(c.high - c.low, Math.abs(c.high - atrSlice[i-1].close), Math.abs(c.low - atrSlice[i-1].close));
  }, 0) / 13;

  // Signal basique (score simulé)
  const score = Math.random() * 30 + 65; // 65-95% simulé

  if (score < minScore) return null;

  const price = candles[idx].close;
  const direction = ema20 > ema50 && rsi < 60 ? 'BUY' : ema20 < ema50 && rsi > 40 ? 'SELL' : null;
  if (!direction) return null;

  return { direction, score, entryPrice: price, gridStep: atr * 1.2, atr };
}

// ─── Boucle principale de backtest ───────────────────────────

console.log('🔄 Simulation en cours...\n');

for (let i = 50; i < candles.length; i++) {
  const candle  = candles[i];
  const price   = candle.close;
  const month   = candle.time.toISOString().slice(0, 7);

  // Mise à jour equity/drawdown
  if (!stats.byMonth[month]) stats.byMonth[month] = { profit: 0, trades: 0 };
  if (equity > peakEquity) peakEquity = equity;
  const dd = ((peakEquity - equity) / peakEquity) * 100;
  if (dd > maxDD) maxDD = dd;

  // Gérer la grille ouverte
  if (openGrid) {
    const pnl = calcFloatingPnL(openGrid, price);

    // Vérifier TP
    const tp = openGrid.tpPrice;
    const tpReached = openGrid.direction === 'BUY' ? price >= tp : price <= tp;

    if (tpReached && pnl > 0) {
      // Fermer en TP
      equity += pnl;
      totalProfit += pnl;
      stats.tpHits++;
      stats.gridsClosed++;
      stats.byMonth[month].profit += pnl;
      stats.byMonth[month].trades++;
      const dur = i - openGrid.openIdx;
      stats.avgDuration = (stats.avgDuration * (stats.gridsClosed - 1) + dur) / stats.gridsClosed;

      process.stdout.write(`  ✅ TP ${openGrid.direction} ${openGrid.positions.length} niveaux | +${pnl.toFixed(2)}$ | Equity: ${equity.toFixed(2)}$\n`);
      openGrid = null;
      continue;
    }

    // Vérifier equity stop
    if (dd > 40) {
      equity += pnl;
      totalProfit += pnl;
      stats.losses++;
      stats.gridsClosed++;
      stats.byMonth[month].profit += pnl;
      process.stdout.write(`  🚨 EQUITY STOP | ${pnl.toFixed(2)}$ | Equity: ${equity.toFixed(2)}$\n`);
      openGrid = null;
      continue;
    }

    // Ouvrir niveaux supplémentaires
    const lastEntry = openGrid.positions[openGrid.positions.length - 1].entry;
    const nextLevelPrice = openGrid.direction === 'BUY'
      ? lastEntry - openGrid.gridStep
      : lastEntry + openGrid.gridStep;

    const shouldAdd = openGrid.direction === 'BUY' ? price <= nextLevelPrice : price >= nextLevelPrice;

    if (shouldAdd && openGrid.positions.length < maxLevels) {
      const level = openGrid.positions.length + 1;
      const lot   = calcLot(level);
      openGrid.positions.push({ entry: price, lot, level });
      if (level > stats.maxLevel) stats.maxLevel = level;

      // Recalculer breakeven et TP
      const totalLot   = openGrid.positions.reduce((s,p) => s+p.lot, 0);
      const breakeven  = openGrid.positions.reduce((s,p) => s + p.entry * p.lot, 0) / totalLot;
      const phase      = level >= 7 ? 2 : 1;
      const tpMult     = phase === 2 ? 3.0 : 1.5;
      openGrid.tpPrice = openGrid.direction === 'BUY'
        ? breakeven + openGrid.atr * tpMult
        : breakeven - openGrid.atr * tpMult;
    }
  } else {
    // Chercher un nouveau signal
    const sig = simpleSignal(candles, i);
    if (sig) {
      const gridStep = sig.gridStep || gridStepPips * PIP;
      const tp = sig.direction === 'BUY'
        ? sig.entryPrice + sig.atr * 1.5
        : sig.entryPrice - sig.atr * 1.5;

      openGrid = {
        direction: sig.direction,
        positions: [{ entry: sig.entryPrice, lot: calcLot(1), level: 1 }],
        gridStep, atr: sig.atr, tpPrice: tp, openIdx: i,
      };
      stats.gridsOpened++;
    }
  }
}

// ─── Résultats ───────────────────────────────────────────────

console.log('\n═══════════════════════════════════════════════════════');
console.log('  RÉSULTATS DU BACKTEST');
console.log('═══════════════════════════════════════════════════════');
console.log(`  Capital initial : ${startEquity.toFixed(2)}$`);
console.log(`  Capital final   : ${equity.toFixed(2)}$`);
console.log(`  Profit net      : ${(equity - startEquity).toFixed(2)}$ (${((equity - startEquity) / startEquity * 100).toFixed(1)}%)`);
console.log(`  Grilles ouvertes: ${stats.gridsOpened}`);
console.log(`  Grilles fermées : ${stats.gridsClosed}`);
console.log(`  TP réussis      : ${stats.tpHits}`);
console.log(`  Pertes          : ${stats.losses}`);
console.log(`  Win rate        : ${stats.gridsClosed ? (stats.tpHits / stats.gridsClosed * 100).toFixed(1) : 0}%`);
console.log(`  DD max          : ${maxDD.toFixed(1)}%`);
console.log(`  Niveau max      : ${stats.maxLevel}`);
console.log(`  Durée moy       : ${stats.avgDuration.toFixed(0)} bougies`);

console.log('\n  Par mois:');
for (const [month, data] of Object.entries(stats.byMonth).sort()) {
  if (data.trades > 0) {
    console.log(`    ${month}: ${data.profit >= 0 ? '+' : ''}${data.profit.toFixed(2)}$ (${data.trades} trades)`);
  }
}
console.log('═══════════════════════════════════════════════════════\n');
