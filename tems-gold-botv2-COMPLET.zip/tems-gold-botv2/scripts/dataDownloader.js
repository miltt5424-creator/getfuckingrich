// dataDownloader.js — Télécharge l'historique depuis MT5 pour le backtest
// Usage: node scripts/dataDownloader.js --symbol XAUUSD --tf M1 --bars 5000

import { writeFileSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';

const __dirname = dirname(fileURLToPath(import.meta.url));

const args   = process.argv.slice(2);
const symbol = args[args.indexOf('--symbol') + 1] || 'XAUUSD';
const tf     = args[args.indexOf('--tf')     + 1] || 'M1';
const bars   = parseInt(args[args.indexOf('--bars') + 1] || '5000');

console.log(`\n📥 Téléchargement ${symbol} ${tf} — ${bars} bougies depuis MT5...\n`);

async function download() {
  try {
    const { MT5Bridge } = await import('../src/broker/mt5Bridge.js');
    const { config }    = await import('../src/utils/config.js');

    const bridge = new MT5Bridge(config);
    await bridge.connect();

    console.log('✅ Bridge MT5 connecté');
    console.log(`🔄 Récupération de ${bars} bougies ${symbol} ${tf}...`);

    const candles = await bridge.getCandles(symbol, tf, bars);
    if (!candles.length) throw new Error('Aucune bougie retournée');

    // Créer le dossier data/
    const dataDir = join(__dirname, '../data');
    mkdirSync(dataDir, { recursive: true });

    // Exporter en CSV
    const filename = join(dataDir, `${symbol}_${tf}.csv`);
    const header   = 'time,open,high,low,close,volume';
    const rows     = candles.map(c =>
      `${c.time instanceof Date ? c.time.toISOString() : c.time},${c.open},${c.high},${c.low},${c.close},${c.volume || 1}`
    );

    writeFileSync(filename, [header, ...rows].join('\n'));

    console.log(`✅ ${candles.length} bougies exportées → ${filename}`);
    console.log(`   Période: ${candles[0].time} → ${candles[candles.length-1].time}`);

    await bridge.disconnect();
  } catch (err) {
    console.error(`❌ Erreur: ${err.message}`);
    console.error('Vérifie que MT5 est ouvert et le bridge ZeroMQ démarré.');

    // Générer des données de test si bridge non disponible
    console.log('\n🔄 Génération de données simulées pour test...');
    const dataDir = join(__dirname, '../data');
    mkdirSync(dataDir, { recursive: true });

    const fakeCandles = generateFakeData(symbol, bars);
    const filename    = join(dataDir, `${symbol}_${tf}.csv`);
    const rows        = fakeCandles.map(c =>
      `${c.time.toISOString()},${c.open.toFixed(2)},${c.high.toFixed(2)},${c.low.toFixed(2)},${c.close.toFixed(2)},${c.volume}`
    );
    writeFileSync(filename, ['time,open,high,low,close,volume', ...rows].join('\n'));
    console.log(`✅ ${fakeCandles.length} bougies simulées → ${filename}`);
  }
}

function generateFakeData(symbol, count) {
  const basePrice = symbol === 'XAUUSD' ? 4650 : symbol === 'EURUSD' ? 1.0850 : 1.2650;
  const volatility = symbol === 'XAUUSD' ? 0.005 : 0.0002;
  const candles  = [];
  let price      = basePrice;
  const now      = Date.now() - count * 60000;

  for (let i = 0; i < count; i++) {
    const change  = (Math.random() - 0.5) * basePrice * volatility;
    const open    = price;
    const close   = price + change;
    const high    = Math.max(open, close) + Math.abs(change) * Math.random() * 0.5;
    const low     = Math.min(open, close) - Math.abs(change) * Math.random() * 0.5;
    candles.push({ time: new Date(now + i * 60000), open, high, low, close, volume: Math.floor(Math.random() * 1000 + 200) });
    price = close;
  }
  return candles;
}

download();
