// optimize.js — Optimisation des paramètres par brute-force
// Teste toutes les combinaisons mult × step × score_min et trouve le meilleur réglage
// Usage: node scripts/optimize.js --symbol XAUUSD --file data/XAUUSD_M1.csv

import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { parse } from 'csv-parse/sync';

const __dirname = dirname(fileURLToPath(import.meta.url));

const args    = process.argv.slice(2);
const symbol  = args[args.indexOf('--symbol') + 1] || 'XAUUSD';
const file    = args[args.indexOf('--file')   + 1] || join(__dirname, `../data/${symbol}_M1.csv`);

console.log('\n═══════════════════════════════════════════════════════');
console.log('  TEMS-GOLD-BOTV2 — Optimiseur de paramètres');
console.log(`  Symbole : ${symbol}`);
console.log('═══════════════════════════════════════════════════════\n');

let candles = [];
try {
  const raw  = readFileSync(file, 'utf-8');
  const rows = parse(raw, { columns: true, skip_empty_lines: true });
  candles = rows.map(r => ({
    time:  new Date(r.time || r.date || r.Date),
    open:  parseFloat(r.open  || r.Open),
    high:  parseFloat(r.high  || r.High),
    low:   parseFloat(r.low   || r.Low),
    close: parseFloat(r.close || r.Close),
  })).filter(c => !isNaN(c.open));
  console.log(`✅ ${candles.length} bougies chargées\n`);
} catch (e) {
  console.error(`❌ ${e.message}`); process.exit(1);
}

// Grille des paramètres à tester
const MULTIPLIERS = [1.3, 1.5, 1.7, 2.0];
const ATR_MULTS   = [0.8, 1.0, 1.2, 1.5, 2.0];
const TP_MULTS    = [1.0, 1.5, 2.0, 3.0];
const MAX_LEVELS  = [8, 10, 12, 15];

const PIP = 0.01;
const total = MULTIPLIERS.length * ATR_MULTS.length * TP_MULTS.length * MAX_LEVELS.length;
console.log(`🔄 Test de ${total} combinaisons...\n`);

function simulateFast(candles, mult, atrMult, tpMult, maxLev) {
  let equity = 1000, peak = 1000, maxDD = 0;
  let wins = 0, losses = 0, open = null;

  function lot(level) { return Math.round(0.01 * Math.pow(mult, level - 1) * 100) / 100; }
  function atr(idx) {
    const sl = candles.slice(Math.max(0, idx - 14), idx + 1);
    return sl.reduce((s, c, i) => i === 0 ? s : s + (c.high - c.low), 0) / Math.max(1, sl.length - 1);
  }

  for (let i = 50; i < candles.length; i++) {
    const price = candles[i].close;
    if (equity > peak) peak = equity;
    const dd = (peak - equity) / peak * 100;
    if (dd > maxDD) maxDD = dd;
    if (dd > 40) { if (open) { losses++; open = null; } continue; }

    if (open) {
      const pnl = open.positions.reduce((s, p) => {
        const pips = open.dir === 'BUY' ? (price - p.e) / PIP : (p.e - price) / PIP;
        return s + pips * p.l;
      }, 0);

      const reached = open.dir === 'BUY' ? price >= open.tp : price <= open.tp;
      if (reached && pnl > 0) { equity += pnl; wins++; open = null; continue; }

      const last = open.positions[open.positions.length - 1];
      const next = open.dir === 'BUY' ? last.e - open.step : last.e + open.step;
      const addLevel = open.dir === 'BUY' ? price <= next : price >= next;

      if (addLevel && open.positions.length < maxLev) {
        const lv = open.positions.length + 1;
        open.positions.push({ e: price, l: lot(lv) });
        const tl = open.positions.reduce((s,p) => s+p.l, 0);
        const be = open.positions.reduce((s,p) => s+p.e*p.l, 0) / tl;
        const a  = atr(i);
        open.tp = open.dir === 'BUY' ? be + a * tpMult : be - a * tpMult;
        open.step = a * atrMult;
      }
    } else if (i % 20 === 0) { // Signal simplifié toutes les 20 bougies
      const sl = candles.slice(i - 20, i + 1);
      const c20 = sl.reduce((s,c) => s+c.close, 0) / sl.length;
      const dir = price > c20 ? 'BUY' : 'SELL';
      const a   = atr(i);
      const step = a * atrMult;
      const tp   = dir === 'BUY' ? price + a * tpMult : price - a * tpMult;
      open = { dir, tp, step, positions: [{ e: price, l: lot(1) }] };
    }
  }

  const total = wins + losses;
  return {
    equity, profit: equity - 1000,
    winRate: total > 0 ? wins / total * 100 : 0,
    maxDD, trades: total,
    score: (equity - 1000) / 10 - maxDD * 2 + (total > 0 ? wins / total * 30 : 0),
  };
}

// Lancement des tests
const results = [];
let done = 0;

for (const m of MULTIPLIERS) {
  for (const a of ATR_MULTS) {
    for (const t of TP_MULTS) {
      for (const l of MAX_LEVELS) {
        const res = simulateFast(candles, m, a, t, l);
        results.push({ mult: m, atrMult: a, tpMult: t, maxLev: l, ...res });
        done++;
        if (done % 20 === 0) process.stdout.write(`\r  Progression: ${done}/${total} (${(done/total*100).toFixed(0)}%)`);
      }
    }
  }
}

// Tri par score combiné (profit - pénalité DD + winRate)
results.sort((a, b) => b.score - a.score);

console.log('\n\n═══════════════════════════════════════════════════════');
console.log('  TOP 10 MEILLEURES COMBINAISONS');
console.log('  (classées par score = profit - DD*2 + winRate)');
console.log('═══════════════════════════════════════════════════════');
console.log('  Mult  | AtrM | TpM  | MaxLv | Profit     | WinRate | MaxDD  | Score');
console.log('  ───────────────────────────────────────────────────────────────────');

for (const r of results.slice(0, 10)) {
  const profit = (r.profit >= 0 ? '+' : '') + r.profit.toFixed(2).padStart(8);
  console.log(
    `  ${r.mult.toFixed(1).padEnd(5)} | ${r.atrMult.toFixed(1).padEnd(4)} | ${r.tpMult.toFixed(1).padEnd(4)} | ${String(r.maxLev).padEnd(5)} | ${profit}$ | ${r.winRate.toFixed(1).padStart(6)}% | ${r.maxDD.toFixed(1).padStart(5)}% | ${r.score.toFixed(1)}`
  );
}

const best = results[0];
console.log('\n═══════════════════════════════════════════════════════');
console.log('  🏆 MEILLEURE COMBINAISON RECOMMANDÉE:');
console.log(`    lot_multiplier      : ${best.mult}`);
console.log(`    grid_step_atr_mult  : ${best.atrMult}`);
console.log(`    tp_atr_mult_phase1  : ${best.tpMult}`);
console.log(`    max_levels          : ${best.maxLev}`);
console.log(`    → Profit: +${best.profit.toFixed(2)}$ | WinRate: ${best.winRate.toFixed(1)}% | MaxDD: ${best.maxDD.toFixed(1)}%`);
console.log('\n  Copiez ces valeurs dans config/params.json');
console.log('═══════════════════════════════════════════════════════\n');
