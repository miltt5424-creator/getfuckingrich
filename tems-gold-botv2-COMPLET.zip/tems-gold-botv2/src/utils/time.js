import { format, parseISO, isWithinInterval, addMinutes, subMinutes } from 'date-fns';
import config from './config.js';

export function nowUTC() { return new Date(); }
export function formatDate(d) { return format(d, 'yyyy-MM-dd HH:mm:ss'); }

export function getCurrentHourUTC() { return new Date().getUTCHours(); }
export function getCurrentMinuteUTC() { return new Date().getUTCMinutes(); }

export function isSessionActive(sessionName) {
  const session = config.sessions?.[sessionName];
  if (!session || !session.trade) return false;
  const [startH, startM] = session.start.split(':').map(Number);
  const [endH,   endM]   = session.end.split(':').map(Number);
  const now = new Date();
  const h = now.getUTCHours(), m = now.getUTCMinutes();
  const nowMins   = h * 60 + m;
  const startMins = startH * 60 + startM;
  const endMins   = endH   * 60 + endM;
  return nowMins >= startMins && nowMins < endMins;
}

export function isAnyTradingSessionActive() {
  return ['london', 'ny'].some(s => isSessionActive(s));
}

export function isWeekend() {
  const day = new Date().getUTCDay();
  return day === 0 || day === 6;
}

export function isNewsBlackout(newsEvents) {
  const now = new Date();
  const pauseBefore = config.news_filter?.pause_before_minutes || 30;
  const pauseAfter  = config.news_filter?.pause_after_minutes  || 30;
  const impactLevels = config.news_filter?.impact_levels || ['high'];

  for (const event of newsEvents) {
    if (!impactLevels.includes(event.impact)) continue;
    const eventTime = typeof event.date === 'string' ? parseISO(event.date) : event.date;
    const start = subMinutes(eventTime, pauseBefore);
    const end   = addMinutes(eventTime, pauseAfter);
    if (isWithinInterval(now, { start, end })) return { blocked: true, event };
  }
  return { blocked: false, event: null };
}

export function minutesUntilNextNews(newsEvents) {
  const now = new Date();
  const future = newsEvents
    .filter(e => new Date(e.date) > now)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  if (!future.length) return Infinity;
  return Math.floor((new Date(future[0].date) - now) / 60000);
}

export function isDailyReportTime() {
  const hour = config.telegram?.daily_report_hour ?? 22;
  const h = getCurrentHourUTC();
  const m = getCurrentMinuteUTC();
  return h === hour && m === 0;
}

export function msUntilNextMinute() {
  const now = new Date();
  return 60000 - (now.getSeconds() * 1000 + now.getMilliseconds());
}
