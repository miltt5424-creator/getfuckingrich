// ============================================================
//  math.js — Fonctions de calcul trading (pips, lots, profit)
// ============================================================

export function round(value, decimals = 5) {
  return Math.round(value * 10 ** decimals) / 10 ** decimals;
}

export function priceToPips(priceDiff, symbolSpec) {
  return Math.abs(priceDiff) / symbolSpec.pip;
}

export function pipsToPriceDistance(pips, symbolSpec) {
  return pips * symbolSpec.pip;
}

export function calcLot(initialLot, multiplier, level) {
  const lot = initialLot * Math.pow(multiplier, level - 1);
  return round(lot, 2);
}

export function calcGridLots(initialLot, multiplier, levels) {
  return Array.from({ length: levels }, (_, i) => calcLot(initialLot, multiplier, i + 1));
}

export function calcCumulativeLot(initialLot, multiplier, levels) {
  return calcGridLots(initialLot, multiplier, levels).reduce((a, b) => round(a + b, 2), 0);
}

export function calcBreakeven(positions) {
  if (!positions.length) return 0;
  const totalLot = positions.reduce((s, p) => s + p.lot, 0);
  const weightedSum = positions.reduce((s, p) => s + p.entryPrice * p.lot, 0);
  return round(weightedSum / totalLot, 5);
}

export function calcFloatingProfit(positions, currentPrice, symbolSpec) {
  return positions.reduce((total, pos) => {
    const priceDiff = pos.direction === 'BUY'
      ? currentPrice - pos.entryPrice
      : pos.entryPrice - currentPrice;
    const profit = priceDiff / symbolSpec.pip * symbolSpec.pip_value_per_lot * pos.lot;
    return total + profit;
  }, 0);
}

export function calcDrawdownPct(peakEquity, currentEquity) {
  if (!peakEquity || peakEquity <= 0) return 0;
  return round(((peakEquity - currentEquity) / peakEquity) * 100, 2);
}

export function calcRequiredMargin(lot, price, marginPct) {
  return round((lot * price * marginPct) / 100, 2);
}

export function calcMaxLevelsForCapital(capital, initialLot, multiplier, price, marginPct) {
  let totalMargin = 0;
  let level = 0;
  while (totalMargin < capital * 0.8) {
    level++;
    const lot = calcLot(initialLot, multiplier, level);
    totalMargin += calcRequiredMargin(lot, price, marginPct);
    if (level > 50) break;
  }
  return level - 1;
}

export function normalizeScore(value, min, max) {
  if (max === min) return 50;
  return round(Math.max(0, Math.min(100, ((value - min) / (max - min)) * 100)), 2);
}

export function weightedAverage(scores) {
  const totalWeight = scores.reduce((s, item) => s + item.weight, 0);
  if (!totalWeight) return 0;
  const weightedSum = scores.reduce((s, item) => s + item.score * item.weight, 0);
  return round(weightedSum / totalWeight, 2);
}

export function calcATRGridStep(atr, multiplier) {
  return round(atr * multiplier, 5);
}

export function calcFibonacciLevels(high, low) {
  const diff = high - low;
  return {
    r_236:  round(high - diff * 0.236, 5),
    r_382:  round(high - diff * 0.382, 5),
    r_500:  round(high - diff * 0.500, 5),
    r_618:  round(high - diff * 0.618, 5),
    r_786:  round(high - diff * 0.786, 5),
    e_1272: round(low  - diff * 0.272, 5),
    e_1618: round(low  - diff * 0.618, 5),
    e_200:  round(low  - diff * 1.000, 5),
  };
}

export function calcPivotPoints(high, low, close) {
  const pp = round((high + low + close) / 3, 5);
  return {
    pp,
    r1: round(2 * pp - low,  5), r2: round(pp + (high - low), 5), r3: round(high + 2 * (pp - low), 5),
    s1: round(2 * pp - high, 5), s2: round(pp - (high - low), 5), s3: round(low  - 2 * (high - pp), 5),
  };
}

export function isNearLevel(price, level, tolerancePips, symbolSpec) {
  return Math.abs(price - level) <= pipsToPriceDistance(tolerancePips, symbolSpec);
}

export function calcPercentChange(from, to) {
  if (!from) return 0;
  return round(((to - from) / from) * 100, 4);
}

export function stdDev(values) {
  const n = values.length;
  if (n < 2) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / n;
  const variance = values.reduce((s, v) => s + Math.pow(v - mean, 2), 0) / n;
  return Math.sqrt(variance);
}

export function sma(values, period) {
  if (values.length < period) return null;
  const slice = values.slice(-period);
  return round(slice.reduce((a, b) => a + b, 0) / period, 5);
}

export function ema(values, period) {
  if (values.length < period) return null;
  const k = 2 / (period + 1);
  let emaVal = values.slice(0, period).reduce((a, b) => a + b, 0) / period;
  for (let i = period; i < values.length; i++) {
    emaVal = values[i] * k + emaVal * (1 - k);
  }
  return round(emaVal, 5);
}

export function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}
