import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import 'dotenv/config';

const __dirname = dirname(fileURLToPath(import.meta.url));
const ROOT = join(__dirname, '../..');

function loadJSON(path) {
  return JSON.parse(readFileSync(join(ROOT, path), 'utf-8'));
}

function validateEnv() {
  const mode = process.env.BOT_MODE || 'paper';
  if (mode === 'live') {
    const required = ['MT5_BRIDGE_HOST','MT5_BRIDGE_PUSH_PORT','MT5_BRIDGE_PULL_PORT','TELEGRAM_BOT_TOKEN','TELEGRAM_CHAT_ID'];
    const missing = required.filter(k => !process.env[k]);
    if (missing.length) throw new Error(`Variables .env manquantes pour le mode LIVE : ${missing.join(', ')}`);
  }
}

function loadConfig() {
  validateEnv();
  const params  = loadJSON('config/params.json');
  const symbols = loadJSON('config/symbols.json');

  return {
    ...params,
    symbols_specs: symbols,
    env: {
      mode:              process.env.BOT_MODE || 'paper',
      nodeEnv:           process.env.NODE_ENV || 'development',
      mt5Host:           process.env.MT5_BRIDGE_HOST || 'localhost',
      mt5PushPort:       parseInt(process.env.MT5_BRIDGE_PUSH_PORT) || 32768,
      mt5PullPort:       parseInt(process.env.MT5_BRIDGE_PULL_PORT) || 32769,
      mt5SubPort:        parseInt(process.env.MT5_BRIDGE_SUB_PORT)  || 32770,
      telegramToken:     process.env.TELEGRAM_BOT_TOKEN || '',
      telegramChatId:    process.env.TELEGRAM_CHAT_ID || '',
      dashboardPort:     parseInt(process.env.DASHBOARD_PORT) || 3001,
      dashboardWsPort:   parseInt(process.env.DASHBOARD_WS_PORT) || 3002,
      forexFactoryUrl:   process.env.FOREX_FACTORY_API || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json',
      alphaVantageKey:   process.env.ALPHA_VANTAGE_KEY || '',
    },
    isLive:  (process.env.BOT_MODE || 'paper') === 'live',
    isPaper: (process.env.BOT_MODE || 'paper') === 'paper',
    isDev:   (process.env.NODE_ENV || 'development') === 'development',

    getSymbol(name) {
      return this.symbols_specs[name] || null;
    },
    getEnabledSymbols() {
      return (params.symbols || []).filter(s => s.enabled);
    },
    getFilterWeight(category, filter) {
      return this.filters?.[category]?.[filter]?.weight || 0;
    },
    isFilterEnabled(category, filter) {
      return this.filters?.[category]?.[filter]?.enabled !== false;
    }
  };
}

export const config = loadConfig();
export default config;
