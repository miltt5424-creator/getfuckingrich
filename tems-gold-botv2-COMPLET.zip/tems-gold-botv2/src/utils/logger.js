import { createLogger, format, transports } from 'winston';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { mkdirSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const LOG_DIR = join(__dirname, '../../logs');
mkdirSync(LOG_DIR, { recursive: true });

const fmt = format.combine(
  format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  format.errors({ stack: true }),
  format.printf(({ timestamp, level, message, ...meta }) => {
    const m = Object.keys(meta).length ? ' | ' + JSON.stringify(meta) : '';
    return `[${timestamp}] ${level.toUpperCase().padEnd(5)} ${message}${m}`;
  })
);

const logger = createLogger({
  level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
  format: fmt,
  transports: [
    new transports.Console({ format: format.combine(format.colorize(), fmt) }),
    new transports.File({ filename: join(LOG_DIR, 'bot.log'),     maxsize: 10485760, maxFiles: 5 }),
    new transports.File({ filename: join(LOG_DIR, 'errors.log'),  maxsize: 5242880,  maxFiles: 5, level: 'error' }),
    new transports.File({ filename: join(LOG_DIR, 'trades.log'),  maxsize: 10485760, maxFiles: 10 }),
    new transports.File({ filename: join(LOG_DIR, 'signals.log'), maxsize: 10485760, maxFiles: 5 }),
  ],
});

logger.trade  = (msg, meta = {}) => logger.info(`[TRADE]  ${msg}`, meta);
logger.signal = (msg, meta = {}) => logger.info(`[SIGNAL] ${msg}`, meta);
logger.risk   = (msg, meta = {}) => logger.warn(`[RISK]   ${msg}`, meta);
logger.bridge = (msg, meta = {}) => logger.debug(`[BRIDGE] ${msg}`, meta);

export default logger;
