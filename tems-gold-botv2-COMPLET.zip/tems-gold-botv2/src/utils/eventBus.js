import EventEmitter from 'eventemitter3';

class EventBus extends EventEmitter {
  constructor() {
    super();
    this._history = [];
  }

  emit(event, data) {
    this._history.push({ event, data, ts: Date.now() });
    if (this._history.length > 1000) this._history.shift();
    return super.emit(event, data);
  }

  getHistory(event, limit = 50) {
    return this._history
      .filter(h => h.event === event)
      .slice(-limit);
  }
}

export const bus = new EventBus();

// Événements émis dans le bot
export const EVENTS = {
  CANDLE_CLOSED:     'candle:closed',
  TICK_RECEIVED:     'tick:received',
  SIGNAL_GENERATED:  'signal:generated',
  GRID_OPENED:       'grid:opened',
  GRID_LEVEL_ADDED:  'grid:level_added',
  GRID_TP_HIT:       'grid:tp_hit',
  GRID_CLOSED:       'grid:closed',
  PHASE_CHANGED:     'survival:phase_changed',
  HEDGE_OPENED:      'survival:hedge_opened',
  EQUITY_STOP:       'survival:equity_stop',
  EQUITY_UPDATED:    'account:equity_updated',
  BRIDGE_CONNECTED:  'bridge:connected',
  BRIDGE_DISCONNECTED:'bridge:disconnected',
  ORDER_SENT:        'order:sent',
  ORDER_CONFIRMED:   'order:confirmed',
  ORDER_ERROR:       'order:error',
  DAILY_REPORT:      'notify:daily_report',
};

export default bus;
