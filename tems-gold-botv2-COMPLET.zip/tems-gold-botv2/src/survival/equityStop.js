import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class EquityStop {
  constructor(config, broker, notifier) {
    this.cfg      = config;
    this.broker   = broker;
    this.notifier = notifier;
    this.triggered = false;
    this.triggerTime = null;
    this.triggerEquity = null;
    this.triggerReason = null;
  }

  async trigger(equity, reason) {
    if (this.triggered) return;
    this.triggered     = true;
    this.triggerTime   = new Date();
    this.triggerEquity = equity;
    this.triggerReason = reason;

    logger.risk(`[EquityStop] ⛔ DÉCLENCHÉ | Equity: ${equity}$ | Raison: ${reason}`);

    // Fermer toutes les positions ouvertes sur MT5
    if (!this.cfg.isPaper) {
      try {
        const positions = await this.broker.getAllOpenPositions();
        logger.risk(`[EquityStop] Fermeture de ${positions.length} position(s)...`);
        for (const pos of positions) {
          try {
            await this.broker.closeOrder(pos.ticket);
            logger.trade(`[EquityStop] Fermé ticket=${pos.ticket}`);
          } catch (e) {
            logger.error(`[EquityStop] Impossible de fermer ${pos.ticket}: ${e.message}`);
          }
        }
      } catch (e) {
        logger.error(`[EquityStop] Erreur récupération positions: ${e.message}`);
      }
    } else {
      logger.trade('[PAPER] Toutes les positions fermées par equity stop');
    }

    bus.emit(EVENTS.EQUITY_STOP, { equity, reason, time: this.triggerTime });

    // Alerte Telegram urgente
    if (this.notifier) {
      await this.notifier.notifyEquityStop(equity, reason, this.triggerTime);
    }

    logger.risk('[EquityStop] Bot arrêté. Redémarrage manuel requis.');
  }

  isTriggered() { return this.triggered; }

  reset() {
    this.triggered = false;
    logger.info('[EquityStop] Reset manuel effectué');
  }

  getReport() {
    return {
      triggered:     this.triggered,
      triggerTime:   this.triggerTime,
      triggerEquity: this.triggerEquity,
      triggerReason: this.triggerReason,
    };
  }
}
