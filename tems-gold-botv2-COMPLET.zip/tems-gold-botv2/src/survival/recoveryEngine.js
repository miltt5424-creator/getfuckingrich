// recoveryEngine.js — Analyse les conditions pour reprendre après un equity stop

import logger from '../utils/logger.js';

export class RecoveryEngine {
  constructor(config, survivalSystem, notifier) {
    this.cfg      = config;
    this.survival = survivalSystem;
    this.notifier = notifier;
    this.recoveryStartTime = null;
  }

  // Démarre le processus de récupération (déclenché après un equity stop)
  startRecovery() {
    this.recoveryStartTime = new Date();
    logger.info('[RecoveryEngine] Processus de récupération démarré — attente de stabilisation...');
  }

  // Vérifie si les conditions sont réunies pour reprendre
  async evaluate(currentEquity, candles_m1, atrAnalyzer, newsCalendar) {
    if (!this.recoveryStartTime) return { ready: false, reason: 'Recovery non démarré' };

    const waitMinutes = this.cfg.survival?.recovery_wait_minutes || 30;
    const elapsedMinutes = (Date.now() - this.recoveryStartTime.getTime()) / 60000;

    if (elapsedMinutes < waitMinutes) {
      return { ready: false, reason: `Attente: ${(waitMinutes - elapsedMinutes).toFixed(0)} minutes restantes` };
    }

    const checks = [];

    // 1. ATR normal (pas de volatilité extrême)
    const atrResult = atrAnalyzer.analyze(candles_m1);
    checks.push({ name: 'ATR normal', ok: atrResult.suitable, detail: atrResult.warning || 'OK' });

    // 2. Pas de news importantes dans les 30 prochaines minutes
    const newsResult = newsCalendar.analyze();
    checks.push({ name: 'Pas de news', ok: !newsResult.blocked && newsResult.minsUntilNext > 30, detail: newsResult.blockReason || `Prochaine news dans ${newsResult.minsUntilNext} min` });

    // 3. Equity > 50% de la perte subie (récupération partielle)
    const ddStats = this.survival.ddMonitor.getStats();
    const equityRatio = ddStats.startEquity > 0 ? currentEquity / ddStats.startEquity : 1;
    checks.push({ name: 'Equity suffisante', ok: equityRatio > 0.5, detail: `Equity actuelle: ${(equityRatio*100).toFixed(0)}% du départ` });

    const allOk = checks.every(c => c.ok);

    if (allOk) {
      logger.info('[RecoveryEngine] Toutes les conditions OK — le bot peut reprendre');
      // Reset le survival system
      this.survival.unblock();
      this.survival.ddMonitor.init(currentEquity);
      this.survival.equityStop.reset();

      // Notifier l'utilisateur
      if (this.notifier) {
        await this.notifier.notifyRecovery(currentEquity, checks);
      }
    }

    return { ready: allOk, checks, elapsedMinutes, waitMinutes };
  }
}
