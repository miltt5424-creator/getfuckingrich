import { calcDrawdownPct } from '../utils/math.js';
import { bus, EVENTS }     from '../utils/eventBus.js';
import logger               from '../utils/logger.js';

export class DrawdownMonitor {
  constructor(config) {
    this.cfg            = config;
    this.startEquity    = null;
    this.peakEquity     = null;
    this.dailyStart     = null;
    this.dailyStartTime = null;
    this.history        = []; // historique des equity
    this.maxDDSeen      = 0;
  }

  init(equity) {
    this.startEquity    = equity;
    this.peakEquity     = equity;
    this.dailyStart     = equity;
    this.dailyStartTime = new Date();
    logger.info(`[DrawdownMonitor] Initialisé avec equity: ${equity}$`);
  }

  update(equity) {
    if (!this.startEquity) this.init(equity);

    // Mettre à jour le peak
    if (equity > this.peakEquity) this.peakEquity = equity;

    // Reset journalier à minuit UTC
    const now = new Date();
    if (this.dailyStartTime && now.getUTCDate() !== this.dailyStartTime.getUTCDate()) {
      this.dailyStart     = equity;
      this.dailyStartTime = now;
      logger.info('[DrawdownMonitor] Reset journalier');
    }

    // Calculer les drawdowns
    const ddFromPeak  = calcDrawdownPct(this.peakEquity, equity);
    const ddFromStart = calcDrawdownPct(this.startEquity, equity);
    const ddDaily     = calcDrawdownPct(this.dailyStart, equity);

    if (ddFromPeak > this.maxDDSeen) this.maxDDSeen = ddFromPeak;

    // Historique (garder 1440 points = 24h en M1)
    this.history.push({ equity, ts: Date.now(), ddFromPeak, ddDaily });
    if (this.history.length > 1440) this.history.shift();

    bus.emit(EVENTS.EQUITY_UPDATED, { equity, ddFromPeak, ddFromStart, ddDaily, peak: this.peakEquity });

    return { equity, ddFromPeak, ddFromStart, ddDaily, peak: this.peakEquity, maxDDSeen: this.maxDDSeen };
  }

  getPhase(equity) {
    const dd = calcDrawdownPct(this.peakEquity || equity, equity);
    const p2Trigger = this.cfg.survival?.phase2_dd_pct || 15;
    const p3Trigger = this.cfg.survival?.phase3_dd_pct || 40;
    const dailyDD   = calcDrawdownPct(this.dailyStart || equity, equity);
    const dailyLimit = this.cfg.survival?.daily_loss_limit_pct || 15;

    if (dd >= p3Trigger || dailyDD >= dailyLimit) return { phase: 3, dd, reason: dd >= p3Trigger ? `DD ${dd.toFixed(1)}% ≥ ${p3Trigger}%` : `Perte journalière ${dailyDD.toFixed(1)}%` };
    if (dd >= p2Trigger) return { phase: 2, dd, reason: `DD ${dd.toFixed(1)}% ≥ ${p2Trigger}%` };
    return { phase: 1, dd, reason: 'Normal' };
  }

  getStats() {
    return {
      startEquity:  this.startEquity,
      peakEquity:   this.peakEquity,
      dailyStart:   this.dailyStart,
      maxDDSeen:    this.maxDDSeen,
      historyCount: this.history.length,
    };
  }
}
