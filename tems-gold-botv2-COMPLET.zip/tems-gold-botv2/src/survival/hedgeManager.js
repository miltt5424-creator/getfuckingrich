import logger from '../utils/logger.js';

export class HedgeManager {
  constructor(config, broker) {
    this.cfg    = config;
    this.broker = broker;
  }

  // Calcule le lot de hedge optimal
  calcHedgeLot(gridTotalLot) {
    const ratio = this.cfg.survival?.hedge_ratio || 0.4;
    const minLot = this.cfg.grid?.lot_initial || 0.01;
    return Math.max(minLot, Math.round(gridTotalLot * ratio * 100) / 100);
  }

  // Ouvre une position de hedge sur une grille
  async openHedge(grid, currentPrice) {
    if (grid.hedgeActive) {
      logger.debug(`[HedgeManager] Hedge déjà actif pour ${grid.id}`);
      return null;
    }

    const hedgeDir = grid.direction === 'BUY' ? 'SELL' : 'BUY';
    const hedgeLot = this.calcHedgeLot(grid.totalLot);

    logger.risk(`[HedgeManager] Ouverture hedge | ${grid.symbol} ${hedgeDir} | Lot: ${hedgeLot} | Grid lot: ${grid.totalLot}`);

    if (this.cfg.isPaper) {
      return { ticket: `HEDGE_${Date.now()}`, lot: hedgeLot, direction: hedgeDir, entryPrice: currentPrice };
    }

    try {
      const order = await this.broker.sendOrder({
        symbol: grid.symbol, type: hedgeDir, lot: hedgeLot,
        comment: `TEMS_HEDGE_${grid.id}`,
      });
      return { ...order, lot: hedgeLot, direction: hedgeDir };
    } catch (err) {
      logger.error(`[HedgeManager] Erreur hedge: ${err.message}`);
      return null;
    }
  }

  // Ferme le hedge quand la grille principale se referme
  async closeHedge(grid) {
    if (!grid.hedgeActive || !grid.hedgePositions.length) return;
    for (const hedgePos of grid.hedgePositions) {
      if (this.cfg.isPaper) {
        logger.trade(`[PAPER] Close hedge ticket=${hedgePos.ticket}`);
        continue;
      }
      try {
        await this.broker.closeOrder(hedgePos.ticket);
      } catch (err) {
        logger.error(`[HedgeManager] Erreur fermeture hedge ${hedgePos.ticket}: ${err.message}`);
      }
    }
  }

  // Évalue si une grille a besoin d'un hedge
  needsHedge(grid, equity) {
    if (grid.hedgeActive) return false;
    if (grid.survivalPhase < 2) return false;
    return grid.level >= (this.cfg.survival?.phase2_level_trigger || 7);
  }
}
