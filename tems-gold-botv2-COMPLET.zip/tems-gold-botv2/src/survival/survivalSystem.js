import { DrawdownMonitor } from './drawdownMonitor.js';
import { HedgeManager }    from './hedgeManager.js';
import { EquityStop }      from './equityStop.js';
import logger               from '../utils/logger.js';

export class SurvivalSystem {
  constructor(config, broker, notifier) {
    this.cfg     = config;
    this.broker  = broker;
    this.notifier= notifier;

    this.ddMonitor  = new DrawdownMonitor(config);
    this.hedgeMgr   = new HedgeManager(config, broker);
    this.equityStop = new EquityStop(config, broker, notifier);

    this.blocked    = false;
    this.blockReason= null;
    this.currentPhase = 1;
  }

  init(equity) {
    this.ddMonitor.init(equity);
    logger.info(`[SurvivalSystem] Initialisé | Equity: ${equity}$ | Phase2 trigger: ${this.cfg.survival.phase2_dd_pct}% | Phase3: ${this.cfg.survival.phase3_dd_pct}%`);
  }

  // Vérifie si on peut ouvrir de nouvelles grilles
  check(equity) {
    const { phase, dd, reason } = this.ddMonitor.getPhase(equity);

    if (phase === 3 || this.blocked) {
      return { allowed: false, reason: this.blockReason || reason, phase, dd };
    }
    if (phase === 2) {
      return { allowed: false, reason: `Phase 2 active — ${reason}`, phase, dd };
    }
    return { allowed: true, phase, dd };
  }

  // Met à jour l'equity et retourne la phase actuelle
  updateEquity(equity) {
    return this.ddMonitor.update(equity);
  }

  // Évalue une grille individuelle et retourne la phase recommandée
  evaluateGrid(grid, equity) {
    const { phase } = this.ddMonitor.getPhase(equity);
    const levelPhase = grid.level >= 12 ? 3 : grid.level >= 7 ? 2 : 1;
    const newPhase   = Math.max(phase, levelPhase);
    const phaseChanged = newPhase !== grid.survivalPhase;

    return { newPhase, phaseChanged, currentPhase: grid.survivalPhase, equity };
  }

  // Gestion complète d'une mise à jour d'equity
  async onEquityUpdate(equity, openGrids, gridManager) {
    const ddInfo  = this.ddMonitor.update(equity);
    const phaseInfo = this.ddMonitor.getPhase(equity);
    this.currentPhase = phaseInfo.phase;

    if (phaseInfo.phase === 3 && !this.blocked) {
      this.blocked     = true;
      this.blockReason = phaseInfo.reason;
      logger.risk(`[SurvivalSystem] PHASE 3 ACTIVÉE — ${phaseInfo.reason}`);

      // Fermer toutes les grilles
      for (const grid of openGrids) {
        await gridManager.closeGrid(grid, 'equity_stop');
      }

      await this.equityStop.trigger(equity, phaseInfo.reason);
    }

    return { ...ddInfo, phase: phaseInfo.phase, blocked: this.blocked };
  }

  unblock() {
    this.blocked     = false;
    this.blockReason = null;
    logger.info('[SurvivalSystem] Bot débloqué manuellement');
  }

  getStatus() {
    return {
      phase:        this.currentPhase,
      blocked:      this.blocked,
      blockReason:  this.blockReason,
      ddStats:      this.ddMonitor.getStats(),
    };
  }
}
