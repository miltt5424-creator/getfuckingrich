import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class AccountMonitor {
  constructor(bridge, survivalSystem) {
    this.bridge   = bridge;
    this.survival = survivalSystem;
    this.current  = null;
    this.interval = null;
  }

  async start(intervalMs = 5000) {
    // Premier fetch immédiat
    await this.refresh();
    this.interval = setInterval(() => this.refresh(), intervalMs);
    logger.info(`[AccountMonitor] Démarré (refresh toutes les ${intervalMs/1000}s)`);
  }

  stop() {
    if (this.interval) clearInterval(this.interval);
  }

  async refresh() {
    try {
      const info = await this.bridge.getAccountInfo();
      this.current = info;
      if (this.survival) {
        this.survival.updateEquity(info.equity);
      }
      bus.emit(EVENTS.EQUITY_UPDATED, info);
      return info;
    } catch (err) {
      logger.error(`[AccountMonitor] Erreur refresh: ${err.message}`);
      return this.current || { equity: 0, balance: 0, freeMargin: 0 };
    }
  }

  getAccount() { return this.current || { equity: 0, balance: 0, freeMargin: 0 }; }
}
