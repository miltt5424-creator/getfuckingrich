// orderManager.js — Gestion des ordres avec retry automatique

import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class OrderManager {
  constructor(bridge, config) {
    this.bridge  = bridge;
    this.cfg     = config;
    this.maxRetry = 3;
    this.retryDelay = 1000;
  }

  async sendOrder(params, retries = 0) {
    try {
      bus.emit(EVENTS.ORDER_SENT, params);
      const result = await this.bridge.sendOrder(params);
      return result;
    } catch (err) {
      if (retries < this.maxRetry) {
        logger.warn(`[OrderManager] Retry ${retries + 1}/${this.maxRetry}: ${err.message}`);
        await this._delay(this.retryDelay * (retries + 1));
        return this.sendOrder(params, retries + 1);
      }
      bus.emit(EVENTS.ORDER_ERROR, { params, error: err.message });
      throw err;
    }
  }

  async closeOrder(ticket, retries = 0) {
    try {
      return await this.bridge.closeOrder(ticket);
    } catch (err) {
      if (retries < this.maxRetry) {
        await this._delay(this.retryDelay * (retries + 1));
        return this.closeOrder(ticket, retries + 1);
      }
      throw err;
    }
  }

  async closeAllBySymbol(symbol) {
    const positions = await this.bridge.getAllOpenPositions();
    const toClose   = positions.filter(p => p.symbol === symbol);
    const results   = [];
    for (const pos of toClose) {
      try {
        await this.closeOrder(pos.ticket);
        results.push({ ticket: pos.ticket, success: true });
      } catch (err) {
        results.push({ ticket: pos.ticket, success: false, error: err.message });
      }
    }
    return results;
  }

  _delay(ms) { return new Promise(r => setTimeout(r, ms)); }
}
