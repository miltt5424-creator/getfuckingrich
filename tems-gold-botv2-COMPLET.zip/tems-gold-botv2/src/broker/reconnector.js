import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class Reconnector {
  constructor(bridge, config, notifier) {
    this.bridge   = bridge;
    this.cfg      = config;
    this.notifier = notifier;
    this.attempts = 0;
    this.maxAttempts = 10;
    this.disconnectedAt = null;
    this.isReconnecting = false;
  }

  watch() {
    bus.on(EVENTS.BRIDGE_DISCONNECTED, () => this._onDisconnect());
    bus.on(EVENTS.BRIDGE_CONNECTED,    () => this._onConnect());
  }

  async _onDisconnect() {
    if (this.isReconnecting) return;
    this.disconnectedAt = new Date();
    this.isReconnecting = true;
    logger.warn('[Reconnector] Bridge MT5 déconnecté — tentative de reconnexion...');

    const delays = [5000, 10000, 15000, 30000, 60000, 60000, 60000, 120000, 120000, 300000];

    for (let i = 0; i < this.maxAttempts; i++) {
      this.attempts = i + 1;
      const delay = delays[Math.min(i, delays.length - 1)];
      logger.info(`[Reconnector] Tentative ${this.attempts}/${this.maxAttempts} dans ${delay/1000}s...`);
      await new Promise(r => setTimeout(r, delay));

      try {
        await this.bridge.connect();
        logger.info(`[Reconnector] Reconnexion réussie après ${this.attempts} tentative(s)`);
        return;
      } catch (err) {
        logger.error(`[Reconnector] Tentative ${this.attempts} échouée: ${err.message}`);

        // Alerte si déconnecté depuis plus de 2 minutes
        const elapsed = (Date.now() - this.disconnectedAt.getTime()) / 60000;
        if (elapsed > 2 && this.notifier) {
          await this.notifier.notifyDisconnection(elapsed, this.attempts).catch(() => {});
        }
      }
    }

    logger.error('[Reconnector] Impossible de se reconnecter après toutes les tentatives. Arrêt.');
    if (this.notifier) {
      await this.notifier.notifyFatalError('Bridge MT5 inaccessible').catch(() => {});
    }
    process.exit(1);
  }

  _onConnect() {
    this.attempts       = 0;
    this.isReconnecting = false;
    this.disconnectedAt = null;
  }
}
