import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class CandleFeeder {
  constructor(bridge, signalEngine, config) {
    this.bridge  = bridge;
    this.signal  = signalEngine;
    this.cfg     = config;
    this.cache   = {}; // symbol:timeframe -> candles[]
    this.lastCandle = {}; // symbol -> timestamp dernière bougie
    this.interval = null;
  }

  async start() {
    const symbols    = this.cfg.getEnabledSymbols().map(s => s.name);
    const timeframes = ['M1', 'M5', 'M15', 'H1', 'H4'];

    // Chargement initial de tout l'historique
    for (const symbol of symbols) {
      for (const tf of timeframes) {
        await this._fetchAndCache(symbol, tf, tf === 'M1' ? 500 : tf === 'H4' ? 100 : 200);
      }
    }

    logger.info(`[CandleFeeder] Historique chargé pour ${symbols.join(', ')}`);

    // Rafraîchissement toutes les minutes
    this.interval = setInterval(() => this._refresh(), 60000);

    // Rafraîchissement immédiat M1 toutes les 10s
    this._m1Interval = setInterval(() => this._refreshM1(), 10000);
  }

  stop() {
    if (this.interval)   clearInterval(this.interval);
    if (this._m1Interval) clearInterval(this._m1Interval);
  }

  getCandles(symbol, timeframe) {
    return this.cache[`${symbol}:${timeframe}`] || [];
  }

  async _fetchAndCache(symbol, timeframe, count) {
    try {
      const candles = await this.bridge.getCandles(symbol, timeframe, count);
      if (!candles.length) return;
      this.cache[`${symbol}:${timeframe}`] = candles;
      this.signal.updateCandles(symbol, timeframe, candles);
    } catch (err) {
      logger.error(`[CandleFeeder] Erreur fetch ${symbol} ${timeframe}: ${err.message}`);
    }
  }

  async _refresh() {
    const symbols = this.cfg.getEnabledSymbols().map(s => s.name);
    for (const symbol of symbols) {
      for (const tf of ['M5', 'M15', 'H1', 'H4']) {
        await this._fetchAndCache(symbol, tf, 200);
      }
    }
  }

  async _refreshM1() {
    const symbols = this.cfg.getEnabledSymbols().map(s => s.name);
    for (const symbol of symbols) {
      try {
        const newCandles = await this.bridge.getCandles(symbol, 'M1', 5);
        if (!newCandles.length) continue;
        const key    = `${symbol}:M1`;
        const cached = this.cache[key] || [];
        const last   = cached[cached.length - 1];
        const newest = newCandles[newCandles.length - 1];

        if (!last || newest.time > last.time) {
          // Nouvelle bougie détectée
          cached.push(...newCandles.filter(c => !last || c.time > last.time));
          if (cached.length > 500) cached.splice(0, cached.length - 500);
          this.cache[key] = cached;
          this.signal.updateCandles(symbol, 'M1', cached);
          bus.emit(EVENTS.CANDLE_CLOSED, { symbol, timeframe: 'M1', candle: newest });
          logger.debug(`[CandleFeeder] Nouvelle bougie M1 ${symbol} @ ${newest.close}`);
        }
      } catch (err) {
        logger.error(`[CandleFeeder] Erreur M1 ${symbol}: ${err.message}`);
      }
    }
  }
}
