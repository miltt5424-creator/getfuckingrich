// mt5Bridge.js — Connexion MT5 via ZeroMQ (DWX_ZeroMQ_Connector)
// Ports : PUSH 32768 (envoi ordres) | PULL 32769 (réponses) | SUB 32770 (ticks/prix)

import logger from '../utils/logger.js';
import { bus, EVENTS } from '../utils/eventBus.js';

export class MT5Bridge {
  constructor(config) {
    this.cfg       = config;
    this.connected = false;
    this.push      = null; // socket PUSH
    this.pull      = null; // socket PULL
    this.sub       = null; // socket SUB
    this._pendingRequests = new Map(); // reqId -> { resolve, reject, timeout }
    this._reqCounter = 0;
    this._tickHandlers = new Map(); // symbol -> callback
    this._reconnectAttempts = 0;
    this._maxReconnectAttempts = 10;
  }

  async connect() {
    try {
      // Import dynamique de zeromq (ESM)
      const zmq = await import('zeromq');

      const host     = this.cfg.env.mt5Host || 'localhost';
      const pushPort = this.cfg.env.mt5PushPort || 32768;
      const pullPort = this.cfg.env.mt5PullPort || 32769;
      const subPort  = this.cfg.env.mt5SubPort  || 32770;

      this.push = new zmq.Push();
      this.pull = new zmq.Pull();
      this.sub  = new zmq.Subscriber();

      await this.push.bind(`tcp://${host}:${pushPort}`);
      await this.pull.bind(`tcp://${host}:${pullPort}`);
      await this.sub.connect(`tcp://${host}:${subPort}`);
      await this.sub.subscribe(''); // S'abonner à tous les messages

      this.connected = true;
      this._reconnectAttempts = 0;
      logger.bridge(`MT5Bridge connecté | ${host}:${pushPort}/${pullPort}/${subPort}`);
      bus.emit(EVENTS.BRIDGE_CONNECTED, { host, pushPort, pullPort, subPort });

      // Démarrer la boucle de lecture des réponses
      this._startPullLoop();
      this._startSubLoop();

    } catch (err) {
      logger.error(`[MT5Bridge] Erreur connexion: ${err.message}`);
      throw err;
    }
  }

  async disconnect() {
    this.connected = false;
    try {
      if (this.push) await this.push.close();
      if (this.pull) await this.pull.close();
      if (this.sub)  await this.sub.close();
    } catch {}
    logger.bridge('MT5Bridge déconnecté');
    bus.emit(EVENTS.BRIDGE_DISCONNECTED);
  }

  // Envoie une requête au bridge MT5 et attend la réponse
  async _sendRequest(payload, timeoutMs = 10000) {
    if (!this.connected) throw new Error('MT5Bridge non connecté');
    const reqId = ++this._reqCounter;
    payload.reqId = reqId;

    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this._pendingRequests.delete(reqId);
        reject(new Error(`MT5Bridge timeout (reqId=${reqId})`));
      }, timeoutMs);

      this._pendingRequests.set(reqId, { resolve, reject, timer });
      this.push.send(JSON.stringify(payload)).catch(reject);
    });
  }

  // Boucle PULL : lit les réponses de MT5
  async _startPullLoop() {
    for await (const [msg] of this.pull) {
      try {
        const data = JSON.parse(msg.toString());
        const reqId = data.reqId;
        if (reqId && this._pendingRequests.has(reqId)) {
          const { resolve, timer } = this._pendingRequests.get(reqId);
          clearTimeout(timer);
          this._pendingRequests.delete(reqId);
          resolve(data);
        }
      } catch (e) {
        logger.error(`[MT5Bridge] Erreur parsing réponse: ${e.message}`);
      }
    }
  }

  // Boucle SUB : lit les ticks/prix en temps réel
  async _startSubLoop() {
    for await (const [msg] of this.sub) {
      try {
        const data = JSON.parse(msg.toString());
        if (data.type === 'tick' && data.symbol) {
          const handler = this._tickHandlers.get(data.symbol);
          if (handler) handler(data);
          bus.emit(EVENTS.TICK_RECEIVED, data);
        } else if (data.type === 'account') {
          bus.emit(EVENTS.EQUITY_UPDATED, data);
        }
      } catch {}
    }
  }

  // Abonne un handler à un symbole
  onTick(symbol, callback) {
    this._tickHandlers.set(symbol, callback);
    // Demander au bridge de streamer ce symbole
    this._sendRequest({ action: 'SUBSCRIBE', symbol }).catch(() => {});
  }

  // Récupère les bougies OHLCV pour un symbole et timeframe
  async getCandles(symbol, timeframe, count = 200) {
    if (!this.connected) return this._getFakeCandles(count);
    try {
      const res = await this._sendRequest({ action: 'GET_CANDLES', symbol, timeframe, count });
      if (!res.candles || !Array.isArray(res.candles)) throw new Error('Réponse invalide');
      return res.candles.map(c => ({
        time: new Date(c.time * 1000), open: c.open, high: c.high,
        low: c.low, close: c.close, volume: c.volume || 1,
      }));
    } catch (err) {
      logger.error(`[MT5Bridge] getCandles(${symbol}, ${timeframe}): ${err.message}`);
      return this._getFakeCandles(count);
    }
  }

  // Informations du compte
  async getAccountInfo() {
    if (!this.connected) return { equity: 1000, balance: 1000, freeMargin: 1000, leverage: 100 };
    try {
      const res = await this._sendRequest({ action: 'GET_ACCOUNT' });
      return { equity: res.equity, balance: res.balance, freeMargin: res.free_margin, leverage: res.leverage, currency: res.currency };
    } catch (err) {
      logger.error(`[MT5Bridge] getAccountInfo: ${err.message}`);
      return { equity: 0, balance: 0, freeMargin: 0 };
    }
  }

  // Envoie un ordre
  async sendOrder({ symbol, type, lot, sl = 0, tp = 0, comment = '' }) {
    if (!this.connected) throw new Error('MT5Bridge non connecté');
    const action = type === 'BUY' ? 'ORDER_TYPE_BUY' : 'ORDER_TYPE_SELL';
    const res = await this._sendRequest({
      action: 'NEW_TRADE', symbol, order_type: action,
      lots: lot, sl, tp, comment,
    }, 15000);
    if (!res.ticket) throw new Error(`Ordre refusé: ${JSON.stringify(res)}`);
    bus.emit(EVENTS.ORDER_CONFIRMED, { ticket: res.ticket, symbol, type, lot });
    logger.trade(`[MT5Bridge] Ordre confirmé | ticket=${res.ticket} | ${type} ${symbol} ${lot}`);
    return { ticket: res.ticket, ...res };
  }

  // Ferme un ordre par ticket
  async closeOrder(ticket) {
    if (!this.connected) throw new Error('MT5Bridge non connecté');
    const res = await this._sendRequest({ action: 'CLOSE_TRADE_BY_TICKET', ticket }, 15000);
    if (res.error) throw new Error(`Fermeture refusée: ${res.error}`);
    logger.trade(`[MT5Bridge] Ordre fermé | ticket=${ticket}`);
    return res;
  }

  // Récupère toutes les positions ouvertes
  async getAllOpenPositions() {
    if (!this.connected) return [];
    try {
      const res = await this._sendRequest({ action: 'GET_OPEN_TRADES' });
      return res.trades || [];
    } catch { return []; }
  }

  // Mode paper : génère de fausses bougies pour tester
  _getFakeCandles(count) {
    const candles = [];
    let price = 4650;
    const now = Date.now();
    for (let i = count - 1; i >= 0; i--) {
      const change = (Math.random() - 0.5) * 5;
      const open   = price;
      const close  = price + change;
      const high   = Math.max(open, close) + Math.random() * 3;
      const low    = Math.min(open, close) - Math.random() * 3;
      price = close;
      candles.push({ time: new Date(now - i * 60000), open, high, low, close, volume: Math.floor(Math.random() * 1000 + 100) });
    }
    return candles;
  }
}
