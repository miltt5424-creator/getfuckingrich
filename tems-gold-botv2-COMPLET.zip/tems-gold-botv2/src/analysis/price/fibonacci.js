import { calcFibonacciLevels, isNearLevel } from '../../utils/math.js';

export class FibonacciAnalyzer {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles, currentPrice) {
    const swing = this._findLastSwing(candles);
    if (!swing) return { score: 0, direction: null, levels: {} };

    const levels = calcFibonacciLevels(swing.high, swing.low);
    const nearLevel = this._findNearestFibLevel(currentPrice, levels);
    const direction = swing.direction === 'UP' ? 'SELL' : 'BUY';

    let score = 0;
    if (nearLevel) {
      score = nearLevel.key === 'r_618' || nearLevel.key === 'r_382' ? 80
            : nearLevel.key === 'r_500' ? 70
            : nearLevel.key === 'r_786' ? 60 : 40;
    }

    return { score, direction, levels, nearLevel, swing };
  }

  _findLastSwing(candles) {
    if (candles.length < 20) return null;
    const recent = candles.slice(-100);
    let highIdx = 0, lowIdx = 0;
    for (let i = 1; i < recent.length; i++) {
      if (recent[i].high > recent[highIdx].high) highIdx = i;
      if (recent[i].low  < recent[lowIdx].low)   lowIdx  = i;
    }
    const high = recent[highIdx].high;
    const low  = recent[lowIdx].low;
    return { high, low, direction: highIdx > lowIdx ? 'UP' : 'DOWN' };
  }

  _findNearestFibLevel(price, levels) {
    const tol = this.spec.pip * 5;
    let nearest = null, minDist = Infinity;
    for (const [key, level] of Object.entries(levels)) {
      const dist = Math.abs(price - level);
      if (dist < minDist && dist <= tol) { minDist = dist; nearest = { key, level, distance: dist }; }
    }
    return nearest;
  }
}
