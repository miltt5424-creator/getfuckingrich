// Elliott Waves simplifié — compte les vagues 1-2-3-4-5 et A-B-C
// Anticipe la vague 3 (la plus forte) pour maximiser les entrées

export class ElliottWaveAnalyzer {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles) {
    if (candles.length < 40) return { wave: null, score: 0, direction: null };

    const swings = this._detectSignificantSwings(candles);
    if (swings.length < 4) return { wave: null, score: 0, direction: null };

    const impulse = this._detectImpulseWave(swings);
    const corrective = this._detectCorrectiveWave(swings);

    let result = { wave: null, score: 0, direction: null, swings };

    if (impulse) {
      result = { ...result, ...impulse };
    } else if (corrective) {
      result = { ...result, ...corrective };
    }

    return result;
  }

  _detectSignificantSwings(candles, minMove = 5) {
    // Détecte uniquement les swings significatifs (> minMove pips)
    const raw = [];
    let lastType = null;
    for (let i = 2; i < candles.length - 2; i++) {
      const window = candles.slice(i - 2, i + 3);
      const c = candles[i];
      const isHigh = c.high === Math.max(...window.map(w => w.high));
      const isLow  = c.low  === Math.min(...window.map(w => w.low));
      if (isHigh && lastType !== 'high') { raw.push({ price: c.high, type: 'high', index: i, time: c.time }); lastType = 'high'; }
      else if (isLow && lastType !== 'low') { raw.push({ price: c.low, type: 'low', index: i, time: c.time }); lastType = 'low'; }
    }
    // Filtrer par taille minimale
    return raw.filter((s, i) => {
      if (i === 0) return true;
      return Math.abs(s.price - raw[i-1].price) >= this.spec.pip * minMove;
    });
  }

  _detectImpulseWave(swings) {
    // Chercher la structure 1-2-3-4-5
    for (let i = 0; i <= swings.length - 5; i++) {
      const [w1, w2, w3, w4, w5] = swings.slice(i, i + 5);
      const upTrend = w1.type === 'low';
      if (!upTrend && w1.type !== 'high') continue;

      const wave1 = Math.abs(w2.price - w1.price);
      const wave2 = Math.abs(w3.price - w2.price);
      const wave3 = Math.abs(w4.price - w3.price);
      const wave4 = Math.abs(w5.price - w4.price);

      // Règles de base d'Elliott :
      // Wave 2 ne doit pas dépasser wave 1
      // Wave 3 est souvent la plus longue
      // Wave 4 ne doit pas entrer dans le territoire de wave 1
      const rule1 = upTrend ? w3.price > w1.price : w3.price < w1.price; // Wave 2 ne passe pas wave 1
      const rule2 = wave3 > wave1 || wave3 > wave4; // Wave 3 est la plus grande
      const rule3 = upTrend ? w5.price > w3.price : w5.price < w3.price; // Wave 4 ne passe pas wave 1

      if (rule1 && rule2) {
        const currentWave = this._identifyCurrentWave(swings, i + 4);
        const direction = upTrend ? 'BUY' : 'SELL';
        const score = rule3 ? 75 : 60;

        return {
          wave: 'impulse', waveCount: currentWave, direction,
          waves: [w1, w2, w3, w4, w5], score,
          anticipating: currentWave === 3 ? 'wave3_in_progress' : currentWave === 5 ? 'wave5_complete' : null,
          wave3Length: wave3, wave1Length: wave1, ratio: wave3 / wave1,
        };
      }
    }
    return null;
  }

  _detectCorrectiveWave(swings) {
    if (swings.length < 3) return null;
    const [a, b, c] = swings.slice(-3);
    const waveA = Math.abs(b.price - a.price);
    const waveB = Math.abs(c.price - b.price);
    const ratio = waveB / waveA;

    // Wave B = 0.5-0.886 de wave A en correction normale
    if (ratio >= 0.382 && ratio <= 1.0) {
      const direction = a.type === 'high' ? 'BUY' : 'SELL'; // Après A baissière → attendre BUY
      return {
        wave: 'corrective', waveCount: 'C_incoming', direction, score: 65,
        waves: [a, b, c], waveALength: waveA, waveBLength: waveB, ratio,
        anticipating: 'wave_c_incoming',
      };
    }
    return null;
  }

  _identifyCurrentWave(swings, lastIdx) {
    const count = lastIdx + 1;
    return count % 5 === 0 ? 5 : count % 5;
  }
}
