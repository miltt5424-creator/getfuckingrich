// Patterns harmoniques : Gartley, Bat, Crab, Butterfly, Shark
// Basés sur les ratios de Fibonacci sur les swings XABCD

export class HarmonicPatternDetector {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles) {
    if (candles.length < 30) return { patterns: [], score: 0, direction: null };
    const swings = this._detectSwings(candles);
    if (swings.length < 5) return { patterns: [], score: 0, direction: null };

    const patterns = [];

    // Tester les 5 derniers swings comme XABCD
    for (let i = swings.length - 5; i < swings.length - 4; i++) {
      if (i < 0) continue;
      const [X, A, B, C, D] = swings.slice(i, i + 5);
      const detected = this._checkAllPatterns(X, A, B, C, D);
      patterns.push(...detected);
    }

    const score = patterns.length > 0 ? Math.max(...patterns.map(p => p.confidence)) : 0;
    const buyPatterns  = patterns.filter(p => p.direction === 'BUY');
    const sellPatterns = patterns.filter(p => p.direction === 'SELL');
    const direction = buyPatterns.length > sellPatterns.length ? 'BUY' : sellPatterns.length > buyPatterns.length ? 'SELL' : null;

    return { patterns, score, direction };
  }

  _detectSwings(candles, strength = 3) {
    const swings = [];
    for (let i = strength; i < candles.length - strength; i++) {
      const window = candles.slice(i - strength, i + strength + 1);
      const c = candles[i];
      if (c.high === Math.max(...window.map(w => w.high))) swings.push({ price: c.high, type: 'high', index: i });
      else if (c.low === Math.min(...window.map(w => w.low))) swings.push({ price: c.low, type: 'low', index: i });
    }
    // Alterner highs et lows
    const alternating = [];
    for (const s of swings) {
      if (!alternating.length || alternating[alternating.length-1].type !== s.type) alternating.push(s);
    }
    return alternating;
  }

  _checkAllPatterns(X, A, B, C, D) {
    const patterns = [];
    const XA = Math.abs(A.price - X.price);
    const AB = Math.abs(B.price - A.price);
    const BC = Math.abs(C.price - B.price);
    const CD = Math.abs(D.price - C.price);
    const XD = Math.abs(D.price - X.price);

    if (!XA) return [];

    const abcdr  = AB / XA;
    const bcdcr  = BC / AB;
    const xdr    = XD / XA;

    const isBullish = A.price > X.price; // X bas → A haut → B bas → C haut → D bas
    const dir = isBullish ? 'BUY' : 'SELL';

    // Gartley : AB=0.618 XA, BC=0.382-0.886 AB, XD=0.786 XA
    if (this._near(abcdr, 0.618, 0.06) && bcdcr > 0.382 && bcdcr < 0.886 && this._near(xdr, 0.786, 0.08)) {
      patterns.push({ name: 'Gartley', direction: dir, confidence: 75, D: D.price, abcdr, xdr });
    }
    // Bat : AB=0.382-0.50 XA, BC=0.382-0.886 AB, XD=0.886 XA
    if (abcdr > 0.382 && abcdr < 0.50 && bcdcr > 0.382 && bcdcr < 0.886 && this._near(xdr, 0.886, 0.08)) {
      patterns.push({ name: 'Bat', direction: dir, confidence: 80, D: D.price, abcdr, xdr });
    }
    // Crab : AB=0.382-0.618 XA, XD=1.618 XA
    if (abcdr > 0.382 && abcdr < 0.618 && this._near(xdr, 1.618, 0.10)) {
      patterns.push({ name: 'Crab', direction: dir, confidence: 85, D: D.price, abcdr, xdr });
    }
    // Butterfly : AB=0.786 XA, XD=1.27-1.618 XA
    if (this._near(abcdr, 0.786, 0.07) && xdr > 1.17 && xdr < 1.618) {
      patterns.push({ name: 'Butterfly', direction: dir, confidence: 78, D: D.price, abcdr, xdr });
    }
    // Shark : BC=1.13-1.618 AB, XD=0.886-1.13 XA
    if (bcdcr > 1.13 && bcdcr < 1.618 && xdr > 0.886 && xdr < 1.13) {
      patterns.push({ name: 'Shark', direction: dir, confidence: 72, D: D.price, abcdr, xdr });
    }

    return patterns;
  }

  _near(value, target, tolerance) {
    return Math.abs(value - target) <= tolerance;
  }
}
