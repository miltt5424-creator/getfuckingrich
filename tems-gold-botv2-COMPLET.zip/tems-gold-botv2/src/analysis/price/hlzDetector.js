// HLZ — High Liquidity Zones detector
// Niveaux psychologiques, session H/L, Equal H/L, POC, Pivot Points

import { calcPivotPoints, isNearLevel } from '../../utils/math.js';

export class HLZDetector {
  constructor(symbolSpec) {
    this.spec = symbolSpec;
  }

  analyze(candles_m1, candles_h1, currentPrice) {
    const result = {
      psychologicalLevels: this.detectPsychologicalLevels(currentPrice),
      sessionLevels:       this.detectSessionLevels(candles_h1),
      equalHighsLows:      this.detectEqualHighsLows(candles_m1),
      poc:                 this.calcPOC(candles_m1),
      pivots:              this.calcPivots(candles_h1),
      nearestLevels:       [],
      score:               0,
      direction:           null,
    };

    result.nearestLevels = this._findNearestLevels(currentPrice, result);
    result.score         = this._calcScore(result, currentPrice);
    result.direction     = this._calcDirection(result, currentPrice);
    return result;
  }

  detectPsychologicalLevels(price) {
    const step = this.spec.psychological_levels_step || 50;
    const base = Math.floor(price / step) * step;
    const levels = [];
    for (let i = -3; i <= 3; i++) {
      levels.push({ level: base + i * step, type: 'psychological', strength: i === 0 ? 'major' : 'minor' });
    }
    return levels;
  }

  detectSessionLevels(candles_h1) {
    if (!candles_h1?.length) return {};
    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const todayCandles = candles_h1.filter(c => new Date(c.time) >= todayStart);
    const asianCandles = todayCandles.filter(c => {
      const h = new Date(c.time).getUTCHours();
      return h >= 0 && h < 8;
    });
    const londonCandles = todayCandles.filter(c => {
      const h = new Date(c.time).getUTCHours();
      return h >= 8 && h < 13;
    });

    const result = {};
    if (asianCandles.length) {
      result.asianHigh  = { level: Math.max(...asianCandles.map(c => c.high)), type: 'asian_high' };
      result.asianLow   = { level: Math.min(...asianCandles.map(c => c.low)),  type: 'asian_low'  };
    }
    if (londonCandles.length) {
      result.londonHigh = { level: Math.max(...londonCandles.map(c => c.high)), type: 'london_high' };
      result.londonLow  = { level: Math.min(...londonCandles.map(c => c.low)),  type: 'london_low'  };
    }

    // Previous day H/L (tout sauf aujourd'hui)
    const yesterday = candles_h1.filter(c => new Date(c.time) < todayStart).slice(-24);
    if (yesterday.length) {
      result.prevDayHigh = { level: Math.max(...yesterday.map(c => c.high)), type: 'prev_day_high' };
      result.prevDayLow  = { level: Math.min(...yesterday.map(c => c.low)),  type: 'prev_day_low'  };
    }

    return result;
  }

  detectEqualHighsLows(candles) {
    if (candles.length < 10) return { highs: [], lows: [] };
    const recent = candles.slice(-100);
    const tolerance = this.spec.pip * 3;

    const swingHighs = [], swingLows = [];
    for (let i = 2; i < recent.length - 2; i++) {
      if (recent[i].high > recent[i-1].high && recent[i].high > recent[i-2].high &&
          recent[i].high > recent[i+1].high && recent[i].high > recent[i+2].high) {
        swingHighs.push(recent[i].high);
      }
      if (recent[i].low < recent[i-1].low && recent[i].low < recent[i-2].low &&
          recent[i].low < recent[i+1].low && recent[i].low < recent[i+2].low) {
        swingLows.push(recent[i].low);
      }
    }

    const equalHighs = [], equalLows = [];
    for (let i = 0; i < swingHighs.length - 1; i++) {
      for (let j = i + 1; j < swingHighs.length; j++) {
        if (Math.abs(swingHighs[i] - swingHighs[j]) <= tolerance) {
          equalHighs.push({ level: (swingHighs[i] + swingHighs[j]) / 2, type: 'equal_highs', strength: 'high' });
        }
      }
    }
    for (let i = 0; i < swingLows.length - 1; i++) {
      for (let j = i + 1; j < swingLows.length; j++) {
        if (Math.abs(swingLows[i] - swingLows[j]) <= tolerance) {
          equalLows.push({ level: (swingLows[i] + swingLows[j]) / 2, type: 'equal_lows', strength: 'high' });
        }
      }
    }

    return { highs: equalHighs.slice(-3), lows: equalLows.slice(-3) };
  }

  calcPOC(candles) {
    if (candles.length < 20) return null;
    const recent = candles.slice(-100);
    const high = Math.max(...recent.map(c => c.high));
    const low  = Math.min(...recent.map(c => c.low));
    const bins = 50;
    const binSize = (high - low) / bins;
    const volumeMap = new Array(bins).fill(0);

    recent.forEach(c => {
      const vol = c.volume || 1;
      const binIdx = Math.min(Math.floor((c.close - low) / binSize), bins - 1);
      volumeMap[binIdx] += vol;
    });

    const maxVol = Math.max(...volumeMap);
    const pocIdx = volumeMap.indexOf(maxVol);
    const poc = low + (pocIdx + 0.5) * binSize;

    return {
      poc,
      vah: low + Math.min(pocIdx + 10, bins - 1) * binSize,
      val: low + Math.max(pocIdx - 10, 0) * binSize,
      type: 'poc'
    };
  }

  calcPivots(candles_h1) {
    if (!candles_h1?.length) return null;
    const yesterday = candles_h1.slice(-48, -24);
    if (!yesterday.length) return null;
    const high  = Math.max(...yesterday.map(c => c.high));
    const low   = Math.min(...yesterday.map(c => c.low));
    const close = yesterday[yesterday.length - 1].close;
    return { ...calcPivotPoints(high, low, close), type: 'daily_pivot' };
  }

  _findNearestLevels(price, result) {
    const allLevels = [];
    result.psychologicalLevels.forEach(l => allLevels.push(l));
    Object.values(result.sessionLevels).forEach(l => allLevels.push(l));
    result.equalHighsLows.highs.forEach(l => allLevels.push(l));
    result.equalHighsLows.lows.forEach(l => allLevels.push(l));
    if (result.poc) allLevels.push(result.poc);
    if (result.pivots) {
      ['pp','r1','r2','s1','s2'].forEach(k => {
        if (result.pivots[k]) allLevels.push({ level: result.pivots[k], type: k });
      });
    }

    return allLevels
      .filter(l => l?.level)
      .map(l => ({ ...l, distance: Math.abs(price - l.level) }))
      .sort((a, b) => a.distance - b.distance)
      .slice(0, 5);
  }

  _calcScore(result, price) {
    let score = 0;
    const tol = this.spec.pip * 10;

    result.psychologicalLevels.forEach(l => {
      if (Math.abs(price - l.level) <= tol) score += l.strength === 'major' ? 25 : 10;
    });
    const sl = result.sessionLevels;
    if (sl.asianHigh  && Math.abs(price - sl.asianHigh.level)  <= tol * 2) score += 20;
    if (sl.asianLow   && Math.abs(price - sl.asianLow.level)   <= tol * 2) score += 20;
    if (sl.londonHigh && Math.abs(price - sl.londonHigh.level) <= tol * 2) score += 15;
    if (sl.londonLow  && Math.abs(price - sl.londonLow.level)  <= tol * 2) score += 15;
    if (result.equalHighsLows.highs.length || result.equalHighsLows.lows.length) score += 15;
    if (result.poc && Math.abs(price - result.poc.poc) <= tol * 3) score += 20;
    return Math.min(100, score);
  }

  _calcDirection(result, price) {
    const sl = result.sessionLevels;
    const votes = { BUY: 0, SELL: 0 };
    if (sl.asianHigh && price >= sl.asianHigh.level) votes.SELL += 2;
    if (sl.asianLow  && price <= sl.asianLow.level)  votes.BUY  += 2;
    result.equalHighsLows.highs.forEach(l => { if (Math.abs(price - l.level) < this.spec.pip * 5) votes.SELL += 2; });
    result.equalHighsLows.lows.forEach(l  => { if (Math.abs(price - l.level) < this.spec.pip * 5) votes.BUY  += 2; });
    if (result.poc) {
      if (price > result.poc.vah) votes.SELL++;
      if (price < result.poc.val) votes.BUY++;
    }
    if (votes.BUY > votes.SELL)  return 'BUY';
    if (votes.SELL > votes.BUY)  return 'SELL';
    return null;
  }
}
