// SMC — Smart Money Concepts detector
// Détecte : BoS, CHoCH, Order Blocks, FVG, Liquidity Sweep, Premium/Discount

export class SMCDetector {
  constructor(config) {
    this.cfg = config;
  }

  analyze(candles_m1, candles_m15) {
    const result = {
      bos:            this.detectBoS(candles_m15),
      choch:          this.detectCHoCH(candles_m15),
      orderBlocks:    this.detectOrderBlocks(candles_m15),
      fvg:            this.detectFVG(candles_m1),
      liquiditySweep: this.detectLiquiditySweep(candles_m15),
      premiumDiscount:this.calcPremiumDiscount(candles_m15),
      score:          0,
      direction:      null,
    };

    result.score     = this._calcScore(result);
    result.direction = this._calcDirection(result);
    return result;
  }

  detectBoS(candles) {
    if (candles.length < 10) return { detected: false };
    const recent = candles.slice(-20);
    const highs = recent.map(c => c.high);
    const lows  = recent.map(c => c.low);

    const prevHigh = Math.max(...highs.slice(0, -3));
    const prevLow  = Math.min(...lows.slice(0, -3));
    const lastClose = recent[recent.length - 1].close;
    const lastHigh  = recent[recent.length - 1].high;
    const lastLow   = recent[recent.length - 1].low;

    if (lastHigh > prevHigh) return { detected: true, direction: 'BUY',  level: prevHigh, strength: (lastHigh - prevHigh) / prevHigh * 100 };
    if (lastLow  < prevLow)  return { detected: true, direction: 'SELL', level: prevLow,  strength: (prevLow - lastLow)  / prevLow  * 100 };
    return { detected: false };
  }

  detectCHoCH(candles) {
    if (candles.length < 15) return { detected: false };
    const recent = candles.slice(-30);

    // Détection swing highs/lows
    const swings = this._detectSwings(recent);
    if (swings.highs.length < 2 || swings.lows.length < 2) return { detected: false };

    const lastHH = swings.highs[swings.highs.length - 1];
    const prevHH = swings.highs[swings.highs.length - 2];
    const lastLL = swings.lows[swings.lows.length - 1];
    const prevLL = swings.lows[swings.lows.length - 2];

    // CHoCH bearish : nouveau lower high après une tendance haussière
    if (lastHH.price < prevHH.price && lastLL.price < prevLL.price) {
      return { detected: true, direction: 'SELL', type: 'bearish_choch', level: lastHH.price };
    }
    // CHoCH bullish : nouveau higher low après une tendance baissière
    if (lastLL.price > prevLL.price && lastHH.price > prevHH.price) {
      return { detected: true, direction: 'BUY', type: 'bullish_choch', level: lastLL.price };
    }
    return { detected: false };
  }

  detectOrderBlocks(candles) {
    if (candles.length < 10) return [];
    const blocks = [];
    const recent = candles.slice(-50);

    for (let i = 3; i < recent.length - 2; i++) {
      const c = recent[i];
      const prev = recent[i - 1];
      const next1 = recent[i + 1];
      const next2 = recent[i + 2];

      // Bullish OB : dernière bougie baissière avant un fort mouvement haussier
      if (prev.close < prev.open && next1.close > next1.open && next2.close > next2.open) {
        const moveSize = next2.close - prev.close;
        if (moveSize > 0) {
          blocks.push({
            type: 'bullish', top: prev.open, bottom: prev.close,
            mid: (prev.open + prev.close) / 2,
            strength: moveSize, index: i - 1, fresh: true
          });
        }
      }

      // Bearish OB : dernière bougie haussière avant un fort mouvement baissier
      if (prev.close > prev.open && next1.close < next1.open && next2.close < next2.open) {
        const moveSize = prev.close - next2.close;
        if (moveSize > 0) {
          blocks.push({
            type: 'bearish', top: prev.close, bottom: prev.open,
            mid: (prev.open + prev.close) / 2,
            strength: moveSize, index: i - 1, fresh: true
          });
        }
      }
    }

    return blocks.slice(-5); // Garder les 5 plus récents
  }

  detectFVG(candles) {
    if (candles.length < 3) return [];
    const fvgs = [];
    const recent = candles.slice(-30);

    for (let i = 2; i < recent.length; i++) {
      const c1 = recent[i - 2];
      const c3 = recent[i];

      // Bullish FVG : bas de la bougie 3 > haut de la bougie 1
      if (c3.low > c1.high) {
        fvgs.push({ type: 'bullish', top: c3.low, bottom: c1.high, mid: (c3.low + c1.high) / 2, index: i, filled: false });
      }
      // Bearish FVG : haut de la bougie 3 < bas de la bougie 1
      if (c3.high < c1.low) {
        fvgs.push({ type: 'bearish', top: c1.low, bottom: c3.high, mid: (c1.low + c3.high) / 2, index: i, filled: false });
      }
    }

    // Marquer les FVG déjà comblés
    const lastPrice = recent[recent.length - 1].close;
    fvgs.forEach(fvg => {
      if (fvg.type === 'bullish' && lastPrice <= fvg.bottom) fvg.filled = true;
      if (fvg.type === 'bearish' && lastPrice >= fvg.top)    fvg.filled = true;
    });

    return fvgs.filter(f => !f.filled).slice(-3);
  }

  detectLiquiditySweep(candles) {
    if (candles.length < 10) return { detected: false };
    const recent = candles.slice(-20);
    const swings = this._detectSwings(recent.slice(0, -3));
    const lastCandle = recent[recent.length - 1];
    const prevCandle = recent[recent.length - 2];

    // Sweep bearish : pic au-dessus d'un swing high puis retour en dessous
    for (const sh of swings.highs) {
      if (prevCandle.high > sh.price && lastCandle.close < sh.price) {
        return { detected: true, direction: 'SELL', sweptLevel: sh.price, type: 'high_sweep' };
      }
    }
    // Sweep bullish : pic en dessous d'un swing low puis retour au-dessus
    for (const sl of swings.lows) {
      if (prevCandle.low < sl.price && lastCandle.close > sl.price) {
        return { detected: true, direction: 'BUY', sweptLevel: sl.price, type: 'low_sweep' };
      }
    }
    return { detected: false };
  }

  calcPremiumDiscount(candles) {
    if (candles.length < 20) return { zone: 'neutral', ratio: 0.5 };
    const recent = candles.slice(-50);
    const high = Math.max(...recent.map(c => c.high));
    const low  = Math.min(...recent.map(c => c.low));
    const range = high - low;
    if (!range) return { zone: 'neutral', ratio: 0.5, high, low };

    const lastClose = recent[recent.length - 1].close;
    const ratio = (lastClose - low) / range; // 0=discount, 1=premium
    const eq = recent.slice(-10);
    const eqHigh = Math.max(...eq.map(c => c.high));
    const eqLow  = Math.min(...eq.map(c => c.low));

    return {
      high, low, range, ratio,
      equilibrium: (high + low) / 2,
      zone: ratio > 0.6 ? 'premium' : ratio < 0.4 ? 'discount' : 'equilibrium',
      equalHighs: this._findEqualLevels(recent.map(c => c.high)),
      equalLows:  this._findEqualLevels(recent.map(c => c.low)),
    };
  }

  _detectSwings(candles, strength = 2) {
    const highs = [], lows = [];
    for (let i = strength; i < candles.length - strength; i++) {
      const slice = candles.slice(i - strength, i + strength + 1);
      const pivot = candles[i];
      if (pivot.high === Math.max(...slice.map(c => c.high))) highs.push({ price: pivot.high, index: i });
      if (pivot.low  === Math.min(...slice.map(c => c.low)))  lows.push({ price: pivot.low,  index: i });
    }
    return { highs, lows };
  }

  _findEqualLevels(values, tolerance = 0.001) {
    const groups = [];
    for (let i = 0; i < values.length; i++) {
      for (let j = i + 1; j < values.length; j++) {
        if (Math.abs(values[i] - values[j]) / values[i] < tolerance) {
          groups.push({ level: (values[i] + values[j]) / 2, count: 2 });
        }
      }
    }
    return groups.slice(0, 3);
  }

  _calcScore(result) {
    let score = 0;
    if (result.bos?.detected)            score += 20;
    if (result.choch?.detected)          score += 20;
    if (result.orderBlocks?.length > 0)  score += 15;
    if (result.fvg?.length > 0)          score += 10;
    if (result.liquiditySweep?.detected) score += 20;
    const pd = result.premiumDiscount;
    if (pd?.zone === 'premium' || pd?.zone === 'discount') score += 15;
    return Math.min(100, score);
  }

  _calcDirection(result) {
    const votes = { BUY: 0, SELL: 0 };
    if (result.bos?.direction)            votes[result.bos.direction]            += 3;
    if (result.choch?.direction)          votes[result.choch.direction]          += 3;
    if (result.liquiditySweep?.direction) votes[result.liquiditySweep.direction] += 3;
    const pd = result.premiumDiscount;
    if (pd?.zone === 'premium')  votes.SELL += 2;
    if (pd?.zone === 'discount') votes.BUY  += 2;
    if (votes.BUY > votes.SELL)  return 'BUY';
    if (votes.SELL > votes.BUY)  return 'SELL';
    return null;
  }
}
