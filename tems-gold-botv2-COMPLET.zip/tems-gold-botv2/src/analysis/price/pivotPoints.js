import { calcPivotPoints } from '../../utils/math.js';

export class PivotPointAnalyzer {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles_h1, currentPrice) {
    if (!candles_h1 || candles_h1.length < 48) return { score: 0, direction: null };

    // Daily pivot (bougies des 24h précédentes)
    const yesterday = candles_h1.slice(-48, -24);
    const today     = candles_h1.slice(-24);
    if (!yesterday.length) return { score: 0, direction: null };

    const yHigh  = Math.max(...yesterday.map(c => c.high));
    const yLow   = Math.min(...yesterday.map(c => c.low));
    const yClose = yesterday[yesterday.length - 1].close;
    const daily  = { ...calcPivotPoints(yHigh, yLow, yClose), timeframe: 'daily' };

    // Weekly pivot
    const weekCandles = candles_h1.slice(-168); // 7j
    const wHigh  = Math.max(...weekCandles.map(c => c.high));
    const wLow   = Math.min(...weekCandles.map(c => c.low));
    const wClose = weekCandles[weekCandles.length - 1].close;
    const weekly = { ...calcPivotPoints(wHigh, wLow, wClose), timeframe: 'weekly' };

    // CPR (Central Pivot Range)
    const cprTop    = (yHigh + yLow) / 2;
    const cprBottom = (daily.pp * 2 - cprTop);
    const cprWidth  = Math.abs(cprTop - cprBottom);
    const narrowCPR = cprWidth < this.spec.pip * 15; // CPR étroit = journée de tendance probable

    // Trouver les niveaux les plus proches
    const allLevels = [
      { name: 'PP',     value: daily.pp, type: 'daily' },
      { name: 'R1',     value: daily.r1, type: 'daily_resist' },
      { name: 'R2',     value: daily.r2, type: 'daily_resist' },
      { name: 'R3',     value: daily.r3, type: 'daily_resist' },
      { name: 'S1',     value: daily.s1, type: 'daily_support' },
      { name: 'S2',     value: daily.s2, type: 'daily_support' },
      { name: 'S3',     value: daily.s3, type: 'daily_support' },
      { name: 'WPP',    value: weekly.pp, type: 'weekly' },
      { name: 'WR1',    value: weekly.r1, type: 'weekly_resist' },
      { name: 'WS1',    value: weekly.s1, type: 'weekly_support' },
      { name: 'CPR_T',  value: cprTop,    type: 'cpr' },
      { name: 'CPR_B',  value: cprBottom, type: 'cpr' },
    ];

    const tol = this.spec.pip * 8;
    const nearLevels = allLevels
      .map(l => ({ ...l, distance: Math.abs(currentPrice - l.value) }))
      .filter(l => l.distance <= tol * 3)
      .sort((a, b) => a.distance - b.distance);

    let score = 0;
    if (nearLevels.length > 0) {
      const nearest = nearLevels[0];
      score = nearest.distance <= tol ? 85 : nearest.distance <= tol * 2 ? 60 : 40;
    }

    // Direction : prix au-dessus du PP = haussier
    const direction = currentPrice > daily.pp ? 'BUY' : 'SELL';

    return { daily, weekly, cpr: { top: cprTop, bottom: cprBottom, width: cprWidth, narrow: narrowCPR }, nearLevels: nearLevels.slice(0, 3), score, direction, allLevels };
  }
}
