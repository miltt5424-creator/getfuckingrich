// Détection de 8 patterns de bougies japonaises

export class CandlePatternDetector {
  analyze(candles) {
    if (candles.length < 3) return { patterns: [], score: 0, direction: null };
    const last3 = candles.slice(-3);
    const [c1, c2, c3] = last3;
    const patterns = [];

    const bodySize  = c => Math.abs(c.close - c.open);
    const rangeSize = c => c.high - c.low;
    const isBull    = c => c.close > c.open;
    const isBear    = c => c.close < c.open;
    const upperWick = c => c.high - Math.max(c.close, c.open);
    const lowerWick = c => Math.min(c.close, c.open) - c.low;

    // Engulfing
    if (isBear(c2) && isBull(c3) && c3.open < c2.close && c3.close > c2.open)
      patterns.push({ name: 'bullish_engulfing', direction: 'BUY',  strength: 85 });
    if (isBull(c2) && isBear(c3) && c3.open > c2.close && c3.close < c2.open)
      patterns.push({ name: 'bearish_engulfing', direction: 'SELL', strength: 85 });

    // Hammer / Shooting Star
    if (lowerWick(c3) > bodySize(c3) * 2 && upperWick(c3) < bodySize(c3) * 0.5)
      patterns.push({ name: 'hammer', direction: 'BUY', strength: 70 });
    if (upperWick(c3) > bodySize(c3) * 2 && lowerWick(c3) < bodySize(c3) * 0.5)
      patterns.push({ name: 'shooting_star', direction: 'SELL', strength: 70 });

    // Doji
    if (bodySize(c3) < rangeSize(c3) * 0.1)
      patterns.push({ name: 'doji', direction: null, strength: 40 });

    // Pin Bar
    if (lowerWick(c3) > rangeSize(c3) * 0.6 && bodySize(c3) < rangeSize(c3) * 0.25)
      patterns.push({ name: 'pin_bar_bull', direction: 'BUY', strength: 80 });
    if (upperWick(c3) > rangeSize(c3) * 0.6 && bodySize(c3) < rangeSize(c3) * 0.25)
      patterns.push({ name: 'pin_bar_bear', direction: 'SELL', strength: 80 });

    // Inside Bar
    if (c3.high < c2.high && c3.low > c2.low)
      patterns.push({ name: 'inside_bar', direction: null, strength: 50 });

    // Morning / Evening Star
    if (isBear(c1) && bodySize(c2) < bodySize(c1) * 0.3 && isBull(c3) && c3.close > (c1.open + c1.close) / 2)
      patterns.push({ name: 'morning_star', direction: 'BUY', strength: 90 });
    if (isBull(c1) && bodySize(c2) < bodySize(c1) * 0.3 && isBear(c3) && c3.close < (c1.open + c1.close) / 2)
      patterns.push({ name: 'evening_star', direction: 'SELL', strength: 90 });

    // 3 White Soldiers / Black Crows
    if (isBull(c1) && isBull(c2) && isBull(c3) && c2.close > c1.close && c3.close > c2.close)
      patterns.push({ name: 'three_white_soldiers', direction: 'BUY', strength: 75 });
    if (isBear(c1) && isBear(c2) && isBear(c3) && c2.close < c1.close && c3.close < c2.close)
      patterns.push({ name: 'three_black_crows', direction: 'SELL', strength: 75 });

    // Marubozu
    if (isBull(c3) && upperWick(c3) < bodySize(c3) * 0.05 && lowerWick(c3) < bodySize(c3) * 0.05)
      patterns.push({ name: 'marubozu_bull', direction: 'BUY', strength: 70 });
    if (isBear(c3) && upperWick(c3) < bodySize(c3) * 0.05 && lowerWick(c3) < bodySize(c3) * 0.05)
      patterns.push({ name: 'marubozu_bear', direction: 'SELL', strength: 70 });

    const maxStrength = patterns.length ? Math.max(...patterns.map(p => p.strength)) : 0;
    const score = Math.min(100, maxStrength);

    const buyCount  = patterns.filter(p => p.direction === 'BUY').reduce((s,p) => s + p.strength, 0);
    const sellCount = patterns.filter(p => p.direction === 'SELL').reduce((s,p) => s + p.strength, 0);
    const direction = buyCount > sellCount ? 'BUY' : sellCount > buyCount ? 'SELL' : null;

    return { patterns, score, direction };
  }
}
