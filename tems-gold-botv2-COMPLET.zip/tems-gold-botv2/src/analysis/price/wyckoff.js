// Analyse de Wyckoff : détection des phases accumulation/distribution
// Phases : Accumulation (Spring → SOS), Distribution (UTAD → SOW)

export class WyckoffAnalyzer {
  analyze(candles) {
    if (candles.length < 50) return { phase: 'unknown', score: 0, direction: null };

    const recent = candles.slice(-100);
    const closes  = recent.map(c => c.close);
    const volumes = recent.map(c => c.volume || 1);
    const highs   = recent.map(c => c.high);
    const lows    = recent.map(c => c.low);

    const range   = this._detectTradingRange(recent);
    const phase   = this._detectPhase(recent, range, volumes);
    const spring  = this._detectSpring(recent, range);
    const utad    = this._detectUTAD(recent, range);
    const sos     = this._detectSOS(recent, range);
    const sow     = this._detectSOW(recent, range);

    let direction = null, score = 40;

    if (spring?.detected)      { direction = 'BUY';  score = 80; }
    else if (sos?.detected)    { direction = 'BUY';  score = 75; }
    else if (utad?.detected)   { direction = 'SELL'; score = 80; }
    else if (sow?.detected)    { direction = 'SELL'; score = 75; }
    else if (phase === 'phase_c_accum') { direction = 'BUY';  score = 70; }
    else if (phase === 'phase_c_dist')  { direction = 'SELL'; score = 70; }

    return { phase, range, spring, utad, sos, sow, direction, score };
  }

  _detectTradingRange(candles) {
    const last60 = candles.slice(-60);
    const high   = Math.max(...last60.map(c => c.high));
    const low    = Math.min(...last60.map(c => c.low));
    const mid    = (high + low) / 2;
    const width  = high - low;
    const isRange = width / mid < 0.02; // Range < 2% = consolidation
    return { high, low, mid, width, isRange };
  }

  _detectPhase(candles, range, volumes) {
    if (!range.isRange) return 'trending';
    const recent10 = candles.slice(-10);
    const avgVolRecent = volumes.slice(-10).reduce((a,b) => a+b,0) / 10;
    const avgVolAll    = volumes.reduce((a,b) => a+b,0) / volumes.length;
    const volExpanding = avgVolRecent > avgVolAll * 1.3;
    const priceInLower = recent10[recent10.length-1].close < range.mid;

    if (priceInLower && volExpanding)  return 'phase_c_accum'; // Spring probable
    if (!priceInLower && volExpanding) return 'phase_c_dist';  // UTAD probable
    if (priceInLower)  return 'phase_b_accum';
    return 'phase_b_dist';
  }

  _detectSpring(candles, range) {
    // Spring = prix perce le bas du range puis remonte rapidement (fausse sortie baissière)
    const recent5 = candles.slice(-5);
    const prevLow = range.low;
    const springCandle = recent5.find(c => c.low < prevLow);
    if (!springCandle) return { detected: false };
    const recovery = recent5[recent5.length - 1].close > prevLow;
    return { detected: recovery, level: prevLow, springLow: springCandle?.low, strength: recovery ? 'confirmed' : 'unconfirmed' };
  }

  _detectUTAD(candles, range) {
    // UTAD = prix perce le haut du range puis revient dedans (fausse sortie haussière)
    const recent5 = candles.slice(-5);
    const prevHigh = range.high;
    const utadCandle = recent5.find(c => c.high > prevHigh);
    if (!utadCandle) return { detected: false };
    const reversal = recent5[recent5.length - 1].close < prevHigh;
    return { detected: reversal, level: prevHigh, utadHigh: utadCandle?.high, strength: reversal ? 'confirmed' : 'unconfirmed' };
  }

  _detectSOS(candles, range) {
    // Sign of Strength = breakout haussier du range sur fort volume
    const last3 = candles.slice(-3);
    const breakout = last3.some(c => c.close > range.high);
    const strongVol = (last3[last3.length-1].volume || 1) > (candles.slice(-20).reduce((a,c) => a + (c.volume||1), 0) / 20) * 1.5;
    return { detected: breakout && strongVol, level: range.high };
  }

  _detectSOW(candles, range) {
    // Sign of Weakness = breakout baissier du range
    const last3 = candles.slice(-3);
    const breakdown = last3.some(c => c.close < range.low);
    const strongVol = (last3[last3.length-1].volume || 1) > (candles.slice(-20).reduce((a,c) => a + (c.volume||1), 0) / 20) * 1.5;
    return { detected: breakdown && strongVol, level: range.low };
  }
}
