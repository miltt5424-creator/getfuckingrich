import { stdDev } from '../../utils/math.js';

export class HistoricalVolatility {
  analyze(candles, period = 20) {
    if (candles.length < period + 1) return { score: 50, ratio: 1, regime: 'normal' };
    const closes = candles.map(c => c.close);

    // Log returns
    const logReturns = [];
    for (let i = 1; i < closes.length; i++) {
      logReturns.push(Math.log(closes[i] / closes[i - 1]));
    }

    const currentVol  = stdDev(logReturns.slice(-period)) * Math.sqrt(252 * 1440); // annualisée M1
    const historicalVol = stdDev(logReturns.slice(-period * 3)) * Math.sqrt(252 * 1440);
    const ratio = historicalVol > 0 ? currentVol / historicalVol : 1;

    // Régime de volatilité
    const regime = ratio < 0.5 ? 'very_low' : ratio < 0.8 ? 'low' : ratio < 1.2 ? 'normal' : ratio < 1.8 ? 'elevated' : 'extreme';
    const suitable = regime !== 'extreme';
    const score = regime === 'low' ? 85 : regime === 'normal' ? 75 : regime === 'elevated' ? 50 : 15;

    // Détection d'expansion imminente (vol basse depuis longtemps = explosion probable)
    const recentVol  = stdDev(logReturns.slice(-5))  * Math.sqrt(252 * 1440);
    const expansionLikely = recentVol < historicalVol * 0.4;

    return { currentVol: currentVol * 100, historicalVol: historicalVol * 100, ratio, regime, suitable, score, expansionLikely,
      warning: !suitable ? `Volatilité extrême (${(ratio).toFixed(2)}x la normale)` : null };
  }
}
