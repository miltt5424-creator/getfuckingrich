import { BollingerBands, ATR } from 'technicalindicators';
import { ema } from '../../utils/math.js';

export class BollingerKeltnerAnalyzer {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    if (candles.length < 25) return { score: 0, squeeze: false, direction: null };
    const closes = candles.map(c => c.close);
    const highs  = candles.map(c => c.high);
    const lows   = candles.map(c => c.low);

    const bbPeriod = this.cfg.bb_period || 20;
    const bbStd    = this.cfg.bb_std    || 2;
    const kcPeriod = this.cfg.keltner_period || 20;
    const kcMult   = this.cfg.keltner_mult   || 1.5;

    try {
      const bb = BollingerBands.calculate({ values: closes, period: bbPeriod, stdDev: bbStd });
      const atrRes = ATR.calculate({ high: highs, low: lows, close: closes, period: kcPeriod });
      const lastBB  = bb[bb.length - 1];
      const lastATR = atrRes[atrRes.length - 1];
      const midEMA  = ema(closes, kcPeriod);

      const kcUpper = midEMA + kcMult * lastATR;
      const kcLower = midEMA - kcMult * lastATR;

      // Squeeze : quand BB est à l'intérieur de KC = compression de volatilité
      const squeeze  = lastBB.upper < kcUpper && lastBB.lower > kcLower;
      const price    = closes[closes.length - 1];
      const momentum = closes[closes.length - 1] - closes[closes.length - 1 - 12 < 0 ? 0 : closes.length - 13];

      const breakoutUp   = !squeeze && price > lastBB.upper;
      const breakoutDown = !squeeze && price < lastBB.lower;
      const score        = squeeze ? 80 : breakoutUp || breakoutDown ? 85 : 40;
      const direction    = squeeze ? (momentum > 0 ? 'BUY' : 'SELL') : breakoutUp ? 'BUY' : breakoutDown ? 'SELL' : null;

      return { bb: lastBB, kcUpper, kcLower, squeeze, breakoutUp, breakoutDown, momentum, score, direction,
        bandwidth: (lastBB.upper - lastBB.lower) / lastBB.middle * 100 };
    } catch (e) { return { score: 0, squeeze: false, direction: null, error: e.message }; }
  }
}
