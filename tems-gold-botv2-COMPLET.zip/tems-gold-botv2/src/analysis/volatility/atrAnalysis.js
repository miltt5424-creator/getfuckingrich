import { ATR } from 'technicalindicators';

export class ATRAnalysis {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    if (candles.length < 15) return { score: 50, atr: null, suitable: true };
    const period = this.cfg.atr_period || 14;
    try {
      const results = ATR.calculate({
        high:  candles.map(c => c.high),
        low:   candles.map(c => c.low),
        close: candles.map(c => c.close),
        period,
      });
      const atr      = results[results.length - 1];
      const atrPrev  = results[results.length - 6] || atr;
      const atrAvg   = results.slice(-20).reduce((a,b) => a+b, 0) / Math.min(20, results.length);
      const ratio    = atr / atrAvg;

      // Trop calme = marché endormi, pas d'entrée / Trop volatile = news, dangereux
      const tooCalm    = ratio < 0.5;
      const tooVolatile= ratio > 2.5;
      const suitable   = !tooCalm && !tooVolatile;
      const expanding  = atr > atrPrev * 1.1;
      const contracting= atr < atrPrev * 0.9;

      const score = tooCalm ? 10 : tooVolatile ? 15 : ratio < 0.8 ? 60 : ratio < 1.5 ? 90 : 50;
      const gridStep = atr * (this.cfg.grid_step_atr_mult || 1.2);

      return { atr, atrAvg, ratio, tooCalm, tooVolatile, suitable, expanding, contracting, gridStep, score,
        warning: tooCalm ? 'ATR faible — marché endormi' : tooVolatile ? 'ATR spike — news probables' : null };
    } catch (e) { return { score: 50, suitable: true, error: e.message }; }
  }

  calcGridStep(atr) {
    return atr * (this.cfg.grid_step_atr_mult || 1.2);
  }
}
