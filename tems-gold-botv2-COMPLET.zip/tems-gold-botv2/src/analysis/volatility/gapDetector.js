export class GapDetector {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles) {
    if (candles.length < 2) return { gaps: [], score: 50 };
    const gaps = [];
    const recent = candles.slice(-200);

    for (let i = 1; i < recent.length; i++) {
      const prev = recent[i - 1];
      const curr = recent[i];
      const gapUp   = curr.open > prev.close + this.spec.pip * 5;
      const gapDown = curr.open < prev.close - this.spec.pip * 5;

      if (gapUp || gapDown) {
        const size = Math.abs(curr.open - prev.close);
        const filled = gapUp
          ? recent.slice(i).some(c => c.low <= prev.close)
          : recent.slice(i).some(c => c.high >= prev.close);
        gaps.push({ type: gapUp ? 'gap_up' : 'gap_down', top: Math.max(curr.open, prev.close), bottom: Math.min(curr.open, prev.close), size, index: i, filled, });
      }
    }

    const openGaps = gaps.filter(g => !g.filled);
    const lastClose = recent[recent.length - 1].close;
    const nearestGap = openGaps.sort((a, b) => Math.abs((a.top+a.bottom)/2 - lastClose) - Math.abs((b.top+b.bottom)/2 - lastClose))[0];

    return {
      gaps: openGaps.slice(-3), nearestGap, totalGaps: gaps.length, openGapsCount: openGaps.length,
      score: nearestGap ? 70 : 50,
      direction: nearestGap ? (lastClose < nearestGap.bottom ? 'BUY' : 'SELL') : null,
    };
  }
}
