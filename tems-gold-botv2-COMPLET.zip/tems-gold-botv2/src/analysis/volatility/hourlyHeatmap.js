// Heatmap statistique de la volatilité par heure UTC
// Construit à partir de l'historique des bougies M1

export class HourlyHeatmap {
  constructor() {
    // Heatmap prédéfinie XAUUSD (peut être recalculée sur l'historique réel)
    this.defaultHeatmap = {
      0: 0.3, 1: 0.2, 2: 0.2, 3: 0.3, 4: 0.3, 5: 0.4, 6: 0.5, 7: 0.7,
      8: 0.9, 9: 1.0, 10: 0.9, 11: 0.8, 12: 0.7, 13: 1.0, 14: 1.0,
      15: 0.9, 16: 0.8, 17: 0.7, 18: 0.5, 19: 0.4, 20: 0.3, 21: 0.3, 22: 0.2, 23: 0.2,
    };
    this.customHeatmap = null;
  }

  buildFromHistory(candles) {
    const hourBuckets = {};
    for (let h = 0; h < 24; h++) hourBuckets[h] = [];

    candles.forEach(c => {
      const h = new Date(c.time).getUTCHours();
      const range = c.high - c.low;
      if (range > 0) hourBuckets[h].push(range);
    });

    const maxAvg = Math.max(...Object.values(hourBuckets).map(v => v.length ? v.reduce((a,b) => a+b,0)/v.length : 0));
    if (!maxAvg) return;

    this.customHeatmap = {};
    for (let h = 0; h < 24; h++) {
      const avg = hourBuckets[h].length ? hourBuckets[h].reduce((a,b) => a+b,0)/hourBuckets[h].length : 0;
      this.customHeatmap[h] = maxAvg > 0 ? avg / maxAvg : 0;
    }
  }

  analyze() {
    const h = new Date().getUTCHours();
    const map = this.customHeatmap || this.defaultHeatmap;
    const activity = map[h] || 0.5;
    const score = activity >= 0.8 ? 90 : activity >= 0.6 ? 70 : activity >= 0.4 ? 50 : 20;
    const suitable = activity >= 0.4;

    return {
      hour: h, activity, suitable, score, heatmap: map,
      bestHours: Object.entries(map).filter(([,v]) => v >= 0.8).map(([h]) => parseInt(h)),
      warning: !suitable ? `Heure peu active (${(activity*100).toFixed(0)}% de l'activité max)` : null,
    };
  }
}
