import { EMA, PSAR } from 'technicalindicators';
import { ema as calcEma } from '../../utils/math.js';

export class TrendIndicators {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    const closes = candles.map(c => c.close);
    const highs  = candles.map(c => c.high);
    const lows   = candles.map(c => c.low);

    const ema20  = calcEma(closes, this.cfg.ema_fast  || 20);
    const ema50  = calcEma(closes, this.cfg.ema_mid   || 50);
    const ema200 = calcEma(closes, this.cfg.ema_slow  || 200);

    const currentPrice = closes[closes.length - 1];
    const alignment = this._checkAlignment(currentPrice, ema20, ema50, ema200);
    const supertrend = this._calcSupertrend(candles, this.cfg.supertrend_period || 10, this.cfg.supertrend_mult || 3);
    const psar = this._calcPSAR(highs, lows, closes);

    const score     = this._calcScore(alignment, supertrend, psar, currentPrice);
    const direction = this._calcDirection(alignment, supertrend, psar, currentPrice);

    return { ema20, ema50, ema200, alignment, supertrend, psar, score, direction, currentPrice };
  }

  _checkAlignment(price, e20, e50, e200) {
    if (!e20 || !e50) return { type: 'unknown', strength: 0 };
    const bullish = e200 ? price > e20 && e20 > e50 && e50 > e200 : price > e20 && e20 > e50;
    const bearish = e200 ? price < e20 && e20 < e50 && e50 < e200 : price < e20 && e20 < e50;
    const goldCross = e20 && e50 && e20 > e50;
    const deathCross = e20 && e50 && e20 < e50;
    return {
      type: bullish ? 'full_bullish' : bearish ? 'full_bearish' : goldCross ? 'golden_cross' : deathCross ? 'death_cross' : 'mixed',
      bullish, bearish,
      strength: bullish || bearish ? 100 : 50
    };
  }

  _calcSupertrend(candles, period, multiplier) {
    if (candles.length < period + 1) return null;
    const recent = candles.slice(-(period * 3));
    const closes = recent.map(c => c.close);
    const highs  = recent.map(c => c.high);
    const lows   = recent.map(c => c.low);

    // ATR
    const atrValues = [];
    for (let i = 1; i < recent.length; i++) {
      const tr = Math.max(highs[i] - lows[i], Math.abs(highs[i] - closes[i-1]), Math.abs(lows[i] - closes[i-1]));
      atrValues.push(tr);
    }
    const atr = atrValues.slice(-period).reduce((a,b) => a+b,0) / period;

    const hl2 = (highs[highs.length-1] + lows[lows.length-1]) / 2;
    const upperBand = hl2 + multiplier * atr;
    const lowerBand = hl2 - multiplier * atr;
    const price = closes[closes.length-1];
    const trend = price > lowerBand ? 'BUY' : 'SELL';

    return { upperBand, lowerBand, trend, atr };
  }

  _calcPSAR(highs, lows, closes) {
    if (highs.length < 10) return null;
    try {
      const results = PSAR.calculate({ high: highs, low: lows, step: 0.02, max: 0.2 });
      const last = results[results.length - 1];
      const price = closes[closes.length - 1];
      return { value: last, trend: price > last ? 'BUY' : 'SELL' };
    } catch { return null; }
  }

  _calcScore(alignment, supertrend, psar, price) {
    let score = 0;
    if (alignment.type === 'full_bullish' || alignment.type === 'full_bearish') score += 40;
    else if (alignment.type === 'golden_cross' || alignment.type === 'death_cross') score += 25;
    if (supertrend) score += 30;
    if (psar) score += 30;
    return Math.min(100, score);
  }

  _calcDirection(alignment, supertrend, psar, price) {
    const votes = { BUY: 0, SELL: 0 };
    if (alignment.bullish) votes.BUY += 3;
    if (alignment.bearish) votes.SELL += 3;
    if (supertrend?.trend === 'BUY')  votes.BUY++;
    if (supertrend?.trend === 'SELL') votes.SELL++;
    if (psar?.trend === 'BUY')  votes.BUY++;
    if (psar?.trend === 'SELL') votes.SELL++;
    return votes.BUY > votes.SELL ? 'BUY' : votes.SELL > votes.BUY ? 'SELL' : null;
  }
}
