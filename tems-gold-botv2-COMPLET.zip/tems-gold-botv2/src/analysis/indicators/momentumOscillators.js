import { RSI, MACD, StochasticRSI, CCI, WilliamsR } from 'technicalindicators';

export class MomentumOscillators {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    const closes = candles.map(c => c.close);
    const highs  = candles.map(c => c.high);
    const lows   = candles.map(c => c.low);

    const rsi       = this._calcRSI(closes);
    const macd      = this._calcMACD(closes);
    const stochRsi  = this._calcStochRSI(closes);
    const cci       = this._calcCCI(highs, lows, closes);
    const williamsR = this._calcWilliamsR(highs, lows, closes);
    const momentum  = this._calcMomentum(closes);

    const score     = this._calcScore({ rsi, macd, stochRsi, cci, williamsR });
    const direction = this._calcDirection({ rsi, macd, stochRsi, cci, williamsR });
    const divergence = this._detectDivergence(candles, closes);

    return { rsi, macd, stochRsi, cci, williamsR, momentum, divergence, score, direction };
  }

  _calcRSI(closes) {
    if (closes.length < 15) return null;
    const period = this.cfg.rsi_period || 14;
    const results = RSI.calculate({ values: closes, period });
    const value = results[results.length - 1];
    return {
      value,
      oversold:    value < (this.cfg.rsi_oversold   || 30),
      overbought:  value > (this.cfg.rsi_overbought || 70),
      zone: value < 30 ? 'oversold' : value > 70 ? 'overbought' : value < 45 ? 'bearish' : value > 55 ? 'bullish' : 'neutral'
    };
  }

  _calcMACD(closes) {
    if (closes.length < 35) return null;
    const results = MACD.calculate({
      values: closes,
      fastPeriod:   this.cfg.macd_fast   || 12,
      slowPeriod:   this.cfg.macd_slow   || 26,
      signalPeriod: this.cfg.macd_signal || 9,
      SimpleMAOscillator: false, SimpleMASignal: false
    });
    if (!results.length) return null;
    const last = results[results.length - 1];
    const prev = results[results.length - 2];
    return {
      macd:      last.MACD,
      signal:    last.signal,
      histogram: last.histogram,
      crossUp:   prev?.MACD < prev?.signal && last.MACD > last.signal,
      crossDown: prev?.MACD > prev?.signal && last.MACD < last.signal,
      bullish:   last.MACD > last.signal && last.histogram > 0,
      bearish:   last.MACD < last.signal && last.histogram < 0,
    };
  }

  _calcStochRSI(closes) {
    if (closes.length < 20) return null;
    try {
      const results = StochasticRSI.calculate({
        values: closes,
        rsiPeriod:       this.cfg.stoch_rsi_period || 14,
        stochasticPeriod:this.cfg.stoch_rsi_period || 14,
        kPeriod:         this.cfg.stoch_rsi_k || 3,
        dPeriod:         this.cfg.stoch_rsi_d || 3,
      });
      if (!results.length) return null;
      const last = results[results.length - 1];
      return {
        k: last.k, d: last.d,
        oversold:   last.k < 20 && last.d < 20,
        overbought: last.k > 80 && last.d > 80,
        crossUp:    last.k > last.d,
        crossDown:  last.k < last.d,
      };
    } catch { return null; }
  }

  _calcCCI(highs, lows, closes) {
    if (closes.length < 22) return null;
    const period = this.cfg.cci_period || 20;
    const results = CCI.calculate({ high: highs, low: lows, close: closes, period });
    const value = results[results.length - 1];
    return {
      value,
      overbought: value > 100,
      oversold:   value < -100,
      extreme_overbought: value > 200,
      extreme_oversold:   value < -200,
    };
  }

  _calcWilliamsR(highs, lows, closes) {
    if (closes.length < 16) return null;
    const period = this.cfg.williams_period || 14;
    const results = WilliamsR.calculate({ high: highs, low: lows, close: closes, period });
    const value = results[results.length - 1];
    return { value, oversold: value < -80, overbought: value > -20 };
  }

  _calcMomentum(closes, period = 10) {
    if (closes.length < period + 1) return null;
    const value = closes[closes.length - 1] - closes[closes.length - 1 - period];
    return { value, bullish: value > 0, bearish: value < 0 };
  }

  _detectDivergence(candles, closes) {
    if (candles.length < 20) return { bullish: false, bearish: false };
    const recent = candles.slice(-20);
    const recentCloses = closes.slice(-20);

    const priceHighs = recent.map(c => c.high);
    const priceLows  = recent.map(c => c.low);

    try {
      const rsiVals = RSI.calculate({ values: recentCloses, period: 14 });
      if (rsiVals.length < 5) return { bullish: false, bearish: false };

      // Divergence baissière : prix fait un nouveau haut mais RSI non
      const pHigh1 = Math.max(...priceHighs.slice(-10, -5));
      const pHigh2 = Math.max(...priceHighs.slice(-5));
      const rHigh1 = Math.max(...rsiVals.slice(-10, -5));
      const rHigh2 = Math.max(...rsiVals.slice(-5));

      const pLow1 = Math.min(...priceLows.slice(-10, -5));
      const pLow2 = Math.min(...priceLows.slice(-5));
      const rLow1 = Math.min(...rsiVals.slice(-10, -5));
      const rLow2 = Math.min(...rsiVals.slice(-5));

      return {
        bearish: pHigh2 > pHigh1 && rHigh2 < rHigh1,
        bullish: pLow2  < pLow1  && rLow2  > rLow1,
      };
    } catch { return { bullish: false, bearish: false }; }
  }

  _calcScore({ rsi, macd, stochRsi, cci, williamsR }) {
    let score = 0;
    if (rsi?.oversold || rsi?.overbought) score += 20;
    if (macd?.crossUp || macd?.crossDown) score += 25;
    if (macd?.bullish || macd?.bearish)   score += 15;
    if (stochRsi?.oversold || stochRsi?.overbought) score += 20;
    if (cci?.overbought || cci?.oversold) score += 10;
    if (williamsR?.oversold || williamsR?.overbought) score += 10;
    return Math.min(100, score);
  }

  _calcDirection({ rsi, macd, stochRsi, cci, williamsR }) {
    const v = { BUY: 0, SELL: 0 };
    if (rsi?.oversold)   v.BUY  += 2; if (rsi?.overbought)   v.SELL += 2;
    if (macd?.crossUp)   v.BUY  += 3; if (macd?.crossDown)   v.SELL += 3;
    if (macd?.bullish)   v.BUY  += 2; if (macd?.bearish)     v.SELL += 2;
    if (stochRsi?.oversold)   v.BUY  += 2; if (stochRsi?.overbought)  v.SELL += 2;
    if (stochRsi?.crossUp)    v.BUY  += 1; if (stochRsi?.crossDown)   v.SELL += 1;
    if (cci?.oversold)   v.BUY  += 1; if (cci?.overbought)   v.SELL += 1;
    if (williamsR?.oversold) v.BUY += 1; if (williamsR?.overbought) v.SELL += 1;
    return v.BUY > v.SELL ? 'BUY' : v.SELL > v.BUY ? 'SELL' : null;
  }
}
