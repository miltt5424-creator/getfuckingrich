import { IchimokuCloud } from 'technicalindicators';

export class IchimokuAnalyzer {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    if (candles.length < 60) return { score: 0, direction: null, cloud: null };
    try {
      const results = IchimokuCloud.calculate({
        high:            candles.map(c => c.high),
        low:             candles.map(c => c.low),
        conversionPeriod: this.cfg.ichimoku_tenkan || 9,
        basePeriod:       this.cfg.ichimoku_kijun  || 26,
        simpleCloudConversion: false,
        spanPeriod:       this.cfg.ichimoku_senkou || 52,
      });
      if (!results.length) return { score: 0, direction: null };
      const last = results[results.length - 1];
      const price = candles[candles.length - 1].close;

      const aboveCloud = price > Math.max(last.spanA, last.spanB);
      const belowCloud = price < Math.min(last.spanA, last.spanB);
      const inCloud    = !aboveCloud && !belowCloud;
      const bullishCloud = last.spanA > last.spanB;

      const tkCross = last.conversion > last.base;
      const score = aboveCloud && bullishCloud ? 90 : belowCloud && !bullishCloud ? 90 : inCloud ? 30 : 50;
      const direction = aboveCloud ? 'BUY' : belowCloud ? 'SELL' : tkCross ? 'BUY' : 'SELL';

      return { conversion: last.conversion, base: last.base, spanA: last.spanA, spanB: last.spanB, aboveCloud, belowCloud, inCloud, bullishCloud, tkCross, score, direction };
    } catch { return { score: 0, direction: null }; }
  }
}
