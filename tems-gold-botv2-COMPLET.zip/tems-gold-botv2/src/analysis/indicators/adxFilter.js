import { ADX } from 'technicalindicators';

export class ADXFilter {
  constructor(config) { this.cfg = config.indicators; }

  analyze(candles) {
    if (candles.length < 20) return { score: 50, trendStrength: 'unknown', adx: null, suitable: true };
    const period = this.cfg.adx_period || 14;
    const strong = this.cfg.adx_strong_trend || 25;

    try {
      const results = ADX.calculate({
        high:   candles.map(c => c.high),
        low:    candles.map(c => c.low),
        close:  candles.map(c => c.close),
        period,
      });
      if (!results.length) return { score: 50, suitable: true };

      const last = results[results.length - 1];
      const adx  = last.adx;
      const pdi  = last.pdi;
      const mdi  = last.mdi;

      // Pour la Martingale, un ADX faible (range) est IDÉAL
      // Un ADX fort = tendance forte = risque pour la Martingale
      const suitable  = adx < strong;
      const trendStrength = adx < 15 ? 'flat' : adx < 25 ? 'weak' : adx < 40 ? 'moderate' : adx < 60 ? 'strong' : 'very_strong';

      // Score inversé : plus ADX est faible, mieux c'est pour nous
      const score = adx < 15 ? 90 : adx < 20 ? 80 : adx < 25 ? 70 : adx < 35 ? 50 : adx < 50 ? 30 : 10;
      const direction = pdi > mdi ? 'BUY' : 'SELL';

      return { adx, pdi, mdi, trendStrength, suitable, score, direction, warning: !suitable ? `ADX élevé (${adx.toFixed(1)}) — tendance forte, grille risquée` : null };
    } catch (e) {
      return { score: 50, suitable: true, error: e.message };
    }
  }
}
