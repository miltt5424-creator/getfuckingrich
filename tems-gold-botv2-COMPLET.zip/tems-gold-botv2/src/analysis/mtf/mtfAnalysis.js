import { ema } from '../../utils/math.js';
import { RSI } from 'technicalindicators';

export class MTFAnalysis {
  analyze({ candles_m1, candles_m5, candles_m15, candles_h1, candles_h4 }) {
    const h4Bias  = candles_h4  ? this._calcBias(candles_h4,  'H4')  : null;
    const h1Bias  = candles_h1  ? this._calcBias(candles_h1,  'H1')  : null;
    const m15Bias = candles_m15 ? this._calcBias(candles_m15, 'M15') : null;
    const m5Bias  = candles_m5  ? this._calcBias(candles_m5,  'M5')  : null;
    const m1Bias  = candles_m1  ? this._calcBias(candles_m1,  'M1')  : null;

    const aligned  = this._checkAlignment({ h4Bias, h1Bias, m15Bias, m5Bias });
    const score    = this._calcScore({ h4Bias, h1Bias, m15Bias, m5Bias, aligned });
    const direction = aligned.direction;

    return { h4Bias, h1Bias, m15Bias, m5Bias, m1Bias, aligned, score, direction };
  }

  _calcBias(candles, tf) {
    if (candles.length < 50) return { tf, direction: null, strength: 0 };
    const closes = candles.map(c => c.close);
    const e20 = ema(closes, 20);
    const e50 = ema(closes, 50);
    const price = closes[closes.length - 1];

    let rsi = 50;
    try {
      const rsiArr = RSI.calculate({ values: closes, period: 14 });
      rsi = rsiArr[rsiArr.length - 1] || 50;
    } catch {}

    const bullish = price > e20 && e20 > e50;
    const bearish = price < e20 && e20 < e50;
    const strength = bullish || bearish ? Math.min(100, Math.abs(price - e50) / e50 * 10000) : 0;
    const direction = bullish ? 'BUY' : bearish ? 'SELL' : null;

    return { tf, direction, strength, ema20: e20, ema50: e50, price, rsi, bullish, bearish };
  }

  _checkAlignment({ h4Bias, h1Bias, m15Bias, m5Bias }) {
    const biases = [h4Bias, h1Bias, m15Bias, m5Bias].filter(Boolean);
    const buys   = biases.filter(b => b.direction === 'BUY').length;
    const sells  = biases.filter(b => b.direction === 'SELL').length;
    const total  = biases.length;

    const fullyAligned = buys === total || sells === total;
    const mostly       = buys >= total * 0.75 || sells >= total * 0.75;
    const direction    = buys > sells ? 'BUY' : sells > buys ? 'SELL' : null;

    return { fullyAligned, mostly, direction, buyCount: buys, sellCount: sells, total };
  }

  _calcScore({ h4Bias, h1Bias, m15Bias, m5Bias, aligned }) {
    let score = 0;
    if (h4Bias?.direction)  score += 30; // H4 = poids le plus fort
    if (h1Bias?.direction)  score += 25;
    if (m15Bias?.direction) score += 25;
    if (m5Bias?.direction)  score += 20;
    if (aligned.fullyAligned) score = Math.min(100, score + 20);
    else if (!aligned.mostly) score = Math.max(0, score - 20);
    return Math.min(100, score);
  }
}
