export class BiasCalculator {
  // Calcule un score directionnel pondéré sur tous les timeframes
  calc({ h4Bias, h1Bias, m15Bias, m5Bias }) {
    const weights = { H4: 40, H1: 35, M15: 15, M5: 10 };
    const biasMap = { H4: h4Bias, H1: h1Bias, M15: m15Bias, M5: m5Bias };

    let buyScore = 0, sellScore = 0, totalWeight = 0;

    for (const [tf, bias] of Object.entries(biasMap)) {
      if (!bias?.direction) continue;
      const w = weights[tf] || 0;
      totalWeight += w;
      if (bias.direction === 'BUY')  buyScore  += w * (bias.strength || 50) / 100;
      if (bias.direction === 'SELL') sellScore += w * (bias.strength || 50) / 100;
    }

    if (!totalWeight) return { buyScore: 0, sellScore: 0, direction: null, confidence: 0 };

    const normBuy  = buyScore  / totalWeight * 100;
    const normSell = sellScore / totalWeight * 100;
    const direction  = normBuy > normSell ? 'BUY' : normSell > normBuy ? 'SELL' : null;
    const confidence = Math.abs(normBuy - normSell);

    return { buyScore: normBuy, sellScore: normSell, direction, confidence,
      strong: confidence > 40, moderate: confidence > 20 && confidence <= 40, weak: confidence <= 20 };
  }
}
