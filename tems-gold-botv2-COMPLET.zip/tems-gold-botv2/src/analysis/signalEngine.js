// ============================================================
//  signalEngine.js — Orchestrateur principal du Signal Engine
//  Appelle les 6 couches d'analyse et retourne le signal final
// ============================================================

import { SMCDetector }            from './price/smcDetector.js';
import { HLZDetector }            from './price/hlzDetector.js';
import { FibonacciAnalyzer }      from './price/fibonacci.js';
import { CandlePatternDetector }  from './price/candlePatterns.js';
import { TrendIndicators }        from './indicators/trendIndicators.js';
import { MomentumOscillators }    from './indicators/momentumOscillators.js';
import { ADXFilter }              from './indicators/adxFilter.js';
import { IchimokuAnalyzer }       from './indicators/ichimoku.js';
import { ATRAnalysis }            from './volatility/atrAnalysis.js';
import { BollingerKeltnerAnalyzer } from './volatility/bollingerKeltner.js';
import { HistoricalVolatility }   from './volatility/historicalVolatility.js';
import { HourlyHeatmap }          from './volatility/hourlyHeatmap.js';
import { GapDetector }            from './volatility/gapDetector.js';
import { VolumeProfileAnalyzer }  from './volume/volumeProfile.js';
import { VWAPAnalyzer }           from './volume/vwap.js';
import { OBVAnalyzer }            from './volume/obvAnalysis.js';
import { VolumeDeltaAnalyzer }    from './volume/volumeDelta.js';
import { ImbalanceZoneDetector }  from './volume/imbalanceZones.js';
import { TickVolumeAnalyzer }     from './volume/tickVolume.js';
import { CorrelationAnalyzer }    from './macro/correlations.js';
import { NewsCalendar }           from './macro/newsCalendar.js';
import { FearGreedProxy }         from './macro/fearGreedProxy.js';
import { COTReport }              from './macro/cotReport.js';
import { OpenInterestAnalyzer }   from './macro/openInterest.js';
import { MTFAnalysis }            from './mtf/mtfAnalysis.js';
import { BiasCalculator }         from './mtf/biasCalculator.js';
import { ScoreEngine }            from './scoreEngine.js';
import logger                     from '../utils/logger.js';

export class SignalEngine {
  constructor(config) {
    this.cfg = config;
    const sym = config.getEnabledSymbols()[0];

    // Instanciation de tous les analyseurs
    this.smc          = new SMCDetector(config);
    this.hlz          = new HLZDetector(sym);
    this.fibonacci    = new FibonacciAnalyzer(sym);
    this.candles      = new CandlePatternDetector();
    this.trend        = new TrendIndicators(config);
    this.momentum     = new MomentumOscillators(config);
    this.adx          = new ADXFilter(config);
    this.ichimoku     = new IchimokuAnalyzer(config);
    this.atr          = new ATRAnalysis(config);
    this.bollinger    = new BollingerKeltnerAnalyzer(config);
    this.histVol      = new HistoricalVolatility();
    this.heatmap      = new HourlyHeatmap();
    this.gaps         = new GapDetector(sym);
    this.volProfile   = new VolumeProfileAnalyzer();
    this.vwap         = new VWAPAnalyzer();
    this.obv          = new OBVAnalyzer();
    this.volDelta     = new VolumeDeltaAnalyzer();
    this.imbalance    = new ImbalanceZoneDetector(sym);
    this.tickVol      = new TickVolumeAnalyzer();
    this.correlations = new CorrelationAnalyzer();
    this.news         = new NewsCalendar(config);
    this.fearGreed    = new FearGreedProxy();
    this.cot          = new COTReport();
    this.openInterest = new OpenInterestAnalyzer();
    this.mtf          = new MTFAnalysis();
    this.bias         = new BiasCalculator();
    this.scoreEngine  = new ScoreEngine(config);

    // Cache des candles par symbole
    this.candleCache = {};
  }

  // Rafraîchit les données macro asynchrones (news, COT, OI, corrélations)
  async refreshMacro() {
    await Promise.allSettled([
      this.news.refresh(),
      this.cot.refresh(),
      this.openInterest.refresh(),
    ]);
  }

  // Met à jour le cache des candles pour un symbole
  updateCandles(symbol, timeframe, candles) {
    if (!this.candleCache[symbol]) this.candleCache[symbol] = {};
    this.candleCache[symbol][timeframe] = candles;
    // Construire le heatmap sur l'historique M1
    if (timeframe === 'M1' && candles.length > 500) {
      this.heatmap.buildFromHistory(candles);
    }
  }

  // Analyse complète pour un symbole — retourne le signal
  async analyze(symbol) {
    const cache = this.candleCache[symbol] || {};
    const m1  = cache['M1']  || [];
    const m5  = cache['M5']  || [];
    const m15 = cache['M15'] || [];
    const h1  = cache['H1']  || [];
    const h4  = cache['H4']  || [];

    if (m1.length < 20) {
      return { go: false, reason: 'Pas assez de bougies M1', symbol };
    }

    const symbolSpec = this.cfg.getSymbol(symbol);
    if (!symbolSpec) {
      return { go: false, reason: `Symbole ${symbol} non configuré`, symbol };
    }

    // Mise à jour du symbole dans les analyseurs dépendants
    this.hlz       = new HLZDetector(symbolSpec);
    this.fibonacci  = new FibonacciAnalyzer(symbolSpec);
    this.gaps       = new GapDetector(symbolSpec);
    this.imbalance  = new ImbalanceZoneDetector(symbolSpec);

    const currentPrice = m1[m1.length - 1]?.close;

    try {
      // === COUCHE 1 : Volatilité ===
      const atrResult     = this.atr.analyze(m1);
      const bollingerResult = this.bollinger.analyze(m1);
      const histVolResult = this.histVol.analyze(m1);
      const heatmapResult = this.heatmap.analyze();
      const gapResult     = this.gaps.analyze(m1);

      // Blocage immédiat si volatilité trop extrême ou heure inactive
      if (!atrResult.suitable) {
        logger.signal(`[${symbol}] NO-GO: ${atrResult.warning}`);
        return { go: false, reason: atrResult.warning, symbol, score: 0 };
      }
      if (!heatmapResult.suitable) {
        logger.signal(`[${symbol}] NO-GO: ${heatmapResult.warning}`);
        return { go: false, reason: heatmapResult.warning, symbol, score: 0 };
      }

      // === COUCHE 2 : Structure (SMC + HLZ + Volume) ===
      const smcResult      = this.smc.analyze(m1, m15);
      const hlzResult      = this.hlz.analyze(m1, h1, currentPrice);
      const fibResult      = this.fibonacci.analyze(m1, currentPrice);
      const candleResult   = this.candles.analyze(m1);
      const profileResult  = this.volProfile.analyze(m1);
      const vwapResult     = this.vwap.analyze(m1);
      const obvResult      = this.obv.analyze(m1);
      const deltaResult    = this.volDelta.analyze(m1);
      const imbalanceResult= this.imbalance.analyze(m1);
      const tickVolResult  = this.tickVol.analyze(m1);

      // === COUCHE 3 : Indicateurs techniques ===
      const trendResult    = this.trend.analyze(m15.length > 50 ? m15 : m1);
      const momentumResult = this.momentum.analyze(m1);
      const adxResult      = this.adx.analyze(m1);
      const ichimokuResult = this.ichimoku.analyze(m1);

      // === COUCHE 4 : Multi-timeframe ===
      const mtfResult = this.mtf.analyze({
        candles_m1: m1, candles_m5: m5,
        candles_m15: m15, candles_h1: h1, candles_h4: h4,
      });
      const biasResult = this.bias.calc({
        h4Bias: mtfResult.h4Bias, h1Bias: mtfResult.h1Bias,
        m15Bias: mtfResult.m15Bias, m5Bias: mtfResult.m5Bias,
      });

      // === COUCHE 5 : Macro ===
      const newsResult    = this.news.analyze();
      const corrResult    = await this.correlations.analyze();
      const cotResult     = this.cot.analyze();
      const oiResult      = this.openInterest.analyze();
      const rsiVal        = momentumResult.rsi?.value || 50;
      const spreadApprox  = symbolSpec.max_spread_pips || 2;
      const fearGreedResult = this.fearGreed.analyze({
        rsi: rsiVal, momentum: momentumResult.momentum?.value || 0,
        spread: spreadApprox, volumeRatio: tickVolResult.ratio || 1,
        atrRatio: atrResult.ratio || 1,
      });

      // Blocage news
      if (newsResult.blocked) {
        logger.signal(`[${symbol}] NO-GO: ${newsResult.blockReason}`);
        return { go: false, reason: newsResult.blockReason, symbol, score: 0 };
      }

      // === SCORE GLOBAL ===
      const scoreResult = this.scoreEngine.compute({
        smc:        smcResult,
        hlz:        hlzResult,
        candles:    candleResult,
        volume:     { vwap: vwapResult, profile: profileResult, obv: obvResult, delta: deltaResult, imbalance: imbalanceResult, tick: tickVolResult },
        indicators: { trend: trendResult, momentum: momentumResult, adx: adxResult, ichimoku: ichimokuResult },
        volatility: { atr: atrResult, bollinger: bollingerResult, histVol: histVolResult, heatmap: heatmapResult },
        macro:      { correlations: corrResult, news: newsResult, fearGreed: fearGreedResult, cot: cotResult, oi: oiResult },
        mtf:        mtfResult,
      });

      // Calcul du grid step basé sur ATR
      const gridStep = atrResult.gridStep || symbolSpec.pip * 10;
      const entryPrice = currentPrice;

      // Log du signal
      logger.signal(`[${symbol}] Score: ${scoreResult.globalScore}% | Dir: ${scoreResult.direction} | GO: ${scoreResult.go}`, {
        breakdown: scoreResult.breakdown,
        warnings: scoreResult.warnings,
      });

      return {
        symbol, go: scoreResult.go,
        direction:    scoreResult.direction,
        score:        scoreResult.globalScore,
        breakdown:    scoreResult.breakdown,
        warnings:     scoreResult.warnings,
        entryPrice,   gridStep,
        atr:          atrResult.atr,
        reason:       scoreResult.go ? `Score ${scoreResult.globalScore}% ≥ ${scoreResult.minScore}%` : `Score insuffisant: ${scoreResult.globalScore}% < ${scoreResult.minScore}%`,
        details: {
          smc: smcResult, hlz: hlzResult, fib: fibResult,
          candle: candleResult, trend: trendResult,
          momentum: momentumResult, adx: adxResult,
          ichimoku: ichimokuResult, atr: atrResult,
          bollinger: bollingerResult, vwap: vwapResult,
          profile: profileResult, mtf: mtfResult,
          bias: biasResult, news: newsResult,
          correlations: corrResult, fearGreed: fearGreedResult,
        },
        timestamp: new Date().toISOString(),
      };
    } catch (err) {
      logger.error(`[${symbol}] Erreur analyse: ${err.message}`, { stack: err.stack });
      return { go: false, reason: `Erreur interne: ${err.message}`, symbol, score: 0 };
    }
  }
}
