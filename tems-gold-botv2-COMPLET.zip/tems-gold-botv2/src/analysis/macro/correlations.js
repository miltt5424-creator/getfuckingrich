import axios from 'axios';

export class CorrelationAnalyzer {
  constructor() {
    this.cache = {};
    this.cacheTTL = 5 * 60 * 1000; // 5 min
  }

  async analyze() {
    try {
      const [dxy, us10y, spx] = await Promise.allSettled([
        this._fetchDXY(), this._fetchUS10Y(), this._fetchSPX()
      ]);

      const result = {
        dxy:   dxy.status   === 'fulfilled' ? dxy.value   : null,
        us10y: us10y.status === 'fulfilled' ? us10y.value : null,
        spx:   spx.status   === 'fulfilled' ? spx.value   : null,
        score: 50, direction: null,
      };

      result.score     = this._calcScore(result);
      result.direction = this._calcDirection(result);
      return result;
    } catch { return { score: 50, direction: null }; }
  }

  async _fetchDXY() {
    // DXY : corrélation inverse avec Gold
    // On utilise EURUSD comme proxy (inverse du DXY)
    const cached = this._getCache('dxy');
    if (cached) return cached;
    try {
      // Alpha Vantage ou fallback statique
      const r = await axios.get('https://query1.finance.yahoo.com/v8/finance/chart/DX-Y.NYB?interval=1d&range=5d', { timeout: 5000 });
      const closes = r.data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close || [];
      const last  = closes[closes.length - 1];
      const prev  = closes[closes.length - 2];
      const change = prev ? ((last - prev) / prev) * 100 : 0;
      const data  = { value: last, change, rising: change > 0 };
      this._setCache('dxy', data);
      return data;
    } catch { return { value: null, change: 0, rising: null }; }
  }

  async _fetchUS10Y() {
    const cached = this._getCache('us10y');
    if (cached) return cached;
    try {
      const r = await axios.get('https://query1.finance.yahoo.com/v8/finance/chart/%5ETNX?interval=1d&range=5d', { timeout: 5000 });
      const closes = r.data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close || [];
      const last   = closes[closes.length - 1];
      const prev   = closes[closes.length - 2];
      const change = prev ? ((last - prev) / prev) * 100 : 0;
      const data   = { value: last, change, rising: change > 0 };
      this._setCache('us10y', data);
      return data;
    } catch { return { value: null, change: 0, rising: null }; }
  }

  async _fetchSPX() {
    const cached = this._getCache('spx');
    if (cached) return cached;
    try {
      const r = await axios.get('https://query1.finance.yahoo.com/v8/finance/chart/%5EGSPC?interval=1d&range=5d', { timeout: 5000 });
      const closes = r.data?.chart?.result?.[0]?.indicators?.quote?.[0]?.close || [];
      const last   = closes[closes.length - 1];
      const prev   = closes[closes.length - 2];
      const change = prev ? ((last - prev) / prev) * 100 : 0;
      const data   = { value: last, change, rising: change > 0 };
      this._setCache('spx', data);
      return data;
    } catch { return { value: null, change: 0, rising: null }; }
  }

  _calcScore({ dxy, us10y, spx }) {
    let score = 50;
    if (dxy?.rising   === false) score += 15; // DXY baisse = Gold monte
    if (dxy?.rising   === true)  score -= 10;
    if (us10y?.rising === false) score += 10; // Taux baisse = Gold monte
    if (spx?.rising   === false) score += 10; // Risk-off = Gold monte
    return Math.max(0, Math.min(100, score));
  }

  _calcDirection({ dxy, us10y, spx }) {
    const v = { BUY: 0, SELL: 0 };
    if (dxy?.rising   === false) v.BUY  += 2;
    if (dxy?.rising   === true)  v.SELL += 2;
    if (us10y?.rising === false) v.BUY  += 1;
    if (us10y?.rising === true)  v.SELL += 1;
    if (spx?.rising   === false) v.BUY  += 1;
    return v.BUY > v.SELL ? 'BUY' : v.SELL > v.BUY ? 'SELL' : null;
  }

  _getCache(key) {
    const c = this.cache[key];
    return c && Date.now() - c.ts < this.cacheTTL ? c.data : null;
  }
  _setCache(key, data) { this.cache[key] = { data, ts: Date.now() }; }
}
