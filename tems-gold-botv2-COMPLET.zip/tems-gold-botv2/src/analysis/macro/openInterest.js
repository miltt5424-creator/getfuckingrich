import axios from 'axios';

export class OpenInterestAnalyzer {
  constructor() { this.cache = null; this.lastFetch = 0; }

  async refresh() {
    if (Date.now() - this.lastFetch < 60 * 60 * 1000 && this.cache) return;
    try {
      // Approximation via Yahoo Finance Gold futures
      const r = await axios.get('https://query1.finance.yahoo.com/v8/finance/chart/GC%3DF?interval=1d&range=10d', { timeout: 8000 });
      const result = r.data?.chart?.result?.[0];
      if (!result) return;
      const oiArr = result.indicators?.quote?.[0]?.volume || [];
      const closeArr = result.indicators?.quote?.[0]?.close || [];
      this.cache = {
        lastOI:    oiArr[oiArr.length - 1],
        prevOI:    oiArr[oiArr.length - 2],
        lastClose: closeArr[closeArr.length - 1],
        prevClose: closeArr[closeArr.length - 2],
      };
      this.lastFetch = Date.now();
    } catch { /* keep cache */ }
  }

  analyze() {
    if (!this.cache) return { score: 50, direction: null, available: false };
    const { lastOI, prevOI, lastClose, prevClose } = this.cache;
    if (!lastOI || !prevOI) return { score: 50, direction: null, available: false };

    const oiChange    = ((lastOI - prevOI) / prevOI) * 100;
    const priceChange = ((lastClose - prevClose) / prevClose) * 100;

    // OI monte + prix monte = tendance saine (continuation haussière)
    // OI monte + prix baisse = tendance baissière forte
    // OI baisse + prix monte = short squeeze (retournement possible)
    let signal = 'neutral', score = 50, direction = null;

    if (oiChange > 2  && priceChange > 0) { signal = 'bullish_continuation'; score = 75; direction = 'BUY';  }
    if (oiChange > 2  && priceChange < 0) { signal = 'bearish_continuation'; score = 75; direction = 'SELL'; }
    if (oiChange < -2 && priceChange > 0) { signal = 'short_squeeze';        score = 70; direction = 'BUY';  }
    if (oiChange < -2 && priceChange < 0) { signal = 'long_liquidation';     score = 70; direction = 'SELL'; }

    return { lastOI, oiChange, priceChange, signal, score, direction, available: true };
  }
}
