import axios from 'axios';

export class COTReport {
  constructor() {
    this.data = null;
    this.lastFetch = 0;
    this.fetchInterval = 7 * 24 * 60 * 60 * 1000; // hebdomadaire
  }

  async refresh() {
    if (Date.now() - this.lastFetch < this.fetchInterval && this.data) return;
    try {
      // CFTC COT data via quandl ou alternative gratuite
      // Données de positionnement Gold futures (code: 088691)
      const r = await axios.get('https://publicreporting.cftc.gov/api/explore/dataset/fut_disagg_txtonly_2024_through_2025/records?where=cftc_market_code%3D088691&limit=1&order_by=report_date_as_yyyy_mm_dd%20DESC', { timeout: 10000 });
      const record = r.data?.records?.[0]?.record?.fields;
      if (record) {
        this.data = {
          date:            record.report_date_as_yyyy_mm_dd,
          commercialLong:  parseInt(record.comm_positions_long_all || 0),
          commercialShort: parseInt(record.comm_positions_short_all || 0),
          largeLong:       parseInt(record.noncomm_positions_long_all || 0),
          largeShort:      parseInt(record.noncomm_positions_short_all || 0),
        };
      }
      this.lastFetch = Date.now();
    } catch { /* garder cache */ }
  }

  analyze() {
    if (!this.data) return { score: 50, direction: null, available: false };

    const { commercialLong, commercialShort, largeLong, largeShort } = this.data;
    const commercialNet = commercialLong - commercialShort;
    const largeNet      = largeLong - largeShort;

    // Commercials = hedgers. Ils sont souvent contra-trend.
    // Large Specs = trend followers.
    // Extremes = signal de retournement
    const commercialExtremeLong  = commercialNet > 0 && commercialLong > commercialShort * 1.5;
    const commercialExtremeShort = commercialNet < 0 && commercialShort > commercialLong  * 1.5;

    let direction = null, score = 50;
    if (commercialExtremeShort) { direction = 'BUY';  score = 75; } // Commercials très shorts = or en haut = BUY possible retournement
    if (commercialExtremeLong)  { direction = 'SELL'; score = 75; }
    if (largeNet > 0 && !commercialExtremeShort) { direction = 'BUY';  score = 60; }
    if (largeNet < 0 && !commercialExtremeLong)  { direction = 'SELL'; score = 60; }

    return { ...this.data, commercialNet, largeNet, commercialExtremeLong, commercialExtremeShort, direction, score, available: true };
  }
}
