// Fear & Greed proxy calculé en interne
// Combine : RSI global, momentum, spread, volume spike

export class FearGreedProxy {
  analyze({ rsi, momentum, spread, volumeRatio, atrRatio }) {
    let score = 50; // 0=extrême peur, 100=extrême avidité

    // RSI
    if (rsi < 30)        score -= 20;
    else if (rsi < 40)   score -= 10;
    else if (rsi > 70)   score += 20;
    else if (rsi > 60)   score += 10;

    // Momentum prix
    if (momentum < -0.5)  score -= 15;
    else if (momentum < 0) score -= 5;
    else if (momentum > 0.5) score += 10;

    // Spread élevé = peur / manipulation
    if (spread > 3)  score -= 15;
    else if (spread > 2) score -= 5;

    // Volume spike = peur ou euphorie
    if (volumeRatio > 3) score -= 10; // panic volume
    else if (volumeRatio > 2) score += 5;

    // Volatilité élevée = peur
    if (atrRatio > 2) score -= 15;

    score = Math.max(0, Math.min(100, score));

    const zone = score < 20 ? 'extreme_fear' : score < 40 ? 'fear' : score < 60 ? 'neutral' : score < 80 ? 'greed' : 'extreme_greed';

    // Pour Gold : peur = haussier, avidité = baissier (safe haven)
    const direction = score < 40 ? 'BUY' : score > 70 ? 'SELL' : null;
    const signalScore = score < 20 || score > 80 ? 80 : score < 35 || score > 65 ? 60 : 40;

    return { fearGreedScore: score, zone, direction, signalScore };
  }
}
