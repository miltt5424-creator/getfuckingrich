import axios from 'axios';
import { isNewsBlackout, minutesUntilNextNews } from '../../utils/time.js';

export class NewsCalendar {
  constructor(config) {
    this.cfg    = config;
    this.events = [];
    this.lastFetch = 0;
    this.fetchInterval = 60 * 60 * 1000; // 1h
  }

  async refresh() {
    if (Date.now() - this.lastFetch < this.fetchInterval) return;
    try {
      const url = this.cfg.env?.forexFactoryUrl || 'https://nfs.faireconomy.media/ff_calendar_thisweek.json';
      const r   = await axios.get(url, { timeout: 10000 });
      this.events = (r.data || [])
        .filter(e => ['high','medium'].includes(e.impact?.toLowerCase()))
        .map(e => ({ ...e, date: new Date(e.date), impact: e.impact?.toLowerCase() }));
      this.lastFetch = Date.now();
    } catch { /* garder l'ancien cache */ }
  }

  analyze() {
    const blackout = isNewsBlackout(this.events);
    const minsUntil = minutesUntilNextNews(this.events);
    const upcoming  = this.events.filter(e => {
      const diff = new Date(e.date) - new Date();
      return diff > 0 && diff < 60 * 60 * 1000;
    });

    // Si news dans moins de 30 min : score bas + bloqué
    const score = blackout.blocked ? 0 : minsUntil < 30 ? 20 : minsUntil < 60 ? 50 : 90;

    return {
      blocked:    blackout.blocked,
      blockReason: blackout.event ? `${blackout.event.title} (${blackout.event.impact})` : null,
      upcoming,
      minsUntilNext: minsUntil,
      score,
      todayEvents: this.events.filter(e => {
        const d = new Date(e.date);
        const n = new Date();
        return d.toDateString() === n.toDateString();
      }),
    };
  }
}
