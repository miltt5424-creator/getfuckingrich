import { weightedAverage } from '../utils/math.js';

export class ScoreEngine {
  constructor(config) { this.cfg = config; }

  compute({ smc, hlz, candles, volume, indicators, volatility, macro, mtf }) {
    const weights = this.cfg.score?.weights || { volatility: 20, smc_hlz: 45, indicators: 15, mtf: 12, macro: 8 };

    // --- Couche 1 : Volatilité (conditions du marché) ---
    const volScore = this._avgScores([
      volatility?.atr?.score, volatility?.bollinger?.score,
      volatility?.histVol?.score, volatility?.heatmap?.score,
    ]);

    // --- Couche 2 : SMC + HLZ + Volume (structure et liquidité) ---
    const structScore = this._avgScores([
      smc?.score, hlz?.score,
      volume?.vwap?.score, volume?.profile?.score,
      volume?.obv?.score, volume?.delta?.score,
      candles?.score,
    ]);

    // --- Couche 3 : Indicateurs techniques ---
    const indScore = this._avgScores([
      indicators?.trend?.score, indicators?.momentum?.score,
      indicators?.adx?.score, indicators?.ichimoku?.score,
    ]);

    // --- Couche 4 : Multi-timeframe ---
    const mtfScore = mtf?.score || 50;

    // --- Couche 5 : Macro ---
    const macroScore = this._avgScores([
      macro?.correlations?.score, macro?.news?.score,
      macro?.fearGreed?.signalScore, macro?.cot?.score,
    ]);

    // Score global pondéré
    const globalScore = weightedAverage([
      { score: volScore,    weight: weights.volatility  },
      { score: structScore, weight: weights.smc_hlz     },
      { score: indScore,    weight: weights.indicators  },
      { score: mtfScore,    weight: weights.mtf         },
      { score: macroScore,  weight: weights.macro       },
    ]);

    const minScore = this.cfg.score?.min_score_to_trade || 70;
    const go       = globalScore >= minScore && !macro?.news?.blocked;

    // Direction majoritaire
    const direction = this._resolveDirection({ smc, hlz, volume, indicators, volatility, mtf, macro });

    const warnings = [];
    if (macro?.news?.blocked)       warnings.push(`News bloquées : ${macro.news.blockReason}`);
    if (volatility?.atr?.warning)   warnings.push(volatility.atr.warning);
    if (indicators?.adx?.warning)   warnings.push(indicators.adx.warning);
    if (volatility?.heatmap?.warning) warnings.push(volatility.heatmap.warning);

    return {
      globalScore, go, direction, minScore, warnings,
      breakdown: { volatility: volScore, structure: structScore, indicators: indScore, mtf: mtfScore, macro: macroScore },
    };
  }

  _avgScores(arr) {
    const valid = arr.filter(v => v !== null && v !== undefined && !isNaN(v));
    if (!valid.length) return 50;
    return Math.round(valid.reduce((a,b) => a+b, 0) / valid.length);
  }

  _resolveDirection({ smc, hlz, volume, indicators, volatility, mtf, macro }) {
    const votes = { BUY: 0, SELL: 0 };
    const add = (dir, w = 1) => { if (dir === 'BUY') votes.BUY += w; else if (dir === 'SELL') votes.SELL += w; };

    add(smc?.direction, 4);
    add(hlz?.direction, 3);
    add(mtf?.direction, 4);
    add(volume?.vwap?.direction, 2);
    add(volume?.profile?.direction, 2);
    add(indicators?.trend?.direction, 3);
    add(indicators?.momentum?.direction, 2);
    add(volatility?.bollinger?.direction, 2);
    add(macro?.correlations?.direction, 2);
    add(macro?.fearGreed?.direction, 1);

    return votes.BUY > votes.SELL ? 'BUY' : votes.SELL > votes.BUY ? 'SELL' : null;
  }
}
