// obvAnalysis.js
import { OBV } from 'technicalindicators';

export class OBVAnalyzer {
  analyze(candles) {
    if (candles.length < 20) return { score: 0, direction: null };
    const closes  = candles.map(c => c.close);
    const volumes = candles.map(c => c.volume || 1);
    try {
      const obv = OBV.calculate({ close: closes, volume: volumes });
      const recent = obv.slice(-20);
      const priceRecent = closes.slice(-20);

      // Divergence : prix monte + OBV baisse = signal baissier
      const obvTrend   = recent[recent.length-1] - recent[0];
      const priceTrend = priceRecent[priceRecent.length-1] - priceRecent[0];
      const divergenceBear = priceTrend > 0 && obvTrend < 0;
      const divergenceBull = priceTrend < 0 && obvTrend > 0;

      const score = divergenceBear || divergenceBull ? 80 : 40;
      const direction = divergenceBull ? 'BUY' : divergenceBear ? 'SELL' : null;

      return { value: obv[obv.length-1], trend: obvTrend > 0 ? 'up' : 'down', divergenceBull, divergenceBear, score, direction };
    } catch { return { score: 0, direction: null }; }
  }
}
