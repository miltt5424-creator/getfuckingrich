export class VWAPAnalyzer {
  analyze(candles) {
    if (candles.length < 2) return { score: 0, direction: null };
    const today = new Date();
    const todayStart = new Date(Date.UTC(today.getUTCFullYear(), today.getUTCMonth(), today.getUTCDate()));

    const todayCandles = candles.filter(c => new Date(c.time) >= todayStart);
    if (!todayCandles.length) return { score: 0, direction: null };

    // VWAP journalier
    let cumTPV = 0, cumVol = 0;
    todayCandles.forEach(c => {
      const tp  = (c.high + c.low + c.close) / 3;
      const vol = c.volume || 1;
      cumTPV += tp * vol;
      cumVol += vol;
    });
    const vwap = cumVol > 0 ? cumTPV / cumVol : null;

    // VWAP hebdomadaire
    const weekStart = new Date(todayStart);
    weekStart.setUTCDate(weekStart.getUTCDate() - weekStart.getUTCDay());
    const weekCandles = candles.filter(c => new Date(c.time) >= weekStart);
    let wCumTPV = 0, wCumVol = 0;
    weekCandles.forEach(c => {
      const tp = (c.high + c.low + c.close) / 3;
      const vol = c.volume || 1;
      wCumTPV += tp * vol; wCumVol += vol;
    });
    const weeklyVwap = wCumVol > 0 ? wCumTPV / wCumVol : null;

    const price = candles[candles.length - 1].close;
    if (!vwap) return { score: 0, direction: null };

    const aboveVWAP = price > vwap;
    const distPct   = Math.abs((price - vwap) / vwap) * 100;

    // Loin du VWAP = mean reversion probable
    const score = distPct > 0.5 ? 80 : distPct > 0.2 ? 60 : 40;
    // Si prix sous VWAP = discount = BUY probable
    const direction = aboveVWAP ? 'SELL' : 'BUY';

    return { vwap, weeklyVwap, price, aboveVWAP, distPct, score, direction,
      zone: aboveVWAP ? 'premium' : 'discount',
      deviation: price - vwap };
  }
}
