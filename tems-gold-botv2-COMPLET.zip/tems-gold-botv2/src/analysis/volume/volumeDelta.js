export class VolumeDeltaAnalyzer {
  analyze(candles) {
    if (candles.length < 5) return { score: 0, direction: null };
    const recent = candles.slice(-20);

    const deltas = recent.map(c => {
      const vol  = c.volume || 1;
      const body = c.close - c.open;
      const range = c.high - c.low || 1;
      // Estimation : proportion acheteur/vendeur selon la position de la clôture
      const buyRatio  = (c.close - c.low) / range;
      const sellRatio = 1 - buyRatio;
      return { delta: (buyRatio - sellRatio) * vol, vol, bullish: body > 0 };
    });

    const cumulDelta = deltas.reduce((s,d) => s + d.delta, 0);
    const lastDelta  = deltas[deltas.length - 1];

    // Signal fort : bougie haussière avec delta négatif = manipulation
    const hiddenSell = lastDelta.bullish && lastDelta.delta < 0;
    const hiddenBuy  = !lastDelta.bullish && lastDelta.delta > 0;

    const score = hiddenSell || hiddenBuy ? 80 : Math.abs(cumulDelta) > 0 ? 60 : 40;
    const direction = hiddenBuy ? 'BUY' : hiddenSell ? 'SELL' : cumulDelta > 0 ? 'BUY' : 'SELL';

    return { cumulDelta, lastDelta: lastDelta.delta, hiddenSell, hiddenBuy, score, direction };
  }
}
