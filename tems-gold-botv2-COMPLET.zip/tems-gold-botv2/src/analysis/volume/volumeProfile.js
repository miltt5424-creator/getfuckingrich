export class VolumeProfileAnalyzer {
  analyze(candles, bins = 50) {
    if (candles.length < 20) return { poc: null, vah: null, val: null, score: 0 };
    const recent  = candles.slice(-200);
    const high    = Math.max(...recent.map(c => c.high));
    const low     = Math.min(...recent.map(c => c.low));
    const range   = high - low;
    if (!range) return { poc: null, score: 0 };

    const binSize = range / bins;
    const volumeMap = new Array(bins).fill(0);

    recent.forEach(c => {
      const vol = c.volume || 1;
      const binLow  = Math.max(0, Math.floor((c.low  - low) / binSize));
      const binHigh = Math.min(bins - 1, Math.floor((c.high - low) / binSize));
      for (let b = binLow; b <= binHigh; b++) volumeMap[b] += vol / (binHigh - binLow + 1);
    });

    const maxVol = Math.max(...volumeMap);
    const pocIdx = volumeMap.indexOf(maxVol);
    const poc    = low + (pocIdx + 0.5) * binSize;

    // Value Area = 70% du volume total
    const totalVol = volumeMap.reduce((a,b) => a+b, 0);
    let vaVol = maxVol, vaLow = pocIdx, vaHigh = pocIdx;
    while (vaVol < totalVol * 0.7) {
      const up   = vaHigh < bins - 1 ? volumeMap[vaHigh + 1] : 0;
      const down = vaLow  > 0       ? volumeMap[vaLow  - 1] : 0;
      if (up >= down && vaHigh < bins - 1) { vaHigh++; vaVol += volumeMap[vaHigh]; }
      else if (vaLow > 0) { vaLow--; vaVol += volumeMap[vaLow]; }
      else break;
    }

    const vah = low + (vaHigh + 1) * binSize;
    const val = low + vaLow       * binSize;

    const price = recent[recent.length - 1].close;
    const abovePOC = price > poc;
    const inValueArea = price >= val && price <= vah;
    const score = Math.abs(price - poc) < binSize * 2 ? 90 : inValueArea ? 60 : 40;
    const direction = price > vah ? 'SELL' : price < val ? 'BUY' : price > poc ? 'SELL' : 'BUY';

    return { poc, vah, val, high, low, range, binSize, volumeMap, abovePOC, inValueArea, score, direction };
  }
}
