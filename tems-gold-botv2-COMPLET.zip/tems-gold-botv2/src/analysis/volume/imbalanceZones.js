export class ImbalanceZoneDetector {
  constructor(symbolSpec) { this.spec = symbolSpec; }

  analyze(candles) {
    if (candles.length < 5) return { zones: [], score: 0 };
    const recent = candles.slice(-100);
    const zones  = [];

    for (let i = 2; i < recent.length; i++) {
      const c1 = recent[i - 2], c3 = recent[i];
      const minGap = this.spec.pip * 3;

      // Imbalance haussière : bas de c3 > haut de c1
      if (c3.low - c1.high > minGap) {
        zones.push({ type: 'bullish', top: c3.low, bottom: c1.high, mid: (c3.low + c1.high) / 2, filled: false, index: i });
      }
      // Imbalance baissière : haut de c3 < bas de c1
      if (c1.low - c3.high > minGap) {
        zones.push({ type: 'bearish', top: c1.low, bottom: c3.high, mid: (c1.low + c3.high) / 2, filled: false, index: i });
      }
    }

    const price = recent[recent.length - 1].close;
    zones.forEach(z => {
      if (z.type === 'bullish' && price <= z.top)   z.filled = true;
      if (z.type === 'bearish' && price >= z.bottom) z.filled = true;
    });

    const openZones = zones.filter(z => !z.filled);
    const nearest   = openZones.sort((a,b) => Math.abs(a.mid - price) - Math.abs(b.mid - price))[0];

    return {
      zones: openZones.slice(-5), nearest, score: nearest ? 70 : 40,
      direction: nearest ? (price < nearest.bottom ? 'BUY' : 'SELL') : null,
    };
  }
}
