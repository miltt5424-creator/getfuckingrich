export class TickVolumeAnalyzer {
  analyze(candles) {
    if (candles.length < 20) return { score: 0, spike: false };
    const recent  = candles.slice(-50);
    const volumes = recent.map(c => c.volume || 1);
    const avgVol  = volumes.slice(0, -5).reduce((a,b) => a+b, 0) / Math.max(1, volumes.length - 5);
    const lastVol = volumes[volumes.length - 1];
    const ratio   = avgVol > 0 ? lastVol / avgVol : 1;

    const spike         = ratio > 2.0;
    const highActivity  = ratio > 1.5;
    const lowActivity   = ratio < 0.5;

    // Spike de volume = gros acteur entré = confirmation forte
    const score = spike ? 90 : highActivity ? 70 : lowActivity ? 20 : 50;
    const lastCandle = recent[recent.length - 1];
    const direction = spike ? (lastCandle.close > lastCandle.open ? 'BUY' : 'SELL') : null;

    return { lastVol, avgVol, ratio, spike, highActivity, lowActivity, score, direction,
      warning: lowActivity ? 'Volume très faible — liquidité insuffisante' : null };
  }
}
