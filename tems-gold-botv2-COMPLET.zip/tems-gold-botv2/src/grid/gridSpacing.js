// gridSpacing.js — Calcul adaptatif de l'écart entre niveaux de grille

export class GridSpacing {
  constructor(config) { this.cfg = config; }

  // Calcule l'écart optimal entre niveaux selon l'ATR et la volatilité
  calc(atr, volatilityRatio = 1, symbolSpec) {
    const baseMult = this.cfg.indicators?.grid_step_atr_mult
      || this.cfg.grid?.grid_step_atr_mult
      || 1.2;

    // Adapter l'écart à la volatilité actuelle
    // Si vol élevée → écart plus grand pour éviter trop de niveaux rapides
    // Si vol faible → écart légèrement réduit
    const adaptedMult = baseMult * Math.max(0.8, Math.min(2.0, volatilityRatio));
    const step = atr * adaptedMult;

    // Plancher minimum : 5 pips
    const minStep = symbolSpec.pip * 5;
    // Plafond maximum : 50 pips
    const maxStep = symbolSpec.pip * 50;

    return Math.max(minStep, Math.min(maxStep, step));
  }

  // Calcule les prix cibles de tous les niveaux de la grille
  calcAllLevels(entryPrice, direction, gridStep, maxLevels) {
    const levels = [];
    for (let i = 0; i < maxLevels; i++) {
      const price = direction === 'BUY'
        ? entryPrice - gridStep * i
        : entryPrice + gridStep * i;
      levels.push({ level: i + 1, price, distance: gridStep * i });
    }
    return levels;
  }

  // Vérifie si le prix est proche du prochain niveau (tolérance 20%)
  isNearNextLevel(currentPrice, nextLevelPrice, gridStep) {
    return Math.abs(currentPrice - nextLevelPrice) <= gridStep * 0.2;
  }
}
