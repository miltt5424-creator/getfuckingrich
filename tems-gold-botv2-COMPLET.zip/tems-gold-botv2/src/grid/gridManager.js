// gridManager.js — Orchestrateur complet de la logique Martingale/Grid

import { GridState }    from './gridState.js';
import { LotCalculator } from './lotCalculator.js';
import { TPManager }    from './tpManager.js';
import { GridSpacing }  from './gridSpacing.js';
import { bus, EVENTS }  from '../utils/eventBus.js';
import logger           from '../utils/logger.js';

export class GridManager {
  constructor(config, broker, survivalSystem, notifier) {
    this.cfg       = config;
    this.broker    = broker;
    this.survival  = survivalSystem;
    this.notifier  = notifier;

    this.lotCalc   = new LotCalculator(config);
    this.tpMgr     = new TPManager(config);
    this.spacing   = new GridSpacing(config);

    // Map des grilles actives : symbol -> GridState[]
    this.grids = new Map();
  }

  // Ouvre une nouvelle grille sur un symbole
  async openGrid(symbol, signal) {
    try {
      const symbolSpec = this.cfg.getSymbol(symbol);
      if (!symbolSpec) throw new Error(`Symbole ${symbol} non trouvé`);

      // Vérifier la limite de grilles simultanées
      const activeGrids = this._getActiveGrids();
      if (activeGrids.length >= this.cfg.general.max_concurrent_grids) {
        logger.warn(`[GridManager] Limite de grilles atteinte (${activeGrids.length}/${this.cfg.general.max_concurrent_grids})`);
        return null;
      }

      // Vérifier si grille déjà ouverte sur ce symbole dans la même direction
      const existingGrids = this.grids.get(symbol) || [];
      const sameDir = existingGrids.find(g => g.direction === signal.direction && g.status === 'open');
      if (sameDir) {
        logger.debug(`[GridManager] Grille ${signal.direction} déjà ouverte sur ${symbol}`);
        return null;
      }

      // Vérifier le risk guard
      const account    = await this.broker.getAccountInfo();
      const riskCheck  = this.survival.check(account.equity);
      if (!riskCheck.allowed) {
        logger.risk(`[GridManager] Ouverture bloquée par RiskGuard: ${riskCheck.reason}`);
        return null;
      }

      // Calculer le grid step adaptatif
      const gridStep = this.spacing.calc(
        signal.atr, signal.details?.volatility?.histVol?.ratio || 1, symbolSpec
      );

      // Créer l'état de la grille
      const grid = new GridState({
        symbol, direction: signal.direction,
        entryPrice: signal.entryPrice, gridStep, atr: signal.atr,
        signal, config: this.cfg,
      });

      // Calculer et vérifier la marge pour le lot initial
      const lotCheck = this.lotCalc.canOpenNextLevel(0, account.equity, signal.entryPrice, symbolSpec);
      if (!lotCheck.allowed) {
        logger.risk(`[GridManager] ${lotCheck.reason}`);
        return null;
      }

      // Envoyer l'ordre niveau 1
      const lot1 = this.lotCalc.calcForLevel(1);
      let ticket;

      if (this.cfg.isPaper) {
        ticket = `PAPER_${Date.now()}`;
        logger.trade(`[PAPER] OPEN ${signal.direction} ${symbol} lot=${lot1} @ ${signal.entryPrice}`);
      } else {
        const order = await this.broker.sendOrder({
          symbol, type: signal.direction, lot: lot1,
          comment: `TEMS_${grid.id}`,
        });
        ticket = order.ticket;
      }

      grid.addPosition({ ticket, lot: lot1, entryPrice: signal.entryPrice });
      const tp = this.tpMgr.calcGlobalTP(grid);
      grid.tpPrice = tp;

      // Stocker la grille
      if (!this.grids.has(symbol)) this.grids.set(symbol, []);
      this.grids.get(symbol).push(grid);

      logger.trade(`[GridManager] Grille OUVERTE | ${symbol} ${signal.direction} | Lot: ${lot1} | TP: ${tp?.toFixed(symbolSpec.digits)} | Score: ${signal.score}%`);

      bus.emit(EVENTS.GRID_OPENED, grid.toJSON());
      await this.notifier.notifyGridOpened(grid, signal);

      return grid;
    } catch (err) {
      logger.error(`[GridManager] Erreur ouverture grille ${symbol}: ${err.message}`);
      return null;
    }
  }

  // Gère une grille existante (ouvre niveaux supplémentaires, vérifie TP)
  async manageGrid(grid, currentPrice, account) {
    if (grid.status !== 'open') return;

    // Mettre à jour le PnL
    grid.updatePnL(currentPrice);

    // Vérifier la phase de survie
    const survivalResult = this.survival.evaluateGrid(grid, account.equity);
    if (survivalResult.phaseChanged) {
      grid.setSurvivalPhase(survivalResult.newPhase);
      logger.risk(`[GridManager] ${grid.symbol} passe en Phase ${survivalResult.newPhase}`);
      bus.emit(EVENTS.PHASE_CHANGED, { gridId: grid.id, phase: survivalResult.newPhase });
      await this.notifier.notifyPhaseChange(grid, survivalResult.newPhase);

      // Phase 2 : activer le hedge
      if (survivalResult.newPhase === 2 && !grid.hedgeActive) {
        await this._openHedge(grid, currentPrice, account);
      }
      // Phase 3 : equity stop total
      if (survivalResult.newPhase === 3) {
        await this._emergencyClose(grid, 'Phase 3 — Equity stop');
        return;
      }
    }

    // Vérifier si TP atteint
    if (this.tpMgr.isGlobalTPReached(grid, currentPrice)) {
      await this.closeGrid(grid, 'TP_HIT', currentPrice);
      return;
    }

    // Vérifier si on doit ouvrir un nouveau niveau
    if (grid.shouldOpenNextLevel(currentPrice)) {
      await this._openNextLevel(grid, currentPrice, account);
    }
  }

  // Ouvre le niveau suivant de la grille
  async _openNextLevel(grid, currentPrice, account) {
    const symbolSpec = this.cfg.getSymbol(grid.symbol);
    const nextLevel  = grid.level + 1;

    const lotCheck = this.lotCalc.canOpenNextLevel(grid.level, account.equity, currentPrice, symbolSpec);
    if (!lotCheck.allowed) {
      logger.risk(`[GridManager] Niveau ${nextLevel} bloqué: ${lotCheck.reason}`);
      return;
    }

    const lot = this.lotCalc.calcForLevel(nextLevel);
    let ticket;

    if (this.cfg.isPaper) {
      ticket = `PAPER_${Date.now()}`;
      logger.trade(`[PAPER] LEVEL ${nextLevel} ${grid.direction} ${grid.symbol} lot=${lot} @ ${currentPrice}`);
    } else {
      try {
        const order = await this.broker.sendOrder({
          symbol: grid.symbol, type: grid.direction, lot,
          comment: `TEMS_L${nextLevel}_${grid.id}`,
        });
        ticket = order.ticket;
      } catch (err) {
        logger.error(`[GridManager] Erreur niveau ${nextLevel}: ${err.message}`);
        return;
      }
    }

    grid.addPosition({ ticket, lot, entryPrice: currentPrice });
    const tp = this.tpMgr.calcGlobalTP(grid);
    grid.tpPrice = tp;

    logger.trade(`[GridManager] Niveau ${nextLevel} ouvert | ${grid.symbol} ${grid.direction} | Lot: ${lot} | Cumul: ${grid.totalLot} | Breakeven: ${grid.breakeven?.toFixed(symbolSpec.digits)}`);
    bus.emit(EVENTS.GRID_LEVEL_ADDED, { ...grid.toJSON(), newLevel: nextLevel, lot });
    await this.notifier.notifyNewLevel(grid, nextLevel, lot, currentPrice);
  }

  // Ouvre une position de hedge (Phase 2)
  async _openHedge(grid, currentPrice, account) {
    const hedgeDirection = grid.direction === 'BUY' ? 'SELL' : 'BUY';
    const hedgeLot       = this.lotCalc.calcHedgeLot(grid);

    let ticket;
    if (this.cfg.isPaper) {
      ticket = `HEDGE_${Date.now()}`;
      logger.trade(`[PAPER] HEDGE ${hedgeDirection} ${grid.symbol} lot=${hedgeLot} @ ${currentPrice}`);
    } else {
      try {
        const order = await this.broker.sendOrder({
          symbol: grid.symbol, type: hedgeDirection, lot: hedgeLot,
          comment: `TEMS_HEDGE_${grid.id}`,
        });
        ticket = order.ticket;
      } catch (err) {
        logger.error(`[GridManager] Erreur hedge: ${err.message}`);
        return;
      }
    }

    grid.addHedgePosition({ ticket, lot: hedgeLot, entryPrice: currentPrice, direction: hedgeDirection });
    logger.risk(`[GridManager] HEDGE ouvert | ${grid.symbol} ${hedgeDirection} | Lot: ${hedgeLot} | 40% de ${grid.totalLot}`);
    bus.emit(EVENTS.HEDGE_OPENED, grid.toJSON());
    await this.notifier.notifyHedgeOpened(grid, hedgeDirection, hedgeLot);
  }

  // Ferme toute la grille
  async closeGrid(grid, reason, currentPrice) {
    if (grid.status === 'closed') return;
    grid.status = 'closing';

    const allTickets = [
      ...grid.positions.map(p => p.ticket),
      ...grid.hedgePositions.map(p => p.ticket),
    ];

    let closedCount = 0;
    for (const ticket of allTickets) {
      if (this.cfg.isPaper) {
        closedCount++;
        logger.trade(`[PAPER] CLOSE ticket=${ticket} @ ${currentPrice}`);
      } else {
        try {
          await this.broker.closeOrder(ticket);
          closedCount++;
        } catch (err) {
          logger.error(`[GridManager] Erreur fermeture ticket ${ticket}: ${err.message}`);
        }
      }
    }

    grid.close(reason);
    const profit = grid.floatingPnL;

    logger.trade(`[GridManager] Grille FERMÉE | ${grid.symbol} ${grid.direction} | Raison: ${reason} | Profit: ${profit?.toFixed(2)}$ | Durée: ${grid.duration?.toFixed(0)}min | Niveaux: ${grid.level}`);
    bus.emit(reason === 'TP_HIT' ? EVENTS.GRID_TP_HIT : EVENTS.GRID_CLOSED, grid.toJSON());

    if (reason === 'TP_HIT') await this.notifier.notifyTPHit(grid, profit);
    else await this.notifier.notifyGridClosed(grid, reason, profit);

    return profit;
  }

  // Fermeture d'urgence (Phase 3)
  async _emergencyClose(grid, reason) {
    logger.risk(`[GridManager] URGENCE — Fermeture forcée grille ${grid.id}: ${reason}`);
    await this.closeGrid(grid, reason);
  }

  // Gère toutes les grilles actives pour tous les symboles
  async manageAll(prices, account) {
    for (const [symbol, grids] of this.grids.entries()) {
      const price = prices[symbol];
      if (!price) continue;
      for (const grid of grids.filter(g => g.status === 'open')) {
        await this.manageGrid(grid, price, account);
      }
    }
  }

  _getActiveGrids() {
    const all = [];
    for (const grids of this.grids.values()) all.push(...grids.filter(g => g.status === 'open'));
    return all;
  }

  getStats() {
    const active = this._getActiveGrids();
    const all    = [...this.grids.values()].flat();
    const closed = all.filter(g => g.status === 'closed');
    const tpHits = closed.filter(g => g.closeReason === 'TP_HIT');
    return {
      activeGrids: active.length,
      totalGrids:  all.length,
      closedGrids: closed.length,
      winRate:     closed.length ? (tpHits.length / closed.length * 100).toFixed(1) : 0,
      totalProfit: closed.reduce((s, g) => s + (g.floatingPnL || 0), 0),
      avgDuration: closed.length ? closed.reduce((s, g) => s + (g.duration || 0), 0) / closed.length : 0,
    };
  }
}
