// GridState — Objet d'état complet d'une grille active

export class GridState {
  constructor({ symbol, direction, entryPrice, gridStep, atr, signal, config }) {
    this.id          = `${symbol}_${direction}_${Date.now()}`;
    this.symbol      = symbol;
    this.direction   = direction;  // 'BUY' | 'SELL'
    this.status      = 'open';     // 'open' | 'closing' | 'closed' | 'hedged'

    // Paramètres de grille
    this.initialLot  = config.grid.lot_initial;
    this.multiplier  = config.grid.lot_multiplier;
    this.maxLevels   = config.grid.max_levels;
    this.gridStep    = gridStep;
    this.atr         = atr;

    // Positions ouvertes
    this.positions   = [];   // [{ ticket, lot, entryPrice, openTime, sl, tp }]
    this.hedgePositions = []; // positions du hedge (phase 2)

    // Niveaux de la grille (prix où ouvrir les prochains niveaux)
    this.nextLevelPrice = this._calcNextLevelPrice(entryPrice, direction, gridStep);

    // Statistiques
    this.openTime     = new Date();
    this.level        = 0;
    this.floatingPnL  = 0;
    this.totalLot     = 0;
    this.breakeven    = entryPrice;
    this.peakProfit   = 0;
    this.maxDrawdown  = 0;

    // Phase de survie
    this.survivalPhase = 1;
    this.hedgeActive   = false;
    this.hedgeLot      = 0;

    // TP
    this.tpPrice       = null;
    this.tpAtrMult     = config.grid.tp_atr_mult_phase1 || 1.5;

    // Signal d'origine
    this.signalScore   = signal?.score || 0;
    this.signalDetails = signal?.breakdown || {};

    this._config = config;
  }

  addPosition(position) {
    this.positions.push({
      ticket:     position.ticket,
      lot:        position.lot,
      entryPrice: position.entryPrice,
      openTime:   new Date(),
      sl:         position.sl || null,
      tp:         position.tp || null,
      status:     'open',
    });
    this.level    = this.positions.length;
    this.totalLot = this.positions.reduce((s, p) => s + p.lot, 0);
    this._updateBreakeven();
    this._updateNextLevel();
  }

  addHedgePosition(position) {
    this.hedgePositions.push({
      ticket:     position.ticket,
      lot:        position.lot,
      entryPrice: position.entryPrice,
      openTime:   new Date(),
      direction:  position.direction,
    });
    this.hedgeActive = true;
    this.hedgeLot    = this.hedgePositions.reduce((s, p) => s + p.lot, 0);
  }

  updatePnL(currentPrice) {
    // Calcul PnL grille principale
    const symbolSpec  = this._config.getSymbol(this.symbol);
    const pipVal      = symbolSpec?.pip_value_per_lot || 1;
    const pip         = symbolSpec?.pip || 0.01;

    let gridPnL = 0;
    for (const pos of this.positions) {
      const priceDiff = this.direction === 'BUY'
        ? currentPrice - pos.entryPrice
        : pos.entryPrice - currentPrice;
      gridPnL += (priceDiff / pip) * pipVal * pos.lot;
    }

    // PnL hedge
    let hedgePnL = 0;
    for (const pos of this.hedgePositions) {
      const priceDiff = pos.direction === 'BUY'
        ? currentPrice - pos.entryPrice
        : pos.entryPrice - currentPrice;
      hedgePnL += (priceDiff / pip) * pipVal * pos.lot;
    }

    this.floatingPnL = gridPnL + hedgePnL;
    this.gridPnL     = gridPnL;
    this.hedgePnL    = hedgePnL;

    if (this.floatingPnL > this.peakProfit) this.peakProfit = this.floatingPnL;
    if (this.floatingPnL < this.maxDrawdown) this.maxDrawdown = this.floatingPnL;

    return this.floatingPnL;
  }

  shouldOpenNextLevel(currentPrice) {
    if (this.level >= this.maxLevels) return false;
    if (this.status !== 'open') return false;
    if (this.survivalPhase >= 2 && this.level >= 11) return false; // Phase 2 = gel à 11 niveaux

    if (this.direction === 'BUY') return currentPrice <= this.nextLevelPrice;
    return currentPrice >= this.nextLevelPrice;
  }

  isTpReached(currentPrice) {
    if (!this.tpPrice) return false;
    const minProfit = this._config.grid.min_profit_to_close || 5;
    const profitOk  = this.floatingPnL >= minProfit;
    if (this.direction === 'BUY') return currentPrice >= this.tpPrice && profitOk;
    return currentPrice <= this.tpPrice && profitOk;
  }

  calcTP(atrMult) {
    if (!this.positions.length) return null;
    const atrMult_ = atrMult || this.tpAtrMult;
    const tpDistance = this.atr * atrMult_;
    this.tpPrice = this.direction === 'BUY'
      ? this.breakeven + tpDistance
      : this.breakeven - tpDistance;
    return this.tpPrice;
  }

  setSurvivalPhase(phase) {
    const old = this.survivalPhase;
    this.survivalPhase = phase;
    if (phase === 2) {
      this.tpAtrMult = this._config.grid.tp_atr_mult_phase2 || 3.0;
      this.calcTP(this.tpAtrMult);
    }
    return { changed: old !== phase, from: old, to: phase };
  }

  closePosition(ticket) {
    const pos = this.positions.find(p => p.ticket === ticket);
    if (pos) pos.status = 'closed';
  }

  close(reason) {
    this.status    = 'closed';
    this.closeTime = new Date();
    this.closeReason = reason;
    this.duration  = (this.closeTime - this.openTime) / 1000 / 60; // minutes
  }

  toJSON() {
    return {
      id: this.id, symbol: this.symbol, direction: this.direction,
      status: this.status, level: this.level, maxLevels: this.maxLevels,
      totalLot: this.totalLot, floatingPnL: this.floatingPnL,
      breakeven: this.breakeven, tpPrice: this.tpPrice,
      survivalPhase: this.survivalPhase, hedgeActive: this.hedgeActive,
      positions: this.positions.length, openTime: this.openTime,
      signalScore: this.signalScore, peakProfit: this.peakProfit,
    };
  }

  _calcNextLevelPrice(entryPrice, direction, gridStep) {
    return direction === 'BUY' ? entryPrice - gridStep : entryPrice + gridStep;
  }

  _updateBreakeven() {
    if (!this.positions.length) return;
    const totalLot   = this.positions.reduce((s, p) => s + p.lot, 0);
    const weightedSum = this.positions.reduce((s, p) => s + p.entryPrice * p.lot, 0);
    this.breakeven   = totalLot > 0 ? weightedSum / totalLot : 0;
    this.calcTP();
  }

  _updateNextLevel() {
    const lastPrice  = this.positions[this.positions.length - 1]?.entryPrice;
    if (!lastPrice) return;
    this.nextLevelPrice = this._calcNextLevelPrice(lastPrice, this.direction, this.gridStep);
  }
}
