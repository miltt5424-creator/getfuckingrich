import { calcLot, calcCumulativeLot, calcRequiredMargin, round } from '../utils/math.js';

export class LotCalculator {
  constructor(config) { this.cfg = config; }

  // Calcule le lot pour un niveau donné
  calcForLevel(level) {
    return calcLot(this.cfg.grid.lot_initial, this.cfg.grid.lot_multiplier, level);
  }

  // Vérifie si on peut ouvrir le prochain niveau
  canOpenNextLevel(level, currentEquity, currentPrice, symbolSpec) {
    const nextLot    = this.calcForLevel(level + 1);
    const margin     = calcRequiredMargin(nextLot, currentPrice, symbolSpec.margin_pct || 1);
    const freeMargin = currentEquity * 0.8; // On utilise max 80% de l'equity

    if (margin > freeMargin) {
      return { allowed: false, reason: `Marge insuffisante: besoin ${margin.toFixed(2)}$, disponible ${freeMargin.toFixed(2)}$`, requiredMargin: margin };
    }

    // Vérifier aussi que le cumul total des marges ne dépasse pas 90% de l'equity
    const cumulLot    = calcCumulativeLot(this.cfg.grid.lot_initial, this.cfg.grid.lot_multiplier, level + 1);
    const totalMargin = cumulLot * currentPrice * (symbolSpec.margin_pct || 1) / 100;
    if (totalMargin > currentEquity * 0.9) {
      return { allowed: false, reason: `Exposition totale trop élevée: ${totalMargin.toFixed(2)}$ > ${(currentEquity*0.9).toFixed(2)}$`, totalMargin };
    }

    return { allowed: true, lot: nextLot, margin, cumulLot };
  }

  // Calcule le lot du hedge (phase 2)
  calcHedgeLot(gridState) {
    const hedgeRatio = this.cfg.survival?.hedge_ratio || 0.4;
    const rawLot     = gridState.totalLot * hedgeRatio;
    return Math.max(this.cfg.grid.lot_initial, round(rawLot, 2));
  }

  // Simule tous les niveaux et leur coût en marge
  simulate(levels, price, symbolSpec) {
    const rows = [];
    let cumLot = 0, cumMargin = 0;
    for (let i = 1; i <= levels; i++) {
      const lot    = calcLot(this.cfg.grid.lot_initial, this.cfg.grid.lot_multiplier, i);
      const margin = calcRequiredMargin(lot, price, symbolSpec.margin_pct || 1);
      cumLot    = round(cumLot + lot, 2);
      cumMargin = round(cumMargin + margin, 2);
      rows.push({ level: i, lot, cumLot, margin, cumMargin });
    }
    return rows;
  }
}
