// tpManager.js — Gestion du Take Profit global flottant

export class TPManager {
  constructor(config) { this.cfg = config; }

  // Calcule le TP global selon la phase
  calcGlobalTP(gridState) {
    const phase    = gridState.survivalPhase;
    const atrMult  = phase === 1
      ? (this.cfg.grid.tp_atr_mult_phase1 || 1.5)
      : (this.cfg.grid.tp_atr_mult_phase2 || 3.0);

    return gridState.calcTP(atrMult);
  }

  // Vérifie si le TP global est atteint
  isGlobalTPReached(gridState, currentPrice) {
    return gridState.isTpReached(currentPrice);
  }

  // Calcule le TP flottant basé sur le breakeven + ATR
  calcFloatingTP(breakeven, direction, atr, phase) {
    const mult = phase === 1
      ? (this.cfg.grid.tp_atr_mult_phase1 || 1.5)
      : (this.cfg.grid.tp_atr_mult_phase2 || 3.0);
    const dist = atr * mult;
    return direction === 'BUY' ? breakeven + dist : breakeven - dist;
  }

  // Breakeven : prix où toute la grille est à 0
  calcBreakevenPrice(positions, direction) {
    if (!positions.length) return 0;
    const totalLot    = positions.reduce((s, p) => s + p.lot, 0);
    const weightedSum = positions.reduce((s, p) => s + p.entryPrice * p.lot, 0);
    return totalLot > 0 ? weightedSum / totalLot : 0;
  }

  // Trailing TP : déplace le TP si le profit dépasse un certain seuil
  shouldUpdateTP(gridState, currentPrice) {
    if (!this.cfg.grid.use_floating_tp) return false;
    const currentProfit = gridState.floatingPnL;
    const minProfit     = this.cfg.grid.min_profit_to_close || 5;
    return currentProfit > minProfit * 2 && gridState.peakProfit > currentProfit * 1.2;
  }
}
