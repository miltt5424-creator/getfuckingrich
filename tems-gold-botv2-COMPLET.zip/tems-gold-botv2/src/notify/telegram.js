// telegram.js — Toutes les alertes Telegram du bot
import TelegramBot from 'node-telegram-bot-api';
import logger from '../utils/logger.js';

export class TelegramNotifier {
  constructor(config) {
    this.cfg     = config;
    this.enabled = !!(config.env?.telegramToken && config.env?.telegramChatId);
    this.chatId  = config.env?.telegramChatId;
    this.bot     = null;
    this._queue  = [];
    this._sending = false;
  }

  init() {
    if (!this.enabled) {
      logger.warn('[Telegram] Token ou ChatId manquant — notifications désactivées');
      return;
    }
    try {
      this.bot = new TelegramBot(this.cfg.env.telegramToken, { polling: false });
      logger.info('[Telegram] Bot initialisé');
    } catch (err) {
      logger.error(`[Telegram] Erreur init: ${err.message}`);
      this.enabled = false;
    }
  }

  async _send(message) {
    if (!this.enabled || !this.bot) return;
    this._queue.push(message);
    if (!this._sending) this._processQueue();
  }

  async _processQueue() {
    this._sending = true;
    while (this._queue.length > 0) {
      const msg = this._queue.shift();
      try {
        await this.bot.sendMessage(this.chatId, msg, { parse_mode: 'HTML' });
        await new Promise(r => setTimeout(r, 300)); // Anti-spam Telegram
      } catch (err) {
        logger.error(`[Telegram] Erreur envoi: ${err.message}`);
      }
    }
    this._sending = false;
  }

  // ─── Grille ouverte ───────────────────────────────────────
  async notifyGridOpened(grid, signal) {
    if (!this.cfg.telegram?.notify_grid_open) return;
    const dir = grid.direction === 'BUY' ? '🟢 BUY' : '🔴 SELL';
    const msg = [
      `<b>🤖 TEMS-GOLD-BOTV2 — Nouvelle grille</b>`,
      ``,
      `<b>Symbole :</b> ${grid.symbol}`,
      `<b>Direction :</b> ${dir}`,
      `<b>Lot initial :</b> ${grid.positions[0]?.lot || grid.initialLot}`,
      `<b>Prix d'entrée :</b> ${signal.entryPrice}`,
      `<b>TP cible :</b> ${grid.tpPrice?.toFixed(2) || '—'}`,
      `<b>Grid step :</b> ${grid.gridStep?.toFixed(2)}`,
      ``,
      `<b>Score analyse :</b> ${signal.score}%`,
      `  • Structure SMC/HLZ : ${signal.breakdown?.structure || '—'}%`,
      `  • Indicateurs : ${signal.breakdown?.indicators || '—'}%`,
      `  • Multi-TF : ${signal.breakdown?.mtf || '—'}%`,
      `  • Macro : ${signal.breakdown?.macro || '—'}%`,
      `  • Volatilité : ${signal.breakdown?.volatility || '—'}%`,
      ``,
      `<b>Mode :</b> ${this.cfg.isPaper ? '🧪 PAPER' : '💰 LIVE'}`,
      `<i>${new Date().toUTCString()}</i>`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Nouveau niveau ───────────────────────────────────────
  async notifyNewLevel(grid, level, lot, price) {
    if (!this.cfg.telegram?.notify_new_level) return;
    const phase = grid.survivalPhase;
    const phaseEmoji = phase === 1 ? '✅' : phase === 2 ? '⚠️' : '🚨';
    const msg = [
      `<b>${phaseEmoji} Niveau ${level} ouvert — ${grid.symbol}</b>`,
      ``,
      `<b>Direction :</b> ${grid.direction}`,
      `<b>Lot niveau ${level} :</b> ${lot}`,
      `<b>Lot cumulé :</b> ${grid.totalLot}`,
      `<b>Prix :</b> ${price}`,
      `<b>Breakeven :</b> ${grid.breakeven?.toFixed(2)}`,
      `<b>TP :</b> ${grid.tpPrice?.toFixed(2) || '—'}`,
      `<b>PnL flottant :</b> ${grid.floatingPnL?.toFixed(2)}$`,
      `<b>Phase survie :</b> Phase ${phase}`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── TP atteint ───────────────────────────────────────────
  async notifyTPHit(grid, profit) {
    if (!this.cfg.telegram?.notify_tp_hit) return;
    const emoji = profit >= 0 ? '💰' : '📉';
    const msg = [
      `<b>${emoji} TP HIT — ${grid.symbol}</b>`,
      ``,
      `<b>Direction :</b> ${grid.direction}`,
      `<b>Profit net :</b> <b>${profit >= 0 ? '+' : ''}${profit?.toFixed(2)}$</b>`,
      `<b>Niveaux utilisés :</b> ${grid.level}/${grid.maxLevels}`,
      `<b>Lot max atteint :</b> ${grid.totalLot}`,
      `<b>Durée :</b> ${grid.duration?.toFixed(0)} min`,
      `<b>Phase survie :</b> Phase ${grid.survivalPhase}`,
      `<b>Hedge utilisé :</b> ${grid.hedgeActive ? 'Oui' : 'Non'}`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Grille fermée (non TP) ───────────────────────────────
  async notifyGridClosed(grid, reason, profit) {
    const msg = [
      `<b>📋 Grille fermée — ${grid.symbol}</b>`,
      `<b>Raison :</b> ${reason}`,
      `<b>Profit/Perte :</b> ${profit >= 0 ? '+' : ''}${profit?.toFixed(2)}$`,
      `<b>Niveaux :</b> ${grid.level}`,
      `<b>Durée :</b> ${grid.duration?.toFixed(0)} min`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Changement de phase ──────────────────────────────────
  async notifyPhaseChange(grid, newPhase) {
    if (!this.cfg.telegram?.notify_phase2 && newPhase === 2) return;
    const emoji = newPhase === 2 ? '⚠️' : '🚨';
    const desc  = newPhase === 2
      ? 'Hedge automatique activé (40% du lot cumulé)'
      : 'EQUITY STOP — Fermeture totale en cours';
    const msg = [
      `<b>${emoji} Phase ${newPhase} activée — ${grid.symbol}</b>`,
      ``,
      `<b>Description :</b> ${desc}`,
      `<b>Niveau grille :</b> ${grid.level}/${grid.maxLevels}`,
      `<b>Lot cumulé :</b> ${grid.totalLot}`,
      `<b>PnL flottant :</b> ${grid.floatingPnL?.toFixed(2)}$`,
      `<b>Breakeven :</b> ${grid.breakeven?.toFixed(2)}`,
      `⚡ <i>Action automatique en cours...</i>`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Hedge ouvert ────────────────────────────────────────
  async notifyHedgeOpened(grid, hedgeDir, hedgeLot) {
    const msg = [
      `<b>🔀 Hedge ouvert — ${grid.symbol}</b>`,
      `<b>Direction hedge :</b> ${hedgeDir}`,
      `<b>Lot hedge :</b> ${hedgeLot} (40% de ${grid.totalLot})`,
      `<b>Grid PnL :</b> ${grid.floatingPnL?.toFixed(2)}$`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Equity Stop ─────────────────────────────────────────
  async notifyEquityStop(equity, reason, time) {
    if (!this.cfg.telegram?.notify_equity_stop) return;
    const msg = [
      `<b>🚨🚨 EQUITY STOP DÉCLENCHÉ 🚨🚨</b>`,
      ``,
      `<b>Equity actuelle :</b> ${equity?.toFixed(2)}$`,
      `<b>Raison :</b> ${reason}`,
      `<b>Heure :</b> ${time?.toUTCString()}`,
      ``,
      `⛔ <b>Toutes les positions ont été fermées</b>`,
      `⛔ <b>Le bot est arrêté</b>`,
      ``,
      `Pour redémarrer : <code>npm start</code>`,
      `⚠️ <i>Analyse les trades avant de relancer !</i>`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Rapport quotidien ────────────────────────────────────
  async notifyDailyReport(stats) {
    if (!this.cfg.telegram?.notify_daily_report) return;
    const profit = stats.totalProfit >= 0 ? `+${stats.totalProfit.toFixed(2)}` : stats.totalProfit.toFixed(2);
    const msg = [
      `<b>📊 Rapport quotidien — TEMS-GOLD-BOTV2</b>`,
      `<i>${new Date().toDateString()}</i>`,
      ``,
      `<b>Grilles ouvertes :</b> ${stats.gridsOpened}`,
      `<b>Grilles fermées :</b> ${stats.gridsClosed}`,
      `<b>TP réussis :</b> ${stats.tpHits}`,
      `<b>Win rate :</b> ${stats.winRate}%`,
      `<b>Profit net :</b> ${profit}$`,
      ``,
      `<b>Equity début :</b> ${stats.startEquity?.toFixed(2)}$`,
      `<b>Equity fin :</b> ${stats.endEquity?.toFixed(2)}$`,
      `<b>DD max :</b> ${stats.maxDD?.toFixed(1)}%`,
      ``,
      `<b>Symbole le + profitable :</b> ${stats.bestSymbol || '—'}`,
      `<b>Symbole le - profitable :</b> ${stats.worstSymbol || '—'}`,
      `<b>Durée moy. grille :</b> ${stats.avgDuration?.toFixed(0)} min`,
    ].join('\n');
    await this._send(msg);
  }

  // ─── Déconnexion bridge ───────────────────────────────────
  async notifyDisconnection(elapsedMinutes, attempts) {
    const msg = `<b>⚠️ Bridge MT5 déconnecté</b>\nDurée: ${elapsedMinutes.toFixed(1)} min\nTentatives: ${attempts}`;
    await this._send(msg);
  }

  async notifyFatalError(msg) {
    await this._send(`<b>💀 ERREUR FATALE</b>\n${msg}\nBot arrêté.`);
  }

  async notifyRecovery(equity, checks) {
    const checksText = checks.map(c => `${c.ok ? '✅' : '❌'} ${c.name}: ${c.detail}`).join('\n');
    const msg = [
      `<b>🔄 Reprise automatique du bot</b>`,
      `<b>Equity :</b> ${equity?.toFixed(2)}$`,
      ``, checksText,
    ].join('\n');
    await this._send(msg);
  }

  async notifyStartup(mode, symbols) {
    const msg = [
      `<b>🚀 TEMS-GOLD-BOTV2 démarré</b>`,
      `<b>Mode :</b> ${mode === 'live' ? '💰 LIVE' : '🧪 PAPER'}`,
      `<b>Symboles :</b> ${symbols.join(', ')}`,
      `<b>Heure :</b> ${new Date().toUTCString()}`,
    ].join('\n');
    await this._send(msg);
  }
}
