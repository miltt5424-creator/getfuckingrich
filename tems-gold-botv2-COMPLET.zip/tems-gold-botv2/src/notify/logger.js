// src/notify/logger.js
// Re-export du logger principal depuis utils/
// Ce fichier existe pour la cohérence de l'arborescence notify/
// Le vrai logger avec la configuration Winston est dans src/utils/logger.js

export { default } from '../utils/logger.js';
