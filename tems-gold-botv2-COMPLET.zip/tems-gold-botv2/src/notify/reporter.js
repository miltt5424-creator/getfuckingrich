// reporter.js — Génère le rapport quotidien complet

import { writeFileSync, mkdirSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import logger from '../utils/logger.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

export class Reporter {
  constructor(config, gridManager, survivalSystem, notifier) {
    this.cfg      = config;
    this.gridMgr  = gridManager;
    this.survival = survivalSystem;
    this.notifier = notifier;
    this.dailyTrades = [];
    this.startEquity  = null;
  }

  setStartEquity(equity) { this.startEquity = equity; }

  recordTrade(trade) {
    this.dailyTrades.push({ ...trade, recordedAt: new Date() });
  }

  async generateDailyReport(currentEquity) {
    const gridStats   = this.gridMgr.getStats();
    const survivalStatus = this.survival.getStatus();
    const ddStats     = survivalStatus.ddStats;

    // Calcul par symbole
    const bySymbol = {};
    for (const trade of this.dailyTrades) {
      if (!bySymbol[trade.symbol]) bySymbol[trade.symbol] = { profit: 0, count: 0, wins: 0 };
      bySymbol[trade.symbol].profit += trade.profit || 0;
      bySymbol[trade.symbol].count++;
      if ((trade.profit || 0) > 0) bySymbol[trade.symbol].wins++;
    }

    const symbolEntries = Object.entries(bySymbol);
    const bestSymbol  = symbolEntries.sort((a,b) => b[1].profit - a[1].profit)[0]?.[0];
    const worstSymbol = symbolEntries.sort((a,b) => a[1].profit - b[1].profit)[0]?.[0];

    const stats = {
      date:          new Date().toDateString(),
      gridsOpened:   this.dailyTrades.length,
      gridsClosed:   gridStats.closedGrids,
      tpHits:        this.dailyTrades.filter(t => t.reason === 'TP_HIT').length,
      winRate:       parseFloat(gridStats.winRate),
      totalProfit:   gridStats.totalProfit,
      startEquity:   this.startEquity,
      endEquity:     currentEquity,
      maxDD:         ddStats.maxDDSeen || 0,
      bestSymbol,
      worstSymbol,
      avgDuration:   gridStats.avgDuration,
      bySymbol,
      survivalPhase: survivalStatus.phase,
    };

    // Sauvegarder en JSON
    try {
      const reportsDir = join(__dirname, '../../../logs/reports');
      mkdirSync(reportsDir, { recursive: true });
      const filename = `report_${new Date().toISOString().split('T')[0]}.json`;
      writeFileSync(join(reportsDir, filename), JSON.stringify(stats, null, 2));
      logger.info(`[Reporter] Rapport sauvegardé: ${filename}`);
    } catch (e) {
      logger.error(`[Reporter] Erreur sauvegarde rapport: ${e.message}`);
    }

    // Envoyer sur Telegram
    if (this.notifier) {
      await this.notifier.notifyDailyReport(stats);
    }

    // Reset des trades journaliers
    this.dailyTrades = [];
    this.startEquity = currentEquity;

    return stats;
  }
}
