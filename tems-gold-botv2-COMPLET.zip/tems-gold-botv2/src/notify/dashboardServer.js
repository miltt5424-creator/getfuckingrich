// dashboardServer.js — Serveur WebSocket qui pousse les données au dashboard Vite

import { WebSocketServer } from 'ws';
import { bus }             from '../utils/eventBus.js';
import logger              from '../utils/logger.js';

export class DashboardServer {
  constructor(config) {
    this.cfg     = config;
    this.wss     = null;
    this.clients = new Set();
    this.lastState = {};
  }

  start() {
    const port = this.cfg.env?.dashboardWsPort || 3002;
    this.wss   = new WebSocketServer({ port });

    this.wss.on('connection', (ws) => {
      this.clients.add(ws);
      logger.debug(`[Dashboard] Client connecté (${this.clients.size} total)`);

      // Envoyer l'état actuel au nouveau client
      if (Object.keys(this.lastState).length) {
        ws.send(JSON.stringify({ type: 'FULL_STATE', data: this.lastState }));
      }

      ws.on('close', () => {
        this.clients.delete(ws);
        logger.debug(`[Dashboard] Client déconnecté (${this.clients.size} restants)`);
      });

      ws.on('error', () => this.clients.delete(ws));
    });

    // Écouter tous les événements du bus et les broadcaster
    const eventsToBroadcast = [
      'candle:closed', 'tick:received', 'signal:generated',
      'grid:opened', 'grid:level_added', 'grid:tp_hit', 'grid:closed',
      'survival:phase_changed', 'survival:hedge_opened', 'survival:equity_stop',
      'account:equity_updated', 'bridge:connected', 'bridge:disconnected',
    ];

    for (const event of eventsToBroadcast) {
      bus.on(event, (data) => this.broadcast(event, data));
    }

    logger.info(`[Dashboard] WebSocket Server démarré sur port ${port}`);
  }

  broadcast(type, data) {
    const msg = JSON.stringify({ type, data, ts: Date.now() });
    this.lastState[type] = data;
    for (const client of this.clients) {
      try {
        if (client.readyState === 1) client.send(msg); // 1 = OPEN
      } catch {}
    }
  }

  updateState(key, value) {
    this.lastState[key] = value;
    this.broadcast('STATE_UPDATE', { key, value });
  }

  stop() {
    if (this.wss) this.wss.close();
  }
}
